// Put this file in  Assets/Editor/  and copy the exported kit folder to
// Assets/MyLife/  (so paths look like Assets/MyLife/Models/... and
// Assets/MyLife/Sprites/...). Every model and sprite is then imported with
// the right settings automatically.
using UnityEditor;
using UnityEngine;

public class MyLifeImportSettings : AssetPostprocessor
{
    const string Root = "/MyLife/";

    void OnPreprocessModel()
    {
        if (!assetPath.Contains(Root)) return;
        var mi = (ModelImporter)assetImporter;
        mi.globalScale = 1f;
        mi.useFileScale = true;
        mi.importBlendShapes = true;
        mi.importAnimation = false;
        mi.importNormals = ModelImporterNormals.Import;   // keeps the flat low-poly look
        mi.materialImportMode = ModelImporterMaterialImportMode.ImportStandard;

        if (assetPath.Contains("/Characters/"))
        {
            mi.animationType = ModelImporterAnimationType.Human;   // retarget any Humanoid clip
            mi.avatarSetup = ModelImporterAvatarSetup.CreateFromThisModel;
            mi.bakeAxisConversion = true;                          // characters export un-baked
        }
        else
        {
            mi.animationType = ModelImporterAnimationType.None;
            mi.generateSecondaryUV = assetPath.Contains("/Buildings/") ||
                                     assetPath.Contains("/Nature/");  // for baked lighting
        }
    }

    void OnPreprocessTexture()
    {
        if (!assetPath.Contains(Root) || !assetPath.Contains("/Sprites/")) return;
        var ti = (TextureImporter)assetImporter;
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.alphaIsTransparency = true;
        ti.mipmapEnabled = false;
        ti.wrapMode = TextureWrapMode.Clamp;
        ti.filterMode = FilterMode.Bilinear;
        ti.textureCompression = TextureImporterCompression.CompressedHQ;

        string file = System.IO.Path.GetFileNameWithoutExtension(assetPath);
        if (file.StartsWith("ui_"))
        {
            // 9-slice borders (pixels) so panels, buttons and bars stretch cleanly.
            // Use Image Type = Sliced in your UI.
            int b = (file.StartsWith("ui_bar") || file.StartsWith("ui_button")) ? 32 : 20;
            ti.spriteBorder = new Vector4(b, b, b, b);
        }
    }
}
