// Drives the facial blendshapes exported from the Blender kit
// (Smile, Blink, Surprised, Sad) with smooth blending and automatic blinking.
// Add to the root of any CHR_ character prefab.
//
//   GetComponent<MyLifeFace>().SetExpression(MyLifeFace.Expression.Smile);
//
using UnityEngine;

public class MyLifeFace : MonoBehaviour
{
    public enum Expression { Neutral, Smile, Surprised, Sad }

    public Expression expression = Expression.Neutral;
    [Range(0f, 1f)] public float intensity = 1f;
    public float blendSpeed = 8f;

    [Header("Blinking")]
    public bool autoBlink = true;
    public Vector2 blinkInterval = new Vector2(2.5f, 5.5f);
    public float blinkDuration = 0.15f;

    SkinnedMeshRenderer face;
    int iSmile = -1, iBlink = -1, iSurprised = -1, iSad = -1;
    float wSmile, wSurprised, wSad;
    float nextBlink, blinkT = -1f;

    void Awake()
    {
        face = GetComponentInChildren<SkinnedMeshRenderer>();
        if (face == null || face.sharedMesh == null) { enabled = false; return; }
        Mesh m = face.sharedMesh;
        for (int i = 0; i < m.blendShapeCount; i++)
        {
            string n = m.GetBlendShapeName(i);   // FBX may prefix names, so match the end
            if (n.EndsWith("Smile")) iSmile = i;
            else if (n.EndsWith("Blink")) iBlink = i;
            else if (n.EndsWith("Surprised")) iSurprised = i;
            else if (n.EndsWith("Sad")) iSad = i;
        }
        ScheduleBlink();
    }

    public void SetExpression(Expression e, float amount = 1f)
    {
        expression = e;
        intensity = Mathf.Clamp01(amount);
    }

    void Update()
    {
        float k = 1f - Mathf.Exp(-blendSpeed * Time.deltaTime);
        wSmile = Mathf.Lerp(wSmile, expression == Expression.Smile ? intensity : 0f, k);
        wSurprised = Mathf.Lerp(wSurprised, expression == Expression.Surprised ? intensity : 0f, k);
        wSad = Mathf.Lerp(wSad, expression == Expression.Sad ? intensity : 0f, k);
        Set(iSmile, wSmile);
        Set(iSurprised, wSurprised);
        Set(iSad, wSad);

        if (autoBlink && Time.time >= nextBlink && blinkT < 0f) blinkT = 0f;
        float blink = 0f;
        if (blinkT >= 0f)
        {
            blinkT += Time.deltaTime / Mathf.Max(blinkDuration, 0.01f);
            blink = Mathf.Sin(Mathf.Clamp01(blinkT) * Mathf.PI);
            if (blinkT >= 1f) { blinkT = -1f; ScheduleBlink(); }
        }
        Set(iBlink, blink);
    }

    void ScheduleBlink() => nextBlink = Time.time + Random.Range(blinkInterval.x, blinkInterval.y);

    void Set(int index, float w01)
    {
        if (index >= 0) face.SetBlendShapeWeight(index, w01 * 100f);
    }
}
