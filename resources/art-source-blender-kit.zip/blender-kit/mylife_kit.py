# =============================================================================
#  ជីវិតខ្ញុំ (My Life) - Blender Asset Kit
#  Procedural low-poly 3D assets + 2D UI sprites for the My Life life-sim,
#  with one-click export to Unity (FBX + PNG).
#
#  Works in Blender 3.6 LTS, 4.x (tested on 4.2 LTS).
#
#  HOW TO USE (pick one):
#   A) Install as add-on: Edit > Preferences > Add-ons > Install... > pick this
#      file > enable "My Life Asset Kit". Then View3D > Sidebar (N) > "My Life".
#   B) Scripting tab > Open this file > Run Script. The "My Life" sidebar tab
#      appears in the 3D viewport.
#   C) Command line (no GUI):
#      blender -b -P mylife_kit.py -- --build --render --export --out ./Export
# =============================================================================

bl_info = {
    "name": "My Life (ជីវិតខ្ញុំ) Asset Kit",
    "author": "My Life team",
    "version": (0, 1, 0),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > My Life",
    "description": "Low-poly Cambodian life-sim assets (characters, vehicles, "
                   "buildings, nature, props) and 2D UI sprites, with Unity export",
    "category": "Add Mesh",
}

import bpy
import bmesh
import math
import os
import random
import sys
from mathutils import Vector, Matrix, Euler

# -----------------------------------------------------------------------------
#  PALETTE  (GDD 12.1: warm golden light, saffron, rice green, laterite, sky)
#  Every material in the kit comes from this table, so the whole game shares
#  ~70 flat-colour materials. Change a hex here, rebuild, done.
# -----------------------------------------------------------------------------
PALETTE = {
    # people
    "Skin_Light": "#E9B996", "Skin_Tan": "#CF946A", "Skin_Brown": "#AD744E",
    "Hair_Black": "#1C1714", "Hair_DarkBrown": "#33241B",
    "Eye": "#151113", "EyeWhite": "#FFFFFF", "Mouth": "#8E3436", "Blush": "#E79A8C",
    # clothing
    "Cloth_White": "#ECEEF1", "Cloth_Navy": "#1F2A44", "Cloth_Charcoal": "#2C2E34",
    "Cloth_Black": "#1A1B1F", "Cloth_Denim": "#3F5C84", "Cloth_Plaid": "#6E3B35",
    "Cloth_PlaidDark": "#3A2826", "Cloth_TeeGrey": "#B4B3AE", "Cloth_Apron": "#B5642F",
    "Shoe_Grey": "#9FA5AB", "Shoe_Black": "#18181A", "Shoe_Brown": "#6B4228",
    "Sole_White": "#EAE6DE", "Sock_White": "#F2F2F0", "Straw": "#D8B26A",
    "Strap_Brown": "#4E3020", "Backpack_Black": "#232529", "Backpack_Navy": "#24335A",
    "Book_Teal": "#5F9C97", "Book_Blue": "#2F5D9A", "Laptop_Silver": "#B9BEC6",
    # buildings
    "Roof_Red": "#B9452F", "Roof_Terracotta": "#C45E3A", "Roof_Saffron": "#E2931E",
    "Roof_Green": "#3C7F5A", "Wall_Cream": "#F0E3C4", "Wall_White": "#F3F0E7",
    "Wall_Yellow": "#EFCB6E", "Wall_Mint": "#A9D8C2", "Wall_Peach": "#F2B793",
    "Wall_Blue": "#9CC3E0", "Trim_White": "#FAF8F2", "Concrete": "#B9B5AD",
    "Concrete_Dark": "#8E8A83", "Window_Blue": "#4F7EA3", "Glass": "#9CC2DA",
    "Door_Brown": "#7A4A2B", "Wood": "#8C5B36", "Wood_Dark": "#5C3B22",
    "Wood_Light": "#B88A5A", "Gold": "#D6A838", "Shutter_Grey": "#A7ABAF",
    "Sign_Blue": "#2B5FA6", "Clay": "#A65A3A",
    # nature & ground
    "Grass": "#76A84C", "Grass_Dark": "#5E9140", "Rice": "#93C653",
    "Rice_Water": "#7FA893", "Leaf": "#5C9C44", "Leaf_Dark": "#3E7838",
    "Leaf_Palm": "#6E9E3E", "Leaf_Dry": "#9C7A42", "Trunk": "#6B5646",
    "Trunk_Palm": "#585049", "Laterite": "#B95A32", "Dirt": "#C98E5A",
    "Water": "#3F82A8", "Water_Deep": "#2F6C92", "Asphalt": "#4B4D52",
    "Road_Line": "#F2E8C9", "Flower_Pink": "#E86A9A", "Flower_Yellow": "#F4C443",
    # vehicles
    "Moto_Red": "#B3262E", "Moto_Blue": "#2E5FA8", "Moto_Black": "#25262A",
    "Metal": "#BCC1C7", "Metal_Dark": "#5E6268", "Rubber": "#1E1E21",
    "Light_Lens": "#FFF3C8", "Tail_Light": "#D9302C", "Seat_Black": "#202124",
    "Remork_Canopy": "#2E7D5B", "Remork_Body": "#E8D9B0",
    # props & market
    "Plastic_Red": "#D8352F", "Plastic_Blue": "#2F6DB5", "Plastic_Green": "#3BA35F",
    "Tarp_Red": "#D9443A", "Tarp_Blue": "#2E86C1", "Tarp_Yellow": "#F2C14E",
    "Tarp_Green": "#3BAE6A", "Fruit_Orange": "#F08A24", "Fruit_Green": "#7DB83A",
    "Fruit_Red": "#C8312C", "Fruit_Yellow": "#F3D23B", "Coffee": "#6B3E26",
    "Coffee_Milk": "#C99A6B", "Ice": "#DDEEF5", "Phone_Body": "#2A2D33",
    "Phone_Screen": "#3B82C4", "Wallet": "#7B4A2A", "Bottle": "#8CC8E8",
    "Bottle_Cap": "#2F6DB5", "Noodle": "#F1E6C6", "Bowl": "#F4F1EA",
    "Bowl_Blue": "#3E6FB0", "Krama_Red": "#C0392B", "Krama_White": "#F4EFE6",
    "Helmet": "#E8E8E8", "Visor": "#3A3F47", "Rice_Sack": "#E9E0C8",
    # UI 2D
    "UI_Navy": "#22324A", "UI_White": "#FFFFFF", "UI_Cream": "#F6EEDC",
    "UI_CreamDark": "#E3D6BC", "UI_Heart": "#E5484D", "UI_Smile": "#F7C531",
    "UI_SmileDark": "#5A3B12", "UI_Skill": "#2F80ED", "UI_Money": "#27AE60",
    "UI_Energy": "#F5B400", "UI_Stress": "#8E5BD9", "UI_Grey": "#C9CED6",
    "UI_Green": "#2DA44E", "UI_Red": "#D64545", "UI_Orange": "#F08A3C",
    "UI_Shadow": "#00000033",
}


def hex_rgba(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    a = int(h[6:8], 16) / 255.0 if len(h) == 8 else 1.0

    def lin(c):  # sRGB -> linear (Blender colour sockets are linear)
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return (lin(r), lin(g), lin(b), a)


MAT_PREFIX = "ML_"


def get_mat(key):
    """Flat-colour material from the palette. Also sets the viewport colour so
    Workbench renders and the Solid viewport match the final look."""
    name = MAT_PREFIX + key
    m = bpy.data.materials.get(name)
    if m:
        return m
    col = hex_rgba(PALETTE.get(key, "#FF00FF"))
    m = bpy.data.materials.new(name)
    m.diffuse_color = col
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = col
        rough = 0.75
        metal = 0.0
        if key.startswith(("Metal", "Laptop", "Gold")):
            rough, metal = 0.35, 0.8
        if key in ("Glass", "Window_Blue", "Light_Lens", "Phone_Screen", "Visor"):
            rough = 0.15
        if key.startswith("Water"):
            rough = 0.1
        bsdf.inputs["Roughness"].default_value = rough
        bsdf.inputs["Metallic"].default_value = metal
    m["mylife_palette"] = key
    return m


# -----------------------------------------------------------------------------
#  Small math helpers
# -----------------------------------------------------------------------------
def V(*a):
    return Vector(a[0] if len(a) == 1 else a)


def T(loc=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1)):
    """Transform matrix. rot in DEGREES (XYZ euler)."""
    r = Euler([math.radians(a) for a in rot], "XYZ").to_matrix().to_4x4()
    s = Matrix.Diagonal((scale[0], scale[1], scale[2], 1.0))
    return Matrix.Translation(Vector(loc)) @ r @ s


def align_z(direction):
    """Rotation matrix that maps +Z onto `direction`."""
    d = Vector(direction).normalized()
    return Vector((0, 0, 1)).rotation_difference(d).to_matrix().to_4x4()


def circle_pts(r, n, cx=0.0, cy=0.0, a0=0.0, a1=2 * math.pi, closed=True,
               sx=1.0, sy=1.0):
    pts = []
    cnt = n if closed else n + 1
    for i in range(cnt):
        a = a0 + (a1 - a0) * i / n
        pts.append((cx + r * sx * math.cos(a), cy + r * sy * math.sin(a)))
    return pts


def rounded_rect_pts(w, h, r, cx=0.0, cy=0.0, n=6):
    r = min(r, w / 2, h / 2)
    pts = []
    corners = [(w / 2 - r, h / 2 - r, 0), (-w / 2 + r, h / 2 - r, 90),
               (-w / 2 + r, -h / 2 + r, 180), (w / 2 - r, -h / 2 + r, 270)]
    for x, y, a in corners:
        for i in range(n + 1):
            t = math.radians(a + 90 * i / n)
            pts.append((cx + x + r * math.cos(t), cy + y + r * math.sin(t)))
    return pts


def arc_band_pts(r_in, r_out, a0, a1, n=16, cx=0.0, cy=0.0):
    """Thick arc as a polygon (angles in degrees)."""
    outer = [(cx + r_out * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
              cy + r_out * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
             for i in range(n + 1)]
    inner = [(cx + r_in * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
              cy + r_in * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
             for i in range(n, -1, -1)]
    return outer + inner


# -----------------------------------------------------------------------------
#  Builder: every asset is assembled from primitives into ONE mesh object with
#  several material slots (= one draw call per material in Unity). Primitives
#  can carry a vertex-group name (rigging) and a tag (shape keys).
# -----------------------------------------------------------------------------
class Builder:
    def __init__(self, name, seed=1):
        self.name = name
        self.bm = bmesh.new()
        self.uv = self.bm.loops.layers.uv.verify()
        # layers must exist before any vertex is created (adding a layer later
        # invalidates python references to existing BMVerts)
        self.deform = self.bm.verts.layers.deform.verify()
        self.mats = []
        self.groups = []
        self.tags = {}
        self.rng = random.Random(seed)

    # ---- internals ----------------------------------------------------------
    def _mi(self, mat):
        if mat not in self.mats:
            self.mats.append(mat)
        return self.mats.index(mat)

    def _gi(self, g):
        if g not in self.groups:
            self.groups.append(g)
        return self.groups.index(g)

    @staticmethod
    def _tbm():
        t = bmesh.new()
        t.loops.layers.uv.verify()
        return t

    def _merge(self, t, mat, smooth=False, group=None, tag=None, mats=None):
        """Copy temp bmesh `t` into the asset. `mats` (optional) is a function
        face_index -> material key for multi-colour primitives."""
        tuv = t.loops.layers.uv.active
        vmap = {}
        for v in t.verts:
            vmap[v] = self.bm.verts.new(v.co)
        for i, f in enumerate(t.faces):
            try:
                nf = self.bm.faces.new([vmap[v] for v in f.verts])
            except ValueError:
                continue
            nf.material_index = self._mi(mats(i) if mats else mat)
            nf.smooth = smooth
            if tuv is not None:
                for l, nl in zip(f.loops, nf.loops):
                    nl[self.uv].uv = l[tuv].uv
        new_verts = list(vmap.values())
        if group:
            for v in new_verts:
                g = group(v.co) if callable(group) else group
                v[self.deform][self._gi(g)] = 1.0
        if tag:
            self.tags.setdefault(tag, []).extend(new_verts)
        t.free()
        return new_verts

    # ---- primitives -----------------------------------------------------------
    def box(self, size, loc=(0, 0, 0), rot=(0, 0, 0), mat="Cloth_White",
            bevel=0.0, seg=1, **kw):
        t = self._tbm()
        bmesh.ops.create_cube(t, size=1.0, calc_uvs=True)
        bmesh.ops.transform(t, matrix=Matrix.Diagonal((*size, 1)), verts=t.verts)
        if bevel > 0:
            bmesh.ops.bevel(t, geom=list(t.edges), offset=bevel, offset_type="OFFSET",
                            segments=seg, profile=0.5, affect="EDGES",
                            clamp_overlap=True)
        bmesh.ops.transform(t, matrix=T(loc, rot), verts=t.verts)
        return self._merge(t, mat, **kw)

    def cyl(self, r1, r2, depth, loc=(0, 0, 0), rot=(0, 0, 0), mat="Metal",
            seg=8, cap=True, scale=(1, 1, 1), matrix=None, **kw):
        """Cylinder/cone along local Z, centred at loc. r1 = bottom radius."""
        t = self._tbm()
        bmesh.ops.create_cone(t, cap_ends=cap, cap_tris=False, segments=seg,
                              radius1=max(r1, 1e-4), radius2=max(r2, 1e-4),
                              depth=depth, calc_uvs=True)
        m = matrix if matrix is not None else T(loc, rot, scale)
        bmesh.ops.transform(t, matrix=m, verts=t.verts)
        return self._merge(t, mat, **kw)

    def cyl_between(self, p1, p2, r1, r2=None, mat="Metal", seg=8, **kw):
        p1, p2 = Vector(p1), Vector(p2)
        d = p2 - p1
        m = Matrix.Translation((p1 + p2) / 2) @ align_z(d)
        return self.cyl(r1, r1 if r2 is None else r2, d.length, mat=mat, seg=seg,
                        matrix=m, **kw)

    def sphere(self, r, loc=(0, 0, 0), scale=(1, 1, 1), rot=(0, 0, 0),
               mat="Cloth_White", seg=12, rings=8, smooth=False, jitter=0.0, **kw):
        t = self._tbm()
        bmesh.ops.create_uvsphere(t, u_segments=seg, v_segments=rings, radius=r,
                                  calc_uvs=True)
        if jitter:
            for v in t.verts:
                v.co += Vector([self.rng.uniform(-jitter, jitter) for _ in range(3)])
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        return self._merge(t, mat, smooth=smooth, **kw)

    def ico(self, r, loc=(0, 0, 0), scale=(1, 1, 1), rot=(0, 0, 0), mat="Leaf",
            subdiv=1, jitter=0.0, **kw):
        t = self._tbm()
        bmesh.ops.create_icosphere(t, subdivisions=subdiv, radius=r, calc_uvs=True)
        if jitter:
            for v in t.verts:
                v.co += Vector([self.rng.uniform(-jitter, jitter) * r for _ in range(3)])
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        return self._merge(t, mat, **kw)

    def torus(self, R, r, loc=(0, 0, 0), rot=(0, 0, 0), mat="Rubber", seg=16,
              ring=6, arc=360.0, scale=(1, 1, 1), **kw):
        """Torus in local XY plane (axis = Z). `arc` < 360 gives an open tube."""
        t = self._tbm()
        closed = arc >= 359.9
        n = seg if closed else seg + 1
        rows = []
        for i in range(n):
            a = math.radians(arc * i / seg)
            row = []
            for j in range(ring):
                b = 2 * math.pi * j / ring
                rr = R + r * math.cos(b)
                row.append(t.verts.new((rr * math.cos(a), rr * math.sin(a),
                                        r * math.sin(b))))
            rows.append(row)
        for i in range(seg if closed else seg):
            a, b = rows[i], rows[(i + 1) % n]
            for j in range(ring):
                t.faces.new((a[j], b[j], b[(j + 1) % ring], a[(j + 1) % ring]))
        if not closed:
            t.faces.new(list(reversed(rows[0])))
            t.faces.new(rows[-1])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        return self._merge(t, mat, **kw)

    def lathe(self, profile, loc=(0, 0, 0), rot=(0, 0, 0), mat="Clay", seg=12,
              scale=(1, 1, 1), cap_bottom=True, cap_top=True, smooth=False,
              jag=None, mats=None, **kw):
        """Revolve a list of (radius, z) points around Z. `jag(i, j)` can
        return a radius multiplier for pleats/flutes."""
        t = self._tbm()
        rows = []
        for j, (r, z) in enumerate(profile):
            row = []
            for i in range(seg):
                a = 2 * math.pi * i / seg
                rr = r * (jag(i, j) if jag else 1.0)
                row.append(t.verts.new((rr * math.cos(a), rr * math.sin(a), z)))
            rows.append(row)
        for j in range(len(rows) - 1):
            a, b = rows[j], rows[j + 1]
            for i in range(seg):
                t.faces.new((a[i], a[(i + 1) % seg], b[(i + 1) % seg], b[i]))
        if cap_bottom and profile[0][0] > 1e-4:
            t.faces.new(list(reversed(rows[0])))
        if cap_top and profile[-1][0] > 1e-4:
            t.faces.new(rows[-1])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        fm = None
        if mats:
            fm = lambda fi: mats(fi % seg, fi // seg) if fi < seg * (len(rows) - 1) else mat
        return self._merge(t, mat, smooth=smooth, mats=fm, **kw)

    def prism(self, pts, depth, loc=(0, 0, 0), rot=(0, 0, 0), mat="Wood",
              matrix=None, center=True, mats=None, **kw):
        """Extrude a 2D polygon (local XY) along local Z."""
        t = self._tbm()
        z0 = -depth / 2 if center else 0.0
        bot = [t.verts.new((x, y, z0)) for x, y in pts]
        top = [t.verts.new((x, y, z0 + depth)) for x, y in pts]
        n = len(pts)
        t.faces.new(list(reversed(bot)))
        t.faces.new(top)
        for i in range(n):
            t.faces.new((bot[i], bot[(i + 1) % n], top[(i + 1) % n], top[i]))
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        ngons = [f for f in t.faces if len(f.verts) > 4]
        if ngons:
            bmesh.ops.triangulate(t, faces=ngons, quad_method="BEAUTY",
                                  ngon_method="BEAUTY")
        m = matrix if matrix is not None else T(loc, rot)
        bmesh.ops.transform(t, matrix=m, verts=t.verts)
        return self._merge(t, mat, mats=mats, **kw)

    def prism_x(self, pts_yz, length, loc=(0, 0, 0), mat="Roof_Red", **kw):
        """Profile drawn in the YZ plane, extruded along X (roofs, rails)."""
        return self.prism(pts_yz, length, matrix=T(loc, (90, 0, 90)), mat=mat, **kw)

    def poly(self, pts, z=0.0, mat="UI_White", loc=(0, 0, 0)):
        """Single flat face in XY (2D UI shapes)."""
        t = self._tbm()
        vs = [t.verts.new((x + loc[0], y + loc[1], z + loc[2])) for x, y in pts]
        f = t.faces.new(vs)
        f.normal_update()
        if f.normal.z < 0:
            f.normal_flip()
        bmesh.ops.triangulate(t, faces=[f], quad_method="BEAUTY", ngon_method="BEAUTY")
        return self._merge(t, mat)

    def custom(self, verts, faces, mat="Cloth_White", matrix=None, smooth=False, **kw):
        t = self._tbm()
        vs = [t.verts.new(v) for v in verts]
        for f in faces:
            t.faces.new([vs[i] for i in f])
        if matrix is not None:
            bmesh.ops.transform(t, matrix=matrix, verts=t.verts)
        return self._merge(t, mat, smooth=smooth, **kw)

    def hip_roof(self, L, D, H, loc=(0, 0, 0), mat="Roof_Red", thick=0.12, rot=(0, 0, 0)):
        """Four-sided hip roof, L along X, D along Y. loc = centre of eave base."""
        hl = L / 2
        hd = D / 2
        rl = max(hl - hd, 0.05)
        top = [(-hl, -hd, 0), (hl, -hd, 0), (hl, hd, 0), (-hl, hd, 0),
               (-rl, 0, H), (rl, 0, H)]
        bot = [(x, y, z - thick) for x, y, z in top]
        verts = top + bot
        faces = [(0, 1, 5, 4), (1, 2, 5), (2, 3, 4, 5), (3, 0, 4),
                 (10, 11, 7, 6), (11, 8, 7), (11, 10, 9, 8), (10, 6, 9),
                 (0, 6, 7, 1), (1, 7, 8, 2), (2, 8, 9, 3), (3, 9, 6, 0)]
        t = self._tbm()
        vs = [t.verts.new(v) for v in verts]
        for f in faces:
            t.faces.new([vs[i] for i in f])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        bmesh.ops.transform(t, matrix=T(loc, rot), verts=t.verts)
        return self._merge(t, mat)

    def gable_roof(self, L, D, H, loc=(0, 0, 0), mat="Roof_Red", thick=0.12,
                   overhang=0.4):
        """Gable roof: ridge along X. loc = centre of eave base."""
        w = D / 2 + overhang
        pts = [(-w, 0), (0, H), (w, 0), (w, -thick), (0, H - thick * 1.4), (-w, -thick)]
        return self.prism_x(pts, L + 2 * overhang, loc=loc, mat=mat)

    # ---- finish -------------------------------------------------------------
    def to_object(self, coll, loc=(0, 0, 0), category="Misc"):
        old = bpy.data.objects.get(self.name)
        if old:
            data = old.data
            bpy.data.objects.remove(old, do_unlink=True)
            if data and data.users == 0 and isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)
        self.bm.verts.index_update()
        self.tag_index = {k: [v.index for v in vs] for k, vs in self.tags.items()}
        self.bm.normal_update()
        me = bpy.data.meshes.new(self.name)
        self.bm.to_mesh(me)
        self.bm.free()
        for m in self.mats:
            me.materials.append(get_mat(m))
        obj = bpy.data.objects.new(self.name, me)
        coll.objects.link(obj)
        for g in self.groups:
            obj.vertex_groups.new(name=g)
        obj.location = loc
        obj["mylife_category"] = category
        obj["mylife_export"] = True
        return obj


def get_coll(name, parent=None):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
        (parent or bpy.context.scene.collection).children.link(c)
    return c


def root_coll():
    return get_coll("MyLife_Assets")


def cat_coll(cat):
    return get_coll("ML_" + cat, root_coll())


# =============================================================================
#  CHARACTERS
#  Low-poly, slightly cartoon-proportioned (GDD 12.1). Each character is one
#  skinned mesh + a Unity-Humanoid-friendly armature + facial blendshapes:
#  Smile, Blink, Surprised, Sad  (the "Expressions" column in the concept art).
#  Character faces -Y in Blender  ->  +Z (forward) in Unity after export.
# =============================================================================
CHARACTERS = {
    "Sokha": dict(name_km="សុខា", age=22, job="Teacher", place="Kampong Cham",
                  body="m", skin="Skin_Tan", hair="short", hair_col="Hair_Black",
                  top="shirt", top_col="Cloth_White", sleeves="short",
                  bottom="pants", bottom_col="Cloth_Navy", belt=True,
                  shoes="sneaker", shoe_col="Shoe_Grey",
                  extras=["backpack_black", "watch", "notebook_L"]),
    "Sreyneath": dict(name_km="ស្រីនាថ", age=20, job="University Student",
                      place="Phnom Penh", body="f", skin="Skin_Light", hair="long",
                      hair_col="Hair_Black", top="shirt", top_col="Cloth_White",
                      sleeves="short", bottom="skirt", bottom_col="Cloth_Navy",
                      shoes="flat", shoe_col="Shoe_Black",
                      extras=["backpack_navy", "book_R", "blush"]),
    "Vuth": dict(name_km="វុធ", age=25, job="Developer", place="Phnom Penh",
                 body="m", skin="Skin_Light", hair="messy", hair_col="Hair_Black",
                 top="hoodie", top_col="Cloth_Black", sleeves="long",
                 bottom="pants", bottom_col="Cloth_Charcoal",
                 shoes="sneaker", shoe_col="Shoe_Black",
                 extras=["glasses", "headphones", "laptop_L"]),
    "Taing": dict(name_km="តាំង", age=28, job="Farmer", place="Takeo", body="m",
                  skin="Skin_Brown", hair="short", hair_col="Hair_Black",
                  top="overshirt", top_col="Cloth_Plaid", sleeves="rolled",
                  bottom="pants", bottom_col="Cloth_Denim",
                  shoes="boot", shoe_col="Shoe_Brown",
                  extras=["straw_hat", "hoe_R"]),
    "Sokunthea": dict(name_km="សុគន្ធា", age=26, job="Shop Owner", place="Siem Reap",
                      body="f", skin="Skin_Tan", hair="long_center",
                      hair_col="Hair_DarkBrown", top="shirt", top_col="Cloth_White",
                      sleeves="long", bottom="pants", bottom_col="Cloth_Denim",
                      shoes="boot", shoe_col="Shoe_Brown",
                      extras=["apron", "blush"]),
}

HEAD_C = Vector((0, 0, 1.615))       # head centre
HEAD_R = Vector((0.165, 0.155, 0.18))  # head radii


def _skeleton(fem):
    sx = 0.205 if fem else 0.232      # shoulder x
    lx = 0.088 if fem else 0.095      # leg x
    J = {}
    for s, side in ((1, "L"), (-1, "R")):
        J["shoulder" + side] = Vector((sx * s, 0.0, 1.33))
        J["elbow" + side] = Vector(((sx + 0.035) * s, 0.01, 1.075))
        J["wrist" + side] = Vector(((sx + 0.055) * s, -0.01, 0.86))
        J["hand" + side] = Vector(((sx + 0.06) * s, -0.015, 0.80))
        J["hip" + side] = Vector((lx * s, 0.0, 0.90))
        J["knee" + side] = Vector((lx * s, -0.005, 0.50))
        J["ankle" + side] = Vector((lx * s, 0.0, 0.10))
    return J, sx, lx


def _torso_group(co):
    return "Chest" if co.z > 1.15 else "Spine"


def build_character(cid, coll=None, loc=(0, 0, 0)):
    cfg = CHARACTERS[cid]
    fem = cfg["body"] == "f"
    skin, top, bot = cfg["skin"], cfg["top_col"], cfg["bottom_col"]
    J, sx, lx = _skeleton(fem)
    b = Builder("CHR_" + cid, seed=hash(cid) & 0xFFFF)

    # ---------------- torso (lathe with rounded shoulders) -------------------
    if fem:
        prof = [(0.150, 0.88), (0.140, 1.00), (0.135, 1.07), (0.160, 1.18),
                (0.170, 1.27), (0.160, 1.35), (0.095, 1.405), (0.055, 1.42)]
    else:
        prof = [(0.160, 0.88), (0.162, 1.00), (0.168, 1.10), (0.190, 1.22),
                (0.205, 1.31), (0.180, 1.37), (0.105, 1.415), (0.06, 1.43)]
    plaid = None
    if cfg["top"] == "overshirt":   # flannel check pattern via face colours
        prof = [(r, z) for (r, z) in prof]
        dense = []
        for (r0, z0), (r1, z1) in zip(prof, prof[1:]):
            dense += [(r0, z0), ((r0 + r1) / 2, (z0 + z1) / 2)]
        prof = dense + [prof[-1]]
        plaid = lambda i, j: "Cloth_PlaidDark" if (i % 3 == 0) ^ (j % 3 == 0) else top
    b.lathe(prof, mat=top, seg=12, scale=(1, 0.62, 1), smooth=plaid is None,
            group=_torso_group, mats=plaid)
    # neck
    b.cyl(0.052, 0.050, 0.12, loc=(0, 0.005, 1.44), mat=skin, seg=8, group="Neck")

    # ---------------- top-specific details -----------------------------------
    t = cfg["top"]
    if t == "shirt":
        for s in (1, -1):   # collar flaps
            b.prism([(0, 0), (0.075 * s, 0.0), (0.02 * s, -0.06)], 0.012,
                    matrix=T((0.012 * s, -0.098, 1.41), (100, 0, 0)), mat=top,
                    group="Chest")
        b.box((0.012, 0.006, 0.42), loc=(0, -0.104, 1.13), mat="Trim_White",
              group=_torso_group)  # placket
        if not fem:
            b.box((0.075, 0.008, 0.08), loc=(-0.09, -0.115, 1.24), rot=(-8, 0, 0),
                  mat="Cloth_White", group="Chest")  # pocket
    elif t == "hoodie":
        b.torus(0.075, 0.03, loc=(0, 0.02, 1.405), rot=(10, 0, 0), mat=top,
                seg=14, ring=6, smooth=True, group="Chest")  # hood roll around neck
        b.sphere(0.12, loc=(0, 0.105, 1.38), scale=(1.0, 0.55, 0.75), mat=top,
                 group="Chest")  # hood on back
        b.box((0.20, 0.015, 0.13), loc=(0, -0.112, 1.00), mat="Cloth_Charcoal",
              bevel=0.02, group="Spine")  # kangaroo pocket
        for s in (1, -1):
            b.cyl_between((0.035 * s, -0.115, 1.38), (0.04 * s, -0.12, 1.22), 0.006,
                          mat="Cloth_White", seg=5, group="Chest")
    elif t == "overshirt":   # open flannel over a grey tee
        b.prism([(-0.055, 0.0), (0.055, 0.0), (0.06, 0.40), (0.0, 0.47), (-0.06, 0.40)],
                0.012, matrix=T((0, -0.106, 0.93), (90, 0, 0)), mat="Cloth_TeeGrey",
                group=_torso_group)
        for s in (1, -1):
            b.box((0.012, 0.012, 0.44), loc=(0.065 * s, -0.11, 1.12), mat=top,
                  group=_torso_group)
    if "apron" in cfg["extras"]:
        b.box((0.30, 0.012, 0.62), loc=(0, -0.118, 0.86), mat="Cloth_Apron",
              bevel=0.01, group=lambda c: "Hips" if c.z < 0.92 else "Spine")
        b.box((0.20, 0.012, 0.16), loc=(0, -0.105, 1.24), mat="Cloth_Apron",
              group="Chest")
        b.box((0.14, 0.008, 0.08), loc=(0, -0.126, 0.82), mat="Wood_Dark",
              group="Hips")  # pocket
        for s in (1, -1):
            b.cyl_between((0.085 * s, -0.105, 1.31), (0.05 * s, 0.0, 1.43), 0.009,
                          mat="Cloth_Apron", seg=5, group="Chest")
            b.cyl_between((0.15 * s, -0.10, 1.04), (0.16 * s, 0.06, 1.04), 0.01,
                          mat="Cloth_Apron", seg=5, group="Spine")

    # ---------------- arms ---------------------------------------------------
    sleeves = cfg["sleeves"]
    for side in ("L", "R"):
        sh, el, wr, hd = (J["shoulder" + side], J["elbow" + side],
                          J["wrist" + side], J["hand" + side])
        ua, la, hand = "UpperArm." + side, "LowerArm." + side, "Hand." + side
        arm_mat_up = top if sleeves in ("long", "rolled") else skin
        arm_mat_lo = top if sleeves == "long" else skin
        b.sphere(0.060 if not fem else 0.052, loc=sh + V(-0.012 if side == "L" else 0.012, 0, 0),
                 scale=(1.0, 1.0, 0.9), mat=top, seg=10, rings=6, smooth=True, group=ua)
        b.cyl_between(sh, el, 0.058 if not fem else 0.05, 0.048 if not fem else 0.042,
                      mat=arm_mat_up, seg=8, group=ua)
        if sleeves == "short":
            mid = sh.lerp(el, 0.45)
            b.cyl_between(sh, mid, 0.066 if not fem else 0.058,
                          0.066 if not fem else 0.058, mat=top, seg=8, group=ua)
        b.sphere(0.048 if not fem else 0.042, loc=el, mat=arm_mat_up, seg=8,
                 rings=6, group=la)
        b.cyl_between(el, wr, 0.046 if not fem else 0.04, 0.038 if not fem else 0.034,
                      mat=arm_mat_lo, seg=8, group=la)
        if sleeves == "rolled":
            b.torus(0.052, 0.018, loc=el.lerp(wr, 0.25), mat=top, seg=8, ring=5,
                    group=la)
        if sleeves == "long":
            b.cyl_between(wr + Vector((0, 0, 0.03)), wr, 0.044, 0.042, mat=top,
                          seg=8, group=la)
        b.sphere(0.047 if not fem else 0.041, loc=hd, scale=(0.78, 0.95, 1.2),
                 mat=skin, seg=8, rings=6, group=hand)
        # thumb
        sgn = 1 if side == "L" else -1
        b.sphere(0.018, loc=hd + Vector((-0.02 * sgn, -0.03, 0.01)),
                 scale=(1, 1, 1.5), mat=skin, seg=6, rings=4, group=hand)

    # ---------------- hips & legs --------------------------------------------
    bottom = cfg["bottom"]
    if bottom == "skirt":
        pleat = lambda i, j: 1.0 if i % 2 == 0 else 0.93
        b.lathe([(0.152, 0.95), (0.158, 0.88), (0.21, 0.72), (0.26, 0.57)],
                mat=bot, seg=16, scale=(1, 0.78, 1), jag=pleat,
                cap_top=True, cap_bottom=True, group="Hips")
    else:
        b.lathe([(0.15, 0.82), (0.163, 0.90), (0.162, 0.97)], mat=bot, seg=12,
                scale=(1, 0.64, 1), group="Hips")
    if cfg.get("belt"):
        b.lathe([(0.168, 0.935), (0.168, 0.965)], mat="Strap_Brown", seg=12,
                scale=(1, 0.66, 1), group="Hips")
        b.box((0.04, 0.01, 0.03), loc=(0, -0.112, 0.95), mat="Metal", group="Hips")

    for side in ("L", "R"):
        hp, kn, an = J["hip" + side], J["knee" + side], J["ankle" + side]
        ul, ll, ft = "UpperLeg." + side, "LowerLeg." + side, "Foot." + side
        if bottom == "skirt":
            b.cyl_between(hp, kn, 0.07, 0.055, mat=skin, seg=8, group=ul)
            b.sphere(0.055, loc=kn, mat=skin, seg=8, rings=6, group=ll)
            b.cyl_between(kn, an + Vector((0, 0, 0.02)), 0.052, 0.04, mat=skin,
                          seg=8, group=ll)
        else:
            b.cyl_between(hp, kn, 0.088 if not fem else 0.08, 0.072, mat=bot,
                          seg=8, group=ul)
            b.sphere(0.072, loc=kn, mat=bot, seg=8, rings=6, group=ll)
            b.cyl_between(kn, an + Vector((0, 0, 0.03)), 0.070, 0.066 if cfg["shoes"] != "boot" else 0.06,
                          mat=bot, seg=8, group=ll)
        # shoes
        shoes, sc = cfg["shoes"], cfg["shoe_col"]
        fx = an.x
        if shoes == "sneaker":
            b.box((0.112, 0.25, 0.085), loc=(fx, -0.04, 0.065), mat=sc, bevel=0.03,
                  group=ft)
            b.box((0.118, 0.258, 0.028), loc=(fx, -0.04, 0.014), mat="Sole_White",
                  bevel=0.008, group=ft)
            b.box((0.06, 0.08, 0.01), loc=(fx, -0.10, 0.11), rot=(-20, 0, 0),
                  mat="Sole_White", group=ft)  # laces patch
        elif shoes == "flat":
            b.cyl(0.045, 0.045, 0.06, loc=(fx, 0.0, 0.10), mat="Sock_White", seg=8,
                  group=ft)
            b.box((0.095, 0.22, 0.06), loc=(fx, -0.035, 0.035), mat=sc, bevel=0.025,
                  group=ft)
        elif shoes == "boot":
            b.cyl(0.066, 0.07, 0.22, loc=(fx, 0.0, 0.17), mat=sc, seg=8, group=ft)
            b.box((0.12, 0.26, 0.10), loc=(fx, -0.045, 0.055), mat=sc, bevel=0.03,
                  group=ft)
            b.box((0.124, 0.264, 0.024), loc=(fx, -0.045, 0.012), mat="Wood_Dark",
                  group=ft)

    # ---------------- head & face --------------------------------------------
    hc = HEAD_C
    b.sphere(1.0, loc=hc, scale=HEAD_R, mat=skin, seg=16, rings=12, smooth=True,
             group="Head")
    b.sphere(0.075, loc=hc + V(0, -0.045, -0.105), scale=(1.2, 1.0, 0.8),
             mat=skin, seg=10, rings=6, smooth=True, group="Head")  # jaw/chin
    for s in (1, -1):
        b.sphere(0.034, loc=hc + V(0.162 * s, 0.01, -0.02), scale=(0.45, 0.8, 1.1),
                 mat=skin, seg=8, rings=6, group="Head")
    b.sphere(0.018, loc=hc + V(0, -0.157, -0.045), scale=(0.9, 0.7, 0.8), mat=skin,
             seg=8, rings=5, smooth=True, group="Head")  # nose
    for s in (1, -1):
        b.sphere(0.024, loc=hc + V(0.058 * s, -0.140, 0.0), scale=(0.85, 0.45, 1.2),
                 mat="Eye", seg=10, rings=6, smooth=True, group="Head",
                 tag="eye_" + ("L" if s > 0 else "R"))
        b.sphere(0.0075, loc=hc + V(0.058 * s + 0.008, -0.152, 0.011), mat="EyeWhite",
                 seg=6, rings=4, group="Head", tag="hl_" + ("L" if s > 0 else "R"))
        b.box((0.05, 0.012, 0.011), loc=hc + V(0.058 * s, -0.142, 0.057),
              rot=(0, -6 * s, 0), mat=cfg["hair_col"], bevel=0.003, group="Head",
              tag="brow_" + ("L" if s > 0 else "R"))
        if "blush" in cfg["extras"]:
            b.sphere(0.022, loc=hc + V(0.092 * s, -0.128, -0.04), scale=(1.2, 0.4, 0.7),
                     rot=(0, 0, 30 * s), mat="Blush", seg=8, rings=4, group="Head")
    mv, mf = _mouth_mesh(MOUTH_NEUTRAL)
    b.custom(mv, mf, mat="Mouth", matrix=Matrix.Translation(hc + V(0, -0.135, -0.085)),
             group="Head", tag="mouth")

    _build_hair(b, cfg)
    _build_extras(b, cfg, J, sx)

    coll = coll or cat_coll("Characters")
    obj = b.to_object(coll, category="Characters")
    obj.location = (0, 0, 0)
    _add_face_shapekeys(obj, b)
    for k, v in cfg.items():
        if isinstance(v, (str, int)):
            obj["mylife_" + k] = v
    rig = _build_rig(obj, fem, J, coll)
    rig.location = loc
    return rig


# ---- face: mouth ring + shape keys ------------------------------------------
MOUTH_N = 12
MOUTH_NEUTRAL = dict(w=0.026, h=0.0075, k=0.006)
MOUTH_SMILE = dict(w=0.036, h=0.0115, k=0.021)
MOUTH_SURPRISED = dict(w=0.018, h=0.022, k=0.0)
MOUTH_SAD = dict(w=0.025, h=0.0065, k=-0.014)


def _mouth_ring(p):
    pts = []
    for i in range(MOUTH_N):
        a = 2 * math.pi * i / MOUTH_N
        x = p["w"] * math.cos(a)
        z = p["h"] * math.sin(a) + p["k"] * (x / p["w"]) ** 2 if p["w"] else 0
        pts.append((x, z))
    return pts


def _mouth_mesh(p):
    ring = _mouth_ring(p)
    verts = [(x, 0.0, z) for x, z in ring] + [(x, 0.014, z) for x, z in ring]
    n = MOUTH_N
    faces = [list(range(n))[::-1], list(range(n, 2 * n))]
    for i in range(n):
        faces.append((i, (i + 1) % n, n + (i + 1) % n, n + i))
    return verts, faces


def _add_face_shapekeys(obj, b):
    me = obj.data
    base = [v.co.copy() for v in me.vertices]
    idx = b.tag_index
    mouth_c = HEAD_C + V(0, -0.135, -0.085)

    def centre(ids):
        c = Vector()
        for i in ids:
            c += base[i]
        return c / max(len(ids), 1)

    def mouth_coords(p):
        ring = _mouth_ring(p)
        ids = idx["mouth"]
        out = {}
        for k, i in enumerate(ids):
            x, z = ring[k % MOUTH_N]
            y = 0.0 if k < MOUTH_N else 0.014
            out[i] = mouth_c + V(x, y, z)
        return out

    def scale_about(ids, sxz, c=None):
        c = c or centre(ids)
        res = {}
        for i in ids:
            d = base[i] - c
            res[i] = c + V(d.x * sxz[0], d.y, d.z * sxz[1])
        return res

    obj.shape_key_add(name="Basis", from_mix=False)

    def make(name, *dicts):
        kb = obj.shape_key_add(name=name, from_mix=False)
        for d in dicts:
            for i, co in d.items():
                kb.data[i].co = co
        kb.value = 0.0

    eyes = idx["eye_L"] + idx["eye_R"]
    hls = idx["hl_L"] + idx["hl_R"]
    blink = {}
    for side in ("L", "R"):
        c = centre(idx["eye_" + side])
        blink.update(scale_about(idx["eye_" + side], (1.1, 0.12), c))
        blink.update(scale_about(idx["hl_" + side], (0.0, 0.0), c))
    smile_eyes = {}
    for side in ("L", "R"):
        c = centre(idx["eye_" + side])
        smile_eyes.update(scale_about(idx["eye_" + side], (1.08, 0.45), c + V(0, 0, -0.014)))
        smile_eyes.update(scale_about(idx["hl_" + side], (0.6, 0.6), c))
    surpr_eyes = {}
    for side in ("L", "R"):
        c = centre(idx["eye_" + side])
        surpr_eyes.update(scale_about(idx["eye_" + side], (1.15, 1.15), c))
    brows_up = {i: base[i] + V(0, -0.002, 0.016) for i in idx["brow_L"] + idx["brow_R"]}
    brows_sad = {}
    for side, s in (("L", 1), ("R", -1)):
        for i in idx["brow_" + side]:
            inner = 1.0 - min(abs(base[i].x - 0.033 * s) / 0.05, 1.0)
            brows_sad[i] = base[i] + V(0, 0, 0.013 * inner - 0.004 * (1 - inner))

    make("Smile", mouth_coords(MOUTH_SMILE), smile_eyes)
    make("Blink", blink)
    make("Surprised", mouth_coords(MOUTH_SURPRISED), surpr_eyes, brows_up)
    make("Sad", mouth_coords(MOUTH_SAD), brows_sad)


# ---- hair --------------------------------------------------------------------
def _hair_cap(b, col, front_cut=0.28, back_cut=-0.62, side_cut=-0.18, grow=1.08):
    t = b._tbm()
    bmesh.ops.create_uvsphere(t, u_segments=16, v_segments=10, radius=1.0, calc_uvs=True)
    kill = []
    for v in t.verts:
        y, z = v.co.y, v.co.z
        cut = side_cut + (-y) * (front_cut - side_cut) if y < 0 else side_cut + y * (back_cut - side_cut)
        if z < cut:
            kill.append(v)
    bmesh.ops.delete(t, geom=kill, context="VERTS")
    for v in t.verts:
        v.co += Vector([b.rng.uniform(-0.03, 0.03) for _ in range(3)])
    sc = (HEAD_R.x * grow, HEAD_R.y * grow, HEAD_R.z * (grow + 0.02))
    bmesh.ops.transform(t, matrix=T(HEAD_C + V(0, 0.006, 0.012), (0, 0, 0), sc),
                        verts=t.verts)
    b._merge(t, col, smooth=False, group="Head")


def _build_hair(b, cfg):
    col = cfg["hair_col"]
    hc = HEAD_C
    style = cfg["hair"]
    if style in ("short", "messy"):
        _hair_cap(b, col)
        fringe = [(-0.10, 4), (-0.05, -6), (0.0, 8), (0.05, -4), (0.10, 6)]
        for x, rz in fringe:
            b.sphere(0.055, loc=hc + V(x, -0.135, 0.105), scale=(1.0, 0.55, 0.85),
                     rot=(25, rz, rz), mat=col, seg=8, rings=5, group="Head")
        for s in (1, -1):  # sideburns
            b.box((0.02, 0.05, 0.07), loc=hc + V(0.158 * s, -0.035, 0.0), mat=col,
                  group="Head")
        if style == "messy":
            for i in range(6):
                a = i * 2 * math.pi / 6 + 0.3
                p = hc + V(0.085 * math.cos(a), 0.08 * math.sin(a), 0.165)
                b.sphere(0.055, loc=p, scale=(1.0, 0.75, 0.55),
                         rot=(10 * math.sin(a), -10 * math.cos(a), math.degrees(a)),
                         mat=col, seg=7, rings=4, group="Head", jitter=0.008)
            b.sphere(0.06, loc=hc + V(0.06, -0.12, 0.13), scale=(1.4, 0.6, 0.8),
                     rot=(20, 0, -15), mat=col, seg=8, rings=5, group="Head")
    elif style in ("long", "long_center"):
        _hair_cap(b, col, front_cut=0.36, side_cut=-0.35, back_cut=-0.7)
        b.sphere(1.0, loc=hc + V(0, 0.075, -0.17), scale=(0.17, 0.10, 0.27), mat=col,
                 seg=12, rings=8, group="Head", jitter=0.03)
        for s in (1, -1):
            b.sphere(1.0, loc=hc + V(0.148 * s, -0.01, -0.13), scale=(0.05, 0.065, 0.19),
                     mat=col, seg=8, rings=6, group="Head", jitter=0.04)
        if style == "long":   # side-swept bangs
            for x, sc in ((-0.07, 1.25), (0.0, 1.1), (0.07, 0.95)):
                b.sphere(0.06, loc=hc + V(x, -0.135, 0.11), scale=(sc, 0.5, 0.8),
                         rot=(25, 0, -20), mat=col, seg=8, rings=5, group="Head")
        else:                 # centre part, curtains to the sides
            for s in (1, -1):
                b.sphere(0.07, loc=hc + V(0.075 * s, -0.125, 0.10), scale=(1.2, 0.5, 0.9),
                         rot=(20, 0, 25 * s), mat=col, seg=8, rings=5, group="Head")


# ---- accessories & held props ------------------------------------------------
def _build_extras(b, cfg, J, sx):
    ex = cfg["extras"]
    hc = HEAD_C
    for e in ex:
        if e.startswith("backpack"):
            col = "Backpack_Black" if e.endswith("black") else "Backpack_Navy"
            b.box((0.28, 0.14, 0.34), loc=(0, 0.165, 1.14), mat=col, bevel=0.035,
                  seg=2, group="Chest")
            b.box((0.20, 0.05, 0.14), loc=(0, 0.245, 1.06), mat=col, bevel=0.02,
                  group="Chest")
            b.box((0.16, 0.005, 0.01), loc=(0, 0.272, 1.10), mat="Metal", group="Chest")
            fy = -0.112 if cfg["body"] == "f" else -0.134
            for s in (1, -1):
                b.cyl_between((0.10 * s, fy, 1.17), (0.122 * s, fy * 0.6, 1.33), 0.016,
                              mat=col, seg=5, group="Chest")
                b.cyl_between((0.122 * s, fy * 0.6, 1.33), (0.125 * s, -0.045, 1.37), 0.016,
                              mat=col, seg=5, group="Chest")
                b.cyl_between((0.125 * s, -0.045, 1.37), (0.11 * s, 0.10, 1.32), 0.016,
                              mat=col, seg=5, group="Chest")
        elif e == "watch":
            w = J["wristL"]
            b.cyl(0.044, 0.044, 0.022, loc=w + V(0, 0, 0.035), mat="Cloth_Black", seg=8,
                  group="LowerArm.L")
            b.box((0.012, 0.03, 0.026), loc=w + V(0.042, -0.002, 0.035), mat="Metal",
                  group="LowerArm.L")
        elif e == "notebook_L":
            h = J["handL"]
            b.box((0.026, 0.17, 0.23), loc=h + V(0.035, 0.0, -0.02), rot=(8, 0, 0),
                  mat="Book_Teal", bevel=0.004, group="Hand.L")
        elif e == "book_R":
            h = J["handR"]
            b.box((0.035, 0.16, 0.22), loc=h + V(-0.035, 0.0, -0.02), rot=(-6, 0, 0),
                  mat="Book_Blue", bevel=0.004, group="Hand.R")
        elif e == "laptop_L":
            h = J["handL"]
            b.box((0.022, 0.30, 0.21), loc=h + V(0.035, 0.02, 0.02), rot=(5, 0, 0),
                  mat="Laptop_Silver", bevel=0.006, group="Hand.L")
        elif e == "glasses":
            for s in (1, -1):
                b.torus(0.033, 0.0045, loc=hc + V(0.058 * s, -0.166, 0.003),
                        rot=(90, 0, 0), scale=(1.1, 1, 0.9), mat="Cloth_Black", seg=12,
                        ring=4, group="Head")
                b.cyl_between(hc + V(0.094 * s, -0.163, 0.01), hc + V(0.162 * s, -0.02, 0.01),
                              0.004, mat="Cloth_Black", seg=4, group="Head")
            b.cyl_between(hc + V(-0.022, -0.168, 0.008), hc + V(0.022, -0.168, 0.008),
                          0.004, mat="Cloth_Black", seg=4, group="Head")
        elif e == "headphones":
            b.torus(0.105, 0.014, loc=(0, -0.01, 1.385), rot=(-10, 0, 0), arc=200,
                    mat="Cloth_Charcoal", seg=12, ring=5, group="Neck",
                    scale=(1.0, 0.95, 1.0))
            for s in (1, -1):
                b.cyl(0.045, 0.045, 0.035, loc=(0.108 * s, -0.04, 1.37),
                      rot=(0, 90, 0), mat="Cloth_Black", seg=10, group="Neck")
                b.cyl(0.032, 0.032, 0.012, loc=(0.128 * s, -0.04, 1.37),
                      rot=(0, 90, 0), mat="Metal_Dark", seg=10, group="Neck")
        elif e == "straw_hat":
            b.lathe([(0.0, 1.715), (0.34, 1.705), (0.33, 1.725), (0.17, 1.75),
                     (0.15, 1.84), (0.11, 1.875), (0.0, 1.885)],
                    loc=V(0, 0.01, 0.0), rot=(-6, 0, 0), mat="Straw", seg=14,
                    cap_bottom=False, cap_top=False, group="Head")
            b.lathe([(0.168, 1.75), (0.163, 1.785)], loc=V(0, 0.01, 0.0), rot=(-6, 0, 0),
                    mat="Strap_Brown", seg=14, scale=(1.02, 1.02, 1.0), group="Head")
        elif e == "hoe_R":
            h = J["handR"]
            top_p = h + V(-0.02, -0.05, 0.55)
            bot_p = h + V(-0.05, -0.12, -0.70)
            b.cyl_between(bot_p, top_p, 0.016, mat="Wood", seg=6, group="Hand.R")
            b.box((0.16, 0.02, 0.13), loc=bot_p + V(0, -0.05, 0.0), rot=(30, 0, 0),
                  mat="Metal_Dark", group="Hand.R")


# ---- armature (Unity Humanoid naming) ----------------------------------------
def _build_rig(mesh_obj, fem, J, coll):
    name = mesh_obj.name.replace("CHR_", "RIG_")
    old = bpy.data.objects.get(name)
    if old:
        bpy.data.objects.remove(old, do_unlink=True)
    arm_data = bpy.data.armatures.new(name)
    rig = bpy.data.objects.new(name, arm_data)
    coll.objects.link(rig)
    rig["mylife_category"] = "Characters"
    rig["mylife_export"] = True
    rig.show_in_front = False
    arm_data.display_type = "STICK"

    vl = bpy.context.view_layer
    # make sure the rig is in the active view layer to enter edit mode
    if rig.name not in vl.objects:
        bpy.context.scene.collection.objects.link(rig)
    prev_active = vl.objects.active
    for o in vl.objects:
        o.select_set(False)
    vl.objects.active = rig
    bpy.ops.object.mode_set(mode="EDIT")
    eb = arm_data.edit_bones

    def bone(n, head, tail, parent=None, connect=False):
        bn = eb.new(n)
        bn.head, bn.tail = Vector(head), Vector(tail)
        if parent:
            bn.parent = eb[parent]
            bn.use_connect = connect
        return bn

    bone("Hips", (0, 0, 0.90), (0, 0, 1.00))
    bone("Spine", (0, 0, 1.00), (0, 0, 1.15), "Hips", True)
    bone("Chest", (0, 0, 1.15), (0, 0, 1.36), "Spine", True)
    bone("Neck", (0, 0, 1.36), (0, 0, 1.47), "Chest", True)
    bone("Head", (0, 0, 1.47), (0, 0, 1.82), "Neck", True)
    for side in ("L", "R"):
        s = 1 if side == "L" else -1
        sh = J["shoulder" + side]
        bone("Shoulder." + side, (0.04 * s, 0, 1.34), sh, "Chest")
        bone("UpperArm." + side, sh, J["elbow" + side], "Shoulder." + side, True)
        bone("LowerArm." + side, J["elbow" + side], J["wrist" + side],
             "UpperArm." + side, True)
        bone("Hand." + side, J["wrist" + side], J["hand" + side] + V(0, 0, -0.06),
             "LowerArm." + side, True)
        bone("UpperLeg." + side, J["hip" + side], J["knee" + side], "Hips")
        bone("LowerLeg." + side, J["knee" + side], J["ankle" + side],
             "UpperLeg." + side, True)
        bone("Foot." + side, J["ankle" + side], J["ankle" + side] + V(0, -0.13, -0.06),
             "LowerLeg." + side, True)
        bone("Toes." + side, J["ankle" + side] + V(0, -0.13, -0.06),
             J["ankle" + side] + V(0, -0.20, -0.06), "Foot." + side, True)
    bpy.ops.object.mode_set(mode="OBJECT")
    if rig.name in bpy.context.scene.collection.objects and rig.name in coll.objects:
        bpy.context.scene.collection.objects.unlink(rig)
    vl.objects.active = prev_active

    mesh_obj.parent = rig
    mod = mesh_obj.modifiers.new("Armature", "ARMATURE")
    mod.object = rig
    return rig


# =============================================================================
#  VEHICLES   (front = -Y, ground at Z=0, origin at centre)
# =============================================================================
def _wheel(b, loc, R=0.30, w=0.09, rim="Metal", seg=16):
    b.torus(R - 0.05, 0.05, loc=loc, rot=(0, 90, 0), mat="Rubber", seg=seg, ring=6,
            scale=(1.0, 1.0, w / 0.1))
    b.cyl(R - 0.07, R - 0.07, w * 0.6, loc=loc, rot=(0, 90, 0), mat=rim, seg=seg)
    b.cyl(0.05, 0.05, w * 1.2, loc=loc, rot=(0, 90, 0), mat="Metal_Dark", seg=8)


def build_motorbike(color="Moto_Red", name=None):
    """Step-through scooter - the most common bike on Cambodian roads."""
    b = Builder(name or "VEH_Motorbike_" + color.split("_")[1])
    fw, rw = V(0, -0.64, 0.30), V(0, 0.62, 0.30)
    _wheel(b, fw)
    _wheel(b, rw)
    # front fork, fender
    b.cyl_between(fw + V(0.06, 0, 0), V(0.06, -0.50, 0.95), 0.022, mat="Metal", seg=6)
    b.cyl_between(fw + V(-0.06, 0, 0), V(-0.06, -0.50, 0.95), 0.022, mat="Metal", seg=6)
    b.torus(0.33, 0.06, loc=fw, rot=(0, 90, 0), arc=150, mat=color, seg=10, ring=4,
            scale=(1, 1, 0.9))
    # leg shield + front body
    b.prism([(-0.10, 0.25), (0.10, 0.92), (0.24, 0.98), (0.16, 0.25)], 0.30,
            matrix=T((0, -0.40, 0), (90, 0, 90)) @ T((0, 0, 0), (0, 0, 0)),
            mat=color)
    b.box((0.26, 0.06, 0.50), loc=(0, -0.40, 0.62), rot=(-18, 0, 0), mat=color,
          bevel=0.03)
    # floor + frame
    b.box((0.28, 0.42, 0.05), loc=(0, -0.08, 0.30), mat="Moto_Black", bevel=0.01)
    # body under seat
    b.prism([(0.10, 0.30), (0.10, 0.62), (0.76, 0.70), (0.86, 0.56), (0.64, 0.30)],
            0.30, matrix=T((0, 0, 0), (90, 0, 90)), mat=color)
    b.box((0.27, 0.62, 0.11), loc=(0, 0.38, 0.75), mat="Seat_Black", bevel=0.045, seg=2)
    b.box((0.06, 0.12, 0.04), loc=(0, 0.74, 0.74), mat="Metal")   # rear rack
    b.box((0.18, 0.06, 0.06), loc=(0, 0.88, 0.62), mat="Tail_Light", bevel=0.01)
    # engine & exhaust
    b.box((0.22, 0.30, 0.20), loc=(0, 0.30, 0.30), mat="Metal_Dark", bevel=0.03)
    b.cyl_between(V(0.16, 0.10, 0.22), V(0.16, 0.85, 0.36), 0.04, mat="Metal", seg=8)
    # handlebar & head
    b.box((0.30, 0.14, 0.14), loc=(0, -0.52, 1.02), mat=color, bevel=0.04, seg=2)
    b.cyl(0.055, 0.06, 0.04, loc=(0, -0.60, 1.02), rot=(90, 0, 0), mat="Light_Lens", seg=10)
    b.cyl_between(V(-0.36, -0.48, 1.05), V(0.36, -0.48, 1.05), 0.016, mat="Metal", seg=6)
    for s in (1, -1):
        b.cyl_between(V(0.30 * s, -0.48, 1.05), V(0.38 * s, -0.48, 1.05), 0.024,
                      mat="Rubber", seg=6)
        b.cyl_between(V(0.18 * s, -0.48, 1.06), V(0.22 * s, -0.50, 1.24), 0.008,
                      mat="Metal", seg=4)
        b.sphere(0.035, loc=(0.22 * s, -0.50, 1.26), scale=(1.4, 0.4, 1), mat="Visor",
                 seg=8, rings=4)
    return b.to_object(cat_coll("Vehicles"), category="Vehicles")


def build_remork():
    """Cambodian tuk-tuk (remork): motorbike pulling a covered carriage."""
    b = Builder("VEH_Remork")
    # carriage chassis behind the bike (bike drawn separately in-game, or use
    # the combined prefab). Carriage: 1.5m x 1.8m
    cy = 1.55
    b.box((1.40, 1.70, 0.10), loc=(0, cy, 0.55), mat="Metal_Dark", bevel=0.02)
    for s in (1, -1):
        _wheel(b, V(0.78 * s, cy + 0.15, 0.30), R=0.30)
        b.torus(0.36, 0.05, loc=V(0.78 * s, cy + 0.15, 0.30), rot=(0, 90, 0), arc=180,
                mat="Remork_Body", seg=10, ring=4)
        # bench + back rest (facing each other)
    for y, d in ((cy - 0.55, 1), (cy + 0.55, -1)):
        b.box((1.30, 0.42, 0.10), loc=(0, y, 0.85), mat="Seat_Black", bevel=0.03)
        b.box((1.30, 0.08, 0.40), loc=(0, y - 0.22 * d, 1.08), mat="Seat_Black", bevel=0.03)
    b.box((1.40, 1.70, 0.30), loc=(0, cy, 0.72), mat="Remork_Body", bevel=0.03)
    # side panels with step
    b.box((0.40, 0.25, 0.04), loc=(0.55, cy, 0.42), mat="Metal")
    # roof
    for x in (-0.66, 0.66):
        for y in (cy - 0.80, cy + 0.80):
            b.cyl(0.022, 0.022, 1.25, loc=(x, y, 1.45), mat="Metal", seg=6)
    b.box((1.55, 1.95, 0.08), loc=(0, cy, 2.10), mat="Remork_Canopy", bevel=0.03)
    for s in (1, -1):  # scalloped valance
        for i in range(8):
            b.prism([(-0.1, 0), (0.1, 0), (0, -0.09)], 0.01,
                    matrix=T((-0.70 + i * 0.2, cy - 0.97 * s, 2.06), (90, 0, 0)),
                    mat="Remork_Canopy")
    # hitch to bike
    b.cyl_between(V(0, cy - 0.85, 0.55), V(0, 0.55, 0.78), 0.035, mat="Metal_Dark", seg=6)
    obj = b.to_object(cat_coll("Vehicles"), category="Vehicles")
    bike = build_motorbike("Moto_Black", name="VEH_Remork_Bike")
    bike.parent = obj
    return obj


def build_bicycle():
    b = Builder("VEH_Bicycle")
    fw, rw = V(0, -0.52, 0.33), V(0, 0.52, 0.33)
    for w in (fw, rw):
        b.torus(0.31, 0.022, loc=w, rot=(0, 90, 0), mat="Rubber", seg=18, ring=4)
        b.cyl(0.03, 0.03, 0.06, loc=w, rot=(0, 90, 0), mat="Metal", seg=6)
    col = "Plastic_Blue"
    bb = V(0, 0.05, 0.33)
    seat = V(0, 0.18, 0.92)
    head = V(0, -0.40, 0.95)
    for p1, p2 in ((bb, seat), (bb, head), (seat, head + V(0, 0.02, -0.08)), (bb, rw),
                   (seat + V(0, 0, -0.06), rw), (head, fw)):
        b.cyl_between(p1, p2, 0.02, mat=col, seg=6)
    b.box((0.13, 0.24, 0.05), loc=seat + V(0, 0.02, 0.05), mat="Seat_Black", bevel=0.02)
    b.cyl_between(head + V(-0.25, 0.05, 0.12), head + V(0.25, 0.05, 0.12), 0.014,
                  mat="Metal", seg=6)
    b.cyl_between(head, head + V(0, 0.05, 0.12), 0.018, mat="Metal", seg=6)
    b.box((0.30, 0.22, 0.18), loc=head + V(0, -0.14, -0.05), mat="Wood_Light")  # basket
    b.cyl(0.08, 0.08, 0.02, loc=bb, rot=(0, 90, 0), mat="Metal_Dark", seg=10)
    return b.to_object(cat_coll("Vehicles"), category="Vehicles")


# =============================================================================
#  BUILDINGS   (origin = centre of footprint at ground, front = -Y)
# =============================================================================
def _window(b, loc, w=1.0, h=1.2, face="-Y", frame="Trim_White", glass="Window_Blue"):
    rot = {"-Y": (0, 0, 0), "+Y": (0, 0, 180), "-X": (0, 0, -90), "+X": (0, 0, 90)}[face]
    m = T(loc, rot)
    b.custom([(-w / 2 - 0.08, -0.04, -h / 2 - 0.08), (w / 2 + 0.08, -0.04, -h / 2 - 0.08),
              (w / 2 + 0.08, -0.04, h / 2 + 0.08), (-w / 2 - 0.08, -0.04, h / 2 + 0.08),
              (-w / 2 - 0.08, 0.02, -h / 2 - 0.08), (w / 2 + 0.08, 0.02, -h / 2 - 0.08),
              (w / 2 + 0.08, 0.02, h / 2 + 0.08), (-w / 2 - 0.08, 0.02, h / 2 + 0.08)],
             [(0, 1, 2, 3), (1, 0, 4, 5), (2, 1, 5, 6), (3, 2, 6, 7), (0, 3, 7, 4)],
             mat=frame, matrix=m)
    t = b._tbm()
    bmesh.ops.create_cube(t, size=1.0, calc_uvs=True)
    bmesh.ops.transform(t, matrix=m @ T((0, -0.05, 0), (0, 0, 0), (w, 0.02, h)), verts=t.verts)
    b._merge(t, glass)
    t = b._tbm()   # mullion
    bmesh.ops.create_cube(t, size=1.0, calc_uvs=True)
    bmesh.ops.transform(t, matrix=m @ T((0, -0.065, 0), (0, 0, 0), (0.05, 0.02, h)), verts=t.verts)
    b._merge(t, frame)


def _door(b, loc, w=1.0, h=2.1, face="-Y", mat="Door_Brown"):
    rot = {"-Y": (0, 0, 0), "+Y": (0, 0, 180), "-X": (0, 0, -90), "+X": (0, 0, 90)}[face]
    m = T(loc, rot)
    for piece, sz, ofs, mt in (("frame", (w + 0.16, 0.06, h + 0.08), (0, -0.01, 0.04), "Trim_White"),
                               ("leaf", (w, 0.06, h), (0, -0.03, 0), mat)):
        t = b._tbm()
        bmesh.ops.create_cube(t, size=1.0, calc_uvs=True)
        bmesh.ops.transform(t, matrix=m @ T((ofs[0], ofs[1], h / 2 + ofs[2]), (0, 0, 0), sz),
                            verts=t.verts)
        b._merge(t, mt)


def build_school():
    """Two-storey provincial school with an open corridor (Kampong Cham)."""
    b = Builder("BLD_School")
    L, D, H = 18.0, 6.5, 3.3
    cor = 2.2                                   # corridor depth (front)
    b.box((L + 0.6, D + cor + 0.6, 0.45), loc=(0, -cor / 2, 0.225), mat="Concrete")
    for i, step in enumerate((0.15, 0.30)):     # steps
        b.box((3.0, 0.35, step), loc=(0, -D / 2 - cor - 0.3 - 0.35 * (1 - i), step / 2),
              mat="Concrete")
    for fl in range(2):
        z0 = 0.45 + fl * H
        b.box((L, D, H), loc=(0, 0, z0 + H / 2), mat="Wall_Cream")
        b.box((L + 0.3, D + cor + 0.3, 0.22), loc=(0, -cor / 2, z0 + H + 0.11),
              mat="Trim_White")             # slab
        for i in range(6):                    # classrooms: door + 2 windows
            x = -L / 2 + 1.5 + i * 3.0
            _door(b, (x - 0.7, -D / 2, z0), w=0.9, h=2.1)
            _window(b, (x + 0.55, -D / 2, z0 + 1.55), w=1.1, h=1.2)
            _window(b, (x, D / 2, z0 + 1.6), w=1.6, h=1.3, face="+Y")
        for x in [-L / 2 + 0.15 + i * (L - 0.3) / 6 for i in range(7)]:
            b.box((0.30, 0.30, H), loc=(x, -D / 2 - cor + 0.2, z0 + H / 2), mat="Trim_White")
        if fl == 1:                           # balcony rail
            b.box((L, 0.12, 0.10), loc=(0, -D / 2 - cor + 0.2, z0 + 1.0), mat="Trim_White")
            for i in range(int(L / 0.35)):
                b.box((0.05, 0.05, 0.9), loc=(-L / 2 + 0.2 + i * 0.35, -D / 2 - cor + 0.2,
                                               z0 + 0.5), mat="Roof_Red")
        for s in (1, -1):
            _window(b, (s * L / 2, 0.8, z0 + 1.6), w=1.2, h=1.2, face="+X" if s > 0 else "-X")
    top = 0.45 + 2 * H + 0.22
    b.hip_roof(L + 1.4, D + cor + 1.4, 2.6, loc=(0, -cor / 2, top), mat="Roof_Red")
    # school name board (add Khmer text texture in Unity with TextMeshPro)
    b.box((5.0, 0.15, 0.9), loc=(0, -D / 2 - cor - 0.05, top - 0.75), mat="Sign_Blue",
          bevel=0.04)
    b.box((5.2, 0.12, 1.0), loc=(0, -D / 2 - cor + 0.02, top - 0.75), mat="Trim_White")
    # flagpole + flag (simple stripes)
    fx, fy = 0, -D / 2 - cor - 6.0
    b.cyl(0.6, 0.6, 0.4, loc=(fx, fy, 0.2), mat="Concrete", seg=8)
    b.cyl(0.05, 0.04, 8.0, loc=(fx, fy, 4.2), mat="Metal", seg=8)
    for z, h, m in ((7.35, 0.25, "Sign_Blue"), (7.0, 0.45, "Tail_Light"), (6.65, 0.25, "Sign_Blue")):
        b.box((1.5, 0.02, h), loc=(fx + 0.8, fy, z + 0.4), mat=m)
    # front wall + gate
    wy = -D / 2 - cor - 9.0
    for s in (1, -1):
        b.box((L / 2 - 2.0, 0.25, 1.4), loc=(s * (L / 4 + 1.0 + 0.5), wy, 0.7), mat="Wall_Cream")
        b.box((0.5, 0.5, 2.2), loc=(s * 2.2, wy, 1.1), mat="Trim_White", bevel=0.04)
        b.box((0.65, 0.65, 0.2), loc=(s * 2.2, wy, 2.3), mat="Roof_Red")
    b.box((4.6, 0.6, 0.35), loc=(0, wy, 2.75), mat="Sign_Blue", bevel=0.05)
    return b.to_object(cat_coll("Buildings"), category="Buildings")


def build_stilt_house(wall="Wood", roof="Roof_Terracotta", name="BLD_StiltHouse"):
    """Traditional Khmer wooden house on stilts (ផ្ទះឈើ), hammock underneath."""
    b = Builder(name, seed=7)
    L, D, post_h = 8.0, 5.5, 2.4
    for x in (-L / 2 + 0.2, -L / 6, L / 6, L / 2 - 0.2):
        for y in (-D / 2 + 0.2, 0, D / 2 - 0.2):
            b.box((0.22, 0.22, post_h + 0.1), loc=(x, y, (post_h + 0.1) / 2), mat="Wood_Dark")
            b.cyl(0.2, 0.2, 0.15, loc=(x, y, 0.075), mat="Concrete", seg=6)
    b.box((L + 0.3, D + 0.3, 0.2), loc=(0, 0, post_h + 0.1), mat="Wood_Dark")
    wall_h = 2.6
    z0 = post_h + 0.2
    b.box((L, D, wall_h), loc=(0, 0, z0 + wall_h / 2), mat=wall)
    for i in range(int(L / 0.5)):  # plank lines
        b.box((0.03, D + 0.02, wall_h - 0.1), loc=(-L / 2 + 0.25 + i * 0.5, 0, z0 + wall_h / 2),
              mat="Wood_Dark")
    for x in (-2.4, 2.4):
        _window(b, (x, -D / 2 - 0.02, z0 + 1.4), w=1.0, h=1.1, frame="Wood_Light",
                glass="Wood_Dark")
        for s in (1, -1):  # open shutters
            b.box((0.5, 0.05, 1.1), loc=(x + s * 0.8, -D / 2 - 0.1, z0 + 1.4), mat="Wood_Light")
    _door(b, (0, -D / 2 - 0.02, z0), w=1.1, h=2.0, mat="Wood_Light")
    # veranda + stairs
    b.box((3.0, 1.4, 0.15), loc=(0, -D / 2 - 0.7, z0 - 0.08), mat="Wood_Dark")
    for s in (1, -1):
        b.box((0.08, 0.08, 1.0), loc=(s * 1.45, -D / 2 - 1.35, z0 + 0.45), mat="Wood_Dark")
    b.box((3.0, 0.08, 0.08), loc=(0, -D / 2 - 1.35, z0 + 0.9), mat="Wood_Dark")
    steps = 8
    for i in range(steps):
        z = z0 - (i + 1) * (z0 / (steps + 1))
        b.box((1.0, 0.32, 0.06), loc=(1.0, -D / 2 - 1.55 - i * 0.28, z), mat="Wood_Light")
    for s in (1, -1):
        b.cyl_between(V(1.0 + 0.55 * s, -D / 2 - 1.4, z0), V(1.0 + 0.55 * s, -D / 2 - 1.55 - steps * 0.28, 0),
                      0.05, mat="Wood_Dark", seg=4)
    # steep Khmer gable roof with gable fins
    b.gable_roof(L, D, 3.0, loc=(0, 0, z0 + wall_h), mat=roof, overhang=0.7)
    for s in (1, -1):
        b.prism([(-D / 2, 0), (0, 2.85), (D / 2, 0)], 0.15, matrix=T((s * (L / 2 + 0.05), 0, z0 + wall_h), (90, 0, 90)),
                mat=wall)
        b.cyl(0.0, 0.08, 0.6, loc=(s * (L / 2 + 0.75), 0, z0 + wall_h + 3.25), rot=(0, -25 * s, 0),
              mat="Gold", seg=6)   # small finials
    # hammock + water jar under the house
    hz = 1.0
    pts = []
    for i in range(9):
        t = i / 8
        pts.append(V(-L / 6 + 0.2 + t * (L / 3 - 0.4), 0.0, hz + 0.35 - 0.5 * math.sin(math.pi * t)))
    for p1, p2 in zip(pts, pts[1:]):
        b.cyl_between(p1, p2, 0.12, mat="Tarp_Blue", seg=6)
    b.lathe([(0.0, 0.0), (0.30, 0.05), (0.42, 0.35), (0.36, 0.70), (0.22, 0.80), (0.25, 0.86)],
            loc=(L / 2 - 0.9, -D / 2 + 0.8, 0), mat="Clay", seg=12, cap_top=True)
    return b.to_object(cat_coll("Buildings"), category="Buildings")


def build_shophouse(color="Wall_Mint", name=None, floors=3):
    """Narrow Phnom Penh shophouse (ផ្ទះល្វែង): rolling shutter, balconies."""
    b = Builder(name or "BLD_Shophouse_" + color.split("_")[1])
    W, D, FH = 4.4, 10.0, 3.2
    for f in range(floors):
        z0 = f * FH
        b.box((W, D, FH), loc=(0, 0, z0 + FH / 2), mat=color)
        b.box((W + 0.1, D + 0.1, 0.18), loc=(0, 0, z0 + FH), mat="Trim_White")
        if f == 0:
            b.box((W - 0.6, 0.05, 2.6), loc=(0, -D / 2 - 0.03, 1.3), mat="Shutter_Grey")
            for i in range(14):
                b.box((W - 0.6, 0.06, 0.03), loc=(0, -D / 2 - 0.05, 0.1 + i * 0.18), mat="Concrete_Dark")
            b.box((W + 0.4, 1.4, 0.08), loc=(0, -D / 2 - 0.7, 2.95), mat="Tarp_Blue")  # awning
            b.box((W, 0.25, 0.7), loc=(0, -D / 2 - 0.15, 2.6 + 0.35 + 0.35), mat="Sign_Blue")
        else:
            b.box((W, 1.0, 0.15), loc=(0, -D / 2 - 0.5, z0 + 0.075), mat="Trim_White")
            b.box((W, 0.08, 0.08), loc=(0, -D / 2 - 0.96, z0 + 1.05), mat="Metal_Dark")
            for i in range(12):
                b.box((0.04, 0.04, 0.95), loc=(-W / 2 + 0.15 + i * 0.37, -D / 2 - 0.96, z0 + 0.55),
                      mat="Metal_Dark")
            _door(b, (-0.9, -D / 2, z0 + 0.15), w=1.2, h=2.3, mat="Glass")
            _window(b, (1.0, -D / 2, z0 + 1.6), w=1.4, h=1.3)
            b.box((0.8, 0.35, 0.5), loc=(1.4, -D / 2 - 0.2, z0 + 2.7), mat="Wall_White",
                  bevel=0.03)  # AC unit
    top = floors * FH
    b.box((W + 0.1, D + 0.1, 0.9), loc=(0, 0, top + 0.45), mat=color)
    b.box((W - 0.4, D - 0.4, 0.92), loc=(0, 0, top + 0.47), mat="Concrete")
    b.box((W + 0.2, 0.25, 0.25), loc=(0, -D / 2 - 0.05, top + 0.85), mat="Trim_White")
    b.cyl(0.45, 0.45, 1.0, loc=(1.2, 2.5, top + 1.0), mat="Wall_White", seg=10)  # water tank
    return b.to_object(cat_coll("Buildings"), category="Buildings")


def build_pagoda():
    """Wat / pagoda hall with tiered saffron roof and gold chovear finials.
    Shown respectfully as a landmark (GDD 9.3)."""
    b = Builder("BLD_Pagoda", seed=11)
    L, D = 14.0, 8.0
    for i, (dl, h) in enumerate(((3.0, 0.5), (2.0, 0.5), (1.0, 0.5))):
        b.box((L + dl * 2, D + dl * 2, h), loc=(0, 0, i * 0.5 + h / 2), mat="Wall_White")
    b.box((3.5, 3.0, 1.5), loc=(0, -D / 2 - 3.6, 0.75), mat="Wall_White")   # front stair block
    for i in range(5):
        b.box((3.0, 0.35, 0.3), loc=(0, -D / 2 - 5.1 - i * 0.35, 1.35 - i * 0.3), mat="Concrete")
    for s in (1, -1):  # naga balustrades (simplified)
        b.cyl_between(V(1.7 * s, -D / 2 - 6.9, 0.6), V(1.7 * s, -D / 2 - 2.6, 1.9), 0.18,
                      mat="Gold", seg=8)
        b.sphere(0.32, loc=(1.7 * s, -D / 2 - 7.0, 0.85), scale=(0.8, 1, 1.3), mat="Gold", seg=8, rings=6)
    z0 = 1.5
    H = 4.2
    b.box((L, D, H), loc=(0, 0, z0 + H / 2), mat="Wall_Cream")
    for i in range(8):   # colonnade
        x = -L / 2 - 0.6 + i * (L + 1.2) / 7
        for y in (-D / 2 - 0.9, D / 2 + 0.9):
            b.cyl(0.25, 0.22, H, loc=(x, y, z0 + H / 2), mat="Wall_White", seg=8)
            b.cyl(0.32, 0.32, 0.3, loc=(x, y, z0 + H - 0.1), mat="Gold", seg=8)
    for x in (-4.5, -1.5, 1.5, 4.5):
        _window(b, (x, -D / 2, z0 + 2.2), w=1.0, h=1.8, frame="Gold", glass="Door_Brown")
    _door(b, (0, -D / 2, z0), w=1.6, h=3.0, mat="Roof_Red")
    # tiered roof: two overlapping gables + lower skirt hip
    top = z0 + H
    b.hip_roof(L + 3.4, D + 3.4, 1.4, loc=(0, 0, top - 0.2), mat="Roof_Saffron", thick=0.15)
    b.gable_roof(L - 1.0, D, 4.2, loc=(0, 0, top + 0.9), mat="Roof_Saffron", overhang=0.6, thick=0.18)
    b.gable_roof(L - 4.0, D - 1.0, 3.6, loc=(0, 0, top + 2.4), mat="Roof_Red", overhang=0.4, thick=0.18)
    # gold ridge + chovear horns at the gable ends
    b.box((L - 3.0, 0.18, 0.25), loc=(0, 0, top + 2.4 + 3.55), mat="Gold")
    for s in (1, -1):
        ex = s * ((L - 4.0) / 2 + 0.4)
        b.cyl_between(V(ex, 0, top + 5.9), V(ex + s * 0.5, 0, top + 7.0), 0.12, 0.02,
                      mat="Gold", seg=6)
        ex2 = s * ((L - 1.0) / 2 + 0.6)
        b.cyl_between(V(ex2, 0, top + 4.95), V(ex2 + s * 0.45, 0, top + 5.9), 0.12, 0.02,
                      mat="Gold", seg=6)
        for yy in (1, -1):   # eave curls
            b.cyl_between(V(s * (L / 2 + 1.7), yy * (D / 2 + 1.7), top - 0.3),
                          V(s * (L / 2 + 2.1), yy * (D / 2 + 2.1), top + 0.4), 0.1, 0.02,
                          mat="Gold", seg=5)
        # gable face (pediment) in gold
        b.prism([(-(D) / 2, 0), (0, 4.0), (D / 2, 0)], 0.1,
                matrix=T((s * ((L - 1.0) / 2 + 0.55), 0, top + 0.9), (90, 0, 90)), mat="Gold")
    b.cyl(0.25, 0.0, 2.2, loc=(0, 0, top + 7.2), mat="Gold", seg=8)   # spire
    return b.to_object(cat_coll("Buildings"), category="Buildings")


def build_market_stall(tarp="Tarp_Red", name=None, seed=3):
    b = Builder(name or "BLD_MarketStall_" + tarp.split("_")[1], seed=seed)
    W, D = 2.6, 2.0
    b.box((W, D * 0.6, 0.08), loc=(0, -0.2, 0.85), mat="Wood_Light")
    b.box((W, 0.05, 0.75), loc=(0, -0.2 - D * 0.3, 0.45), mat="Wood")
    for x in (-W / 2 + 0.05, W / 2 - 0.05):
        for y in (-D / 2, D / 2):
            b.cyl(0.03, 0.03, 2.3 if y < 0 else 2.0, loc=(x, y, (2.3 if y < 0 else 2.0) / 2),
                  mat="Metal", seg=6)
    # sloped tarp with alternating stripe faces
    t = b._tbm()
    n = 6
    vs = []
    for i in range(n + 1):
        x = -W / 2 - 0.15 + (W + 0.3) * i / n
        vs.append((t.verts.new((x, -D / 2 - 0.4, 2.2)), t.verts.new((x, D / 2 + 0.15, 1.95))))
    for i in range(n):
        t.faces.new((vs[i][0], vs[i + 1][0], vs[i + 1][1], vs[i][1]))
    bmesh.ops.solidify(t, geom=list(t.faces), thickness=0.03) if hasattr(bmesh.ops, "solidify") else None
    b._merge(t, tarp, mats=lambda i: tarp if (i % 2 == 0) else "Trim_White")
    # produce baskets
    fruits = ["Fruit_Orange", "Fruit_Green", "Fruit_Red", "Fruit_Yellow"]
    for k, x in enumerate((-0.85, -0.28, 0.28, 0.85)):
        b.lathe([(0.0, 0.0), (0.2, 0.0), (0.26, 0.14)], loc=(x, -0.2, 0.89), mat="Wood_Light",
                seg=10, cap_top=False)
        for j in range(6):
            a = j * math.pi / 3
            b.ico(0.06, loc=(x + 0.1 * math.cos(a), -0.2 + 0.1 * math.sin(a), 1.02),
                  mat=fruits[(k + seed) % 4], subdiv=1)
        b.ico(0.06, loc=(x, -0.2, 1.08), mat=fruits[(k + seed) % 4], subdiv=1)
    b.box((0.5, 0.4, 0.3), loc=(0.7, 0.6, 0.15), mat="Plastic_Blue")   # crate
    return b.to_object(cat_coll("Buildings"), category="Buildings")


def build_coffee_stall():
    """Street coffee cart with umbrella and plastic stools."""
    b = Builder("BLD_CoffeeStall", seed=5)
    b.box((1.4, 0.7, 0.85), loc=(0, 0, 0.6), mat="Wall_White", bevel=0.03)
    b.box((1.5, 0.75, 0.06), loc=(0, 0, 1.05), mat="Metal")
    b.box((1.3, 0.02, 0.35), loc=(0, -0.36, 0.7), mat="Coffee")   # sign panel
    for x in (-0.55, 0.55):
        b.torus(0.13, 0.04, loc=(x, -0.30, 0.17), rot=(90, 0, 0), mat="Rubber", seg=10, ring=4)
    for i, (c, x) in enumerate((("Bottle", -0.45), ("Ice", -0.15), ("Coffee", 0.15), ("Bottle_Cap", 0.45))):
        b.cyl(0.08, 0.08, 0.25, loc=(x, 0.1, 1.21), mat=c, seg=8)
    b.cyl(0.03, 0.03, 2.2, loc=(0.6, 0.2, 1.1), mat="Metal", seg=6)
    b.lathe([(1.25, 2.05), (0.0, 2.45)], loc=(0.6, 0.2, 0), seg=8, mat="Tarp_Yellow",
            mats=lambda i, j: "Tarp_Yellow" if i % 2 == 0 else "Tarp_Red", cap_bottom=True, cap_top=False)
    for x, y, c in ((-0.8, -1.1, "Plastic_Red"), (0.2, -1.3, "Plastic_Blue"), (1.1, -0.9, "Plastic_Red")):
        _stool(b, (x, y, 0), c)
    return b.to_object(cat_coll("Buildings"), category="Buildings")


def _stool(b, loc, col):
    x, y, z = loc
    b.lathe([(0.15, z + 0.0), (0.13, z + 0.40), (0.155, z + 0.42), (0.155, z + 0.45)],
            loc=(x, y, 0), mat=col, seg=10)


# =============================================================================
#  NATURE & GROUND TILES
# =============================================================================
def build_sugar_palm(name="ENV_SugarPalm", seed=1, h=9.0):
    """Sugar palm (ដើមត្នោត) - Cambodia's national tree."""
    b = Builder(name, seed=seed)
    r = b.rng
    pts = [V(0, 0, 0)]
    for i in range(1, 7):
        pts.append(V(r.uniform(-0.06, 0.06) * i * 0.4, r.uniform(-0.06, 0.06) * i * 0.4, h * i / 6))
    for i, (p1, p2) in enumerate(zip(pts, pts[1:])):
        b.cyl_between(p1, p2, 0.30 - i * 0.025, 0.28 - (i + 1) * 0.025, mat="Trunk_Palm", seg=8)
    top = pts[-1]
    b.ico(0.75, loc=top + V(0, 0, -0.3), scale=(1, 1, 1.3), mat="Leaf_Dry", subdiv=1, jitter=0.25)
    n = 16
    for i in range(n):
        az = 2 * math.pi * i / n + r.uniform(-0.15, 0.15)
        el = math.radians(r.uniform(-25, 55)) if i % 2 else math.radians(r.uniform(10, 70))
        d = V(math.cos(az) * math.cos(el), math.sin(az) * math.cos(el), math.sin(el))
        stem_end = top + d * 1.5
        b.cyl_between(top, stem_end, 0.04, 0.03, mat="Trunk", seg=4)
        # fan leaf: a pleated half-disc facing outward
        fan = []
        k = 9
        side = d.cross(V(0, 0, 1))
        if side.length < 1e-3:
            side = V(1, 0, 0)
        side.normalize()
        up = side.cross(d).normalized()
        center = stem_end + d * 0.15
        fan_v = [center]
        for j in range(k + 1):
            a = math.pi * j / k - math.pi / 2
            rr = 1.25 * (1.0 if j % 2 == 0 else 0.85)
            p = center + (d * math.cos(a) + side * math.sin(a)) * rr + up * (0.12 if j % 2 else -0.05)
            fan_v.append(p)
        faces = [(0, j, j + 1) for j in range(1, k + 1)]
        b.custom([tuple(v) for v in fan_v], faces, mat="Leaf_Palm")
        b.custom([tuple(v) for v in fan_v], [tuple(reversed(f)) for f in faces], mat="Leaf_Palm")
    for j in range(5):   # fruit cluster
        b.ico(0.12, loc=top + V(r.uniform(-0.4, 0.4), r.uniform(-0.4, 0.4), -0.6), mat="Wood_Dark")
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_coconut_palm(name="ENV_CoconutPalm", seed=2, h=7.0):
    b = Builder(name, seed=seed)
    r = b.rng
    lean = V(r.uniform(-1, 1), r.uniform(-1, 1), 0).normalized() * 1.2
    prev = V(0, 0, 0)
    for i in range(1, 9):
        t = i / 8
        p = lean * t * t + V(0, 0, h * t)
        b.cyl_between(prev, p, 0.22 - 0.012 * i, 0.21 - 0.012 * (i + 1), mat="Trunk", seg=7)
        b.torus(0.20 - 0.012 * i, 0.025, loc=p, mat="Trunk_Palm", seg=7, ring=3,
                rot=(0, 0, 0))
        prev = p
    top = prev
    for i in range(10):
        az = 2 * math.pi * i / 10 + r.uniform(-0.1, 0.1)
        L = r.uniform(2.6, 3.4)
        seg = 6
        d = V(math.cos(az), math.sin(az), 0)
        side = V(-d.y, d.x, 0)
        verts, faces = [], []
        for j in range(seg + 1):
            t = j / seg
            c = top + d * (L * t) + V(0, 0, 0.9 * math.sin(math.pi * t * 0.8) - 1.6 * t * t)
            w = 0.45 * math.sin(math.pi * min(t * 1.1, 1.0)) + 0.02
            verts += [tuple(c - side * w + V(0, 0, -0.1)), tuple(c), tuple(c + side * w + V(0, 0, -0.1))]
        for j in range(seg):
            a = j * 3
            faces += [(a, a + 3, a + 4, a + 1), (a + 1, a + 4, a + 5, a + 2)]
        b.custom(verts, faces, mat="Leaf" if i % 2 else "Leaf_Palm")
        b.custom(verts, [tuple(reversed(f)) for f in faces], mat="Leaf" if i % 2 else "Leaf_Palm")
    for j in range(4):
        b.ico(0.16, loc=top + V(r.uniform(-0.25, 0.25), r.uniform(-0.25, 0.25), -0.25),
              mat="Fruit_Green", subdiv=1)
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_tree(name="ENV_Tree", seed=3, h=4.5, leaf="Leaf"):
    b = Builder(name, seed=seed)
    r = b.rng
    b.cyl(0.25, 0.16, h * 0.55, loc=(0, 0, h * 0.275), mat="Trunk", seg=7)
    for i in range(5):
        a = i * 2 * math.pi / 5
        rr = 1.0 if i else 0.0
        p = V(math.cos(a) * rr, math.sin(a) * rr, h * 0.7 + r.uniform(-0.2, 0.4)) if i else V(0, 0, h * 0.9)
        b.ico(r.uniform(1.1, 1.5), loc=p, scale=(1, 1, 0.8), mat=leaf if i % 2 else "Leaf_Dark",
              subdiv=1, jitter=0.15)
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_bush(name="ENV_Bush", seed=4, flowers=True):
    b = Builder(name, seed=seed)
    r = b.rng
    blobs = []
    for i in range(4):
        c = V(r.uniform(-0.4, 0.4), r.uniform(-0.3, 0.3), 0.35)
        rad = r.uniform(0.35, 0.55)
        blobs.append((c, rad))
        b.ico(rad, loc=c, scale=(1, 1, 0.8), mat="Leaf" if i % 2 else "Leaf_Dark", subdiv=1,
              jitter=0.15)
    if flowers:
        for i in range(10):
            c, rad = blobs[i % 4]
            a, e = r.uniform(0, 2 * math.pi), r.uniform(0.1, 1.1)
            d = V(math.cos(a) * math.cos(e), math.sin(a) * math.cos(e), math.sin(e) * 0.8)
            b.ico(0.06, loc=c + d * rad * 0.92, mat="Flower_Pink" if i % 2 else "Flower_Yellow",
                  subdiv=1)
    return b.to_object(cat_coll("Nature"), category="Nature")


TILE = 10.0   # all ground tiles are 10 x 10 m and snap together


def build_tile_grass():
    b = Builder("ENV_Tile_Grass", seed=8)
    b.box((TILE, TILE, 0.2), loc=(0, 0, -0.1), mat="Grass")
    r = b.rng
    for i in range(10):   # grass clumps
        b.ico(0.15, loc=(r.uniform(-4.5, 4.5), r.uniform(-4.5, 4.5), 0.02), scale=(1, 1, 0.5),
              mat="Grass_Dark", subdiv=1, jitter=0.3)
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_tile_road(kind="asphalt"):
    """Straight road tile along Y: 6 m carriageway + dirt shoulders."""
    b = Builder("ENV_Tile_Road_" + kind.capitalize())
    b.box((TILE, TILE, 0.2), loc=(0, 0, -0.1), mat="Grass")
    if kind == "asphalt":
        b.box((6.0, TILE, 0.22), loc=(0, 0, -0.09), mat="Asphalt")
        b.box((1.0, TILE, 0.21), loc=(-3.5, 0, -0.095), mat="Laterite")
        b.box((1.0, TILE, 0.21), loc=(3.5, 0, -0.095), mat="Laterite")
        for i in range(4):
            b.box((0.15, 1.4, 0.23), loc=(0, -3.75 + i * 2.5, -0.09), mat="Road_Line")
    else:   # red laterite village road
        b.box((4.0, TILE, 0.22), loc=(0, 0, -0.09), mat="Laterite")
        for s in (1, -1):
            b.box((0.5, TILE, 0.215), loc=(s * 1.0, 0, -0.088), mat="Dirt")
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_tile_rice():
    """Rice paddy tile with laterite dykes and rows of rice."""
    b = Builder("ENV_Tile_RicePaddy", seed=9)
    b.box((TILE, TILE, 0.2), loc=(0, 0, -0.25), mat="Rice_Water")
    for s in (1, -1):
        b.box((TILE, 0.6, 0.35), loc=(0, s * (TILE / 2 - 0.3), -0.05), mat="Laterite", bevel=0.1)
        b.box((0.6, TILE, 0.35), loc=(s * (TILE / 2 - 0.3), 0, -0.05), mat="Laterite", bevel=0.1)
    for i in range(14):
        x = -4.2 + i * 0.65
        b.box((0.28, TILE - 1.6, 0.42), loc=(x, 0, 0.0), mat="Rice", bevel=0.1)
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_tile_river():
    """Mekong river tile (flows along X) with sloped banks."""
    b = Builder("ENV_Tile_River")
    b.box((TILE, TILE, 0.2), loc=(0, 0, -1.3), mat="Water_Deep")
    b.box((TILE, 7.0, 0.05), loc=(0, 0, -0.35), mat="Water")
    for s in (1, -1):
        b.prism_x([(s * 3.5, -1.2), (s * 5.0, 0.0), (s * 5.0, -1.2)] if s > 0 else
                  [(s * 5.0, -1.2), (s * 5.0, 0.0), (s * 3.5, -1.2)], TILE, mat="Dirt")
    return b.to_object(cat_coll("Nature"), category="Nature")


def build_bridge():
    """Simple river bridge span (fits 1 river tile, 10 m)."""
    b = Builder("BLD_Bridge")
    b.box((7.0, 12.0, 0.5), loc=(0, 0, 1.2), mat="Concrete")
    b.box((6.0, 12.0, 0.05), loc=(0, 0, 1.47), mat="Asphalt")
    for s in (1, -1):
        b.box((0.25, 12.0, 0.9), loc=(s * 3.4, 0, 1.9), mat="Trim_White")
        for y in (-3.0, 3.0):
            b.box((1.2, 1.2, 2.5), loc=(s * 2.2, y, -0.1), mat="Concrete_Dark")
        for y in range(-5, 6, 2):
            b.cyl(0.05, 0.05, 1.2, loc=(s * 3.4, y, 2.9), mat="Metal", seg=6)
            b.sphere(0.12, loc=(s * 3.4, y, 3.55), mat="Light_Lens", seg=8, rings=5)
    return b.to_object(cat_coll("Buildings"), category="Buildings")


# =============================================================================
#  PROPS  (also rendered as 2D inventory icons)
# =============================================================================
def build_props():
    out = []
    C = cat_coll("Props")

    b = Builder("PRP_Backpack")
    b.box((0.30, 0.16, 0.40), loc=(0, 0, 0.22), mat="Backpack_Black", bevel=0.05, seg=2)
    b.box((0.22, 0.06, 0.16), loc=(0, -0.10, 0.15), mat="Backpack_Black", bevel=0.025)
    b.box((0.17, 0.01, 0.01), loc=(0, -0.13, 0.20), mat="Metal")
    b.torus(0.05, 0.012, loc=(0, 0.0, 0.44), rot=(90, 0, 0), arc=180, mat="Backpack_Black", seg=8, ring=4)
    for s in (1, -1):
        b.box((0.04, 0.03, 0.34), loc=(0.09 * s, 0.095, 0.24), mat="Backpack_Black", bevel=0.01)
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_Phone")
    b.box((0.075, 0.009, 0.155), loc=(0, 0, 0.0775), mat="Phone_Body", bevel=0.008)
    b.box((0.066, 0.002, 0.140), loc=(0, -0.005, 0.0775), mat="Phone_Screen")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_Wallet")
    b.box((0.11, 0.025, 0.09), loc=(0, 0, 0.045), mat="Wallet", bevel=0.008)
    b.box((0.112, 0.026, 0.03), loc=(0, 0, 0.065), mat="Strap_Brown")
    b.box((0.012, 0.03, 0.012), loc=(0.045, -0.002, 0.065), mat="Gold")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_Notebook")
    b.box((0.17, 0.23, 0.025), loc=(0, 0, 0.0125), mat="Book_Teal", bevel=0.004)
    b.box((0.16, 0.22, 0.018), loc=(0.006, 0, 0.0125), mat="Wall_White")
    b.box((0.015, 0.232, 0.027), loc=(-0.078, 0, 0.0125), mat="Book_Blue")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_WaterBottle")
    b.lathe([(0.0, 0.0), (0.035, 0.0), (0.037, 0.02), (0.035, 0.15), (0.033, 0.17),
             (0.015, 0.20), (0.015, 0.215)], mat="Bottle", seg=12, smooth=True)
    b.cyl(0.017, 0.017, 0.022, loc=(0, 0, 0.225), mat="Bottle_Cap", seg=10)
    b.cyl(0.0375, 0.0375, 0.05, loc=(0, 0, 0.09), mat="Plastic_Blue", seg=12)
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_Laptop")
    b.box((0.32, 0.22, 0.015), loc=(0, 0, 0.0075), mat="Laptop_Silver", bevel=0.004)
    b.box((0.28, 0.12, 0.002), loc=(0, -0.01, 0.016), mat="Phone_Body")
    b.box((0.32, 0.012, 0.21), loc=(0, 0.115, 0.11), rot=(-15, 0, 0), mat="Laptop_Silver", bevel=0.004)
    b.box((0.29, 0.002, 0.18), loc=(0, 0.107, 0.112), rot=(-15, 0, 0), mat="Phone_Screen")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_IcedCoffee")
    b.lathe([(0.0, 0.0), (0.032, 0.0), (0.045, 0.14)], mat="Ice", seg=12, cap_top=False)
    b.lathe([(0.0, 0.002), (0.031, 0.002), (0.042, 0.10), (0.0, 0.10)], mat="Coffee", seg=12)
    b.lathe([(0.0, 0.10), (0.042, 0.10), (0.044, 0.125), (0.0, 0.125)], mat="Coffee_Milk", seg=12)
    b.cyl_between(V(0, 0, 0.05), V(0.012, -0.01, 0.20), 0.004, mat="Plastic_Green", seg=6)
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_PlasticStool")
    _stool(b, (0, 0, 0), "Plastic_Red")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_Helmet")
    b.sphere(0.15, loc=(0, 0, 0.0), scale=(1, 1.15, 1), mat="Helmet", seg=14, rings=10, smooth=True)
    b.lathe([(0.152, 0.0), (0.152, 0.012)], scale=(1, 1.15, 1), mat="Visor", seg=14)
    b.box((0.20, 0.025, 0.09), loc=(0, -0.168, 0.06), rot=(-18, 0, 0), mat="Visor", bevel=0.01)
    b.box((0.035, 0.30, 0.01), loc=(0, 0.0, 0.148), mat="Moto_Red")
    out_obj = b.to_object(C, category="Props")
    for v in out_obj.data.vertices:      # flatten the open bottom onto the ground
        v.co.z = max(v.co.z, 0.0)
    out.append(out_obj)

    b = Builder("PRP_Krama")
    # checked Khmer scarf, folded flat: grid with alternating face colours
    n, m = 8, 4
    verts, faces = [], []
    for j in range(m + 1):
        for i in range(n + 1):
            verts.append((-0.25 + 0.5 * i / n, -0.12 + 0.24 * j / m, 0.02 + 0.006 * math.sin(i)))
    for j in range(m):
        for i in range(n):
            a = j * (n + 1) + i
            faces.append((a, a + 1, a + n + 2, a + n + 1))
    t = b._tbm()
    vs = [t.verts.new(v) for v in verts]
    for f in faces:
        t.faces.new([vs[k] for k in f])
    b._merge(t, "Krama_Red", mats=lambda k: "Krama_White" if ((k % n) + (k // n)) % 2 else "Krama_Red")
    b.box((0.5, 0.24, 0.018), loc=(0, 0, 0.009), mat="Krama_Red")
    for i in range(9):   # fringe
        b.box((0.008, 0.04, 0.004), loc=(0.25 + 0.02, -0.11 + i * 0.0275, 0.018), mat="Krama_White")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_NoodleBowl")   # num banh chok
    b.lathe([(0.0, 0.0), (0.05, 0.0), (0.05, 0.012), (0.12, 0.09), (0.11, 0.09), (0.045, 0.02), (0.0, 0.02)],
            mat="Bowl", seg=16, mats=lambda i, j: "Bowl_Blue" if j == 3 else "Bowl")
    b.cyl(0.105, 0.105, 0.01, loc=(0, 0, 0.075), mat="Fruit_Yellow", seg=16)
    for i in range(10):
        a = i * 0.7
        b.torus(0.03, 0.006, loc=(0.05 * math.cos(a), 0.05 * math.sin(a), 0.082), mat="Noodle",
                seg=8, ring=3)
    for i in range(5):
        b.box((0.03, 0.012, 0.004), loc=(0.06 * math.cos(i * 1.3), 0.06 * math.sin(i * 1.3), 0.088),
              rot=(0, 0, i * 40), mat="Leaf")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_RiceSack")
    b.lathe([(0.0, 0.0), (0.2, 0.0), (0.23, 0.15), (0.22, 0.45), (0.12, 0.55), (0.04, 0.6), (0.0, 0.62)],
            mat="Rice_Sack", seg=10, scale=(1, 0.7, 1))
    b.box((0.25, 0.01, 0.15), loc=(0, -0.16, 0.28), mat="Moto_Red")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_Money")    # stack of USD notes
    for i in range(5):
        b.box((0.156, 0.066, 0.004), loc=(0, 0, 0.002 + i * 0.004), rot=(0, 0, i * 3 - 6),
              mat="Fruit_Green" if i % 2 else "UI_Money")
    b.box((0.03, 0.068, 0.024), loc=(0, 0, 0.01), mat="Wall_White")
    out.append(b.to_object(C, category="Props"))

    b = Builder("PRP_MotoKey")
    b.box((0.03, 0.012, 0.035), loc=(0, 0, 0.02), mat="Seat_Black", bevel=0.006)
    b.box((0.01, 0.004, 0.05), loc=(0, 0, 0.06), mat="Metal")
    b.torus(0.02, 0.003, loc=(0, 0, -0.005), rot=(90, 0, 0), mat="Metal", seg=10, ring=3)
    out.append(b.to_object(C, category="Props"))
    return out


# =============================================================================
#  2D UI KIT  - flat vector shapes built in Blender and rendered to PNG
#  icon_<name>.png  : coloured glyph (status bars, rewards, inventory tabs)
#  btn_<name>.png   : white glyph on navy rounded tile (HUD side buttons)
#  ui_<panel>.png   : 9-slice panels, buttons, bars (see README for borders)
# =============================================================================
def _heart_pts(n=48, s=1.0, cx=0.0, cy=0.0):
    pts = []
    for i in range(n):
        t = 2 * math.pi * i / n
        x = 16 * math.sin(t) ** 3
        y = 13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)
        pts.append((cx + s * x / 17.0, cy + s * (y + 2.5) / 17.0))
    return pts


def _star_pts(r_out=1.0, r_in=0.45, n=5, cx=0.0, cy=0.0):
    pts = []
    for i in range(n * 2):
        r = r_out if i % 2 == 0 else r_in
        a = math.pi / 2 + i * math.pi / n
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def _line_pts(p1, p2, w):
    (x1, y1), (x2, y2) = p1, p2
    dx, dy = x2 - x1, y2 - y1
    l = math.hypot(dx, dy) or 1
    nx, ny = -dy / l * w / 2, dx / l * w / 2
    return [(x1 + nx, y1 + ny), (x2 + nx, y2 + ny), (x2 - nx, y2 - ny), (x1 - nx, y1 - ny)]


def _thick_line(b, p1, p2, w, z, mat):
    b.poly(_line_pts(p1, p2, w), z=z, mat=mat)
    b.poly(circle_pts(w / 2, 12, *p1), z=z, mat=mat)
    b.poly(circle_pts(w / 2, 12, *p2), z=z, mat=mat)


def _text_glyph(b, text, size, loc, z, mat):
    """Latin text/digits via Blender's built-in font (e.g. '$'). Khmer UI text
    should be rendered in Unity with TextMeshPro + a Khmer font (GDD 13.4)."""
    cu = bpy.data.curves.new("ML_tmp_txt", "FONT")
    cu.body = text
    cu.size = size
    cu.align_x, cu.align_y = "CENTER", "CENTER"
    ob = bpy.data.objects.new("ML_tmp_txt", cu)
    bpy.context.scene.collection.objects.link(ob)
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    t = b._tbm()
    t.from_mesh(me)
    bmesh.ops.transform(t, matrix=Matrix.Translation((loc[0], loc[1], z)), verts=t.verts)
    b._merge(t, mat)
    bpy.data.objects.remove(ob)
    bpy.data.curves.remove(cu)
    bpy.data.meshes.remove(me)


def _g_heart(b, P, S, btn):
    b.poly(_heart_pts(s=0.95, cy=-0.05), z=0.01, mat=P)
    if not btn:
        b.poly(circle_pts(0.13, 12, -0.42, 0.33, sx=1.0, sy=0.75), z=0.02, mat=S)


def _g_smile(b, P, S, btn):
    b.poly(circle_pts(0.92, 40), z=0.01, mat=P)
    for x in (-0.32, 0.32):
        b.poly(circle_pts(0.11, 16, x, 0.22, sx=0.8, sy=1.3), z=0.02, mat=S)
    b.poly(arc_band_pts(0.42, 0.56, 200, 340, 16, 0, 0.0), z=0.02, mat=S)


def _g_skill(b, P, S, btn):
    b.poly([(-0.95, -0.55), (-0.05, -0.75), (-0.05, 0.70), (-0.95, 0.85)], z=0.01, mat=P)
    b.poly([(0.95, -0.55), (0.05, -0.75), (0.05, 0.70), (0.95, 0.85)], z=0.01, mat=P)
    for i in range(3):
        y = 0.40 - i * 0.30
        b.poly(_line_pts((-0.78, y), (-0.22, y - 0.08), 0.08), z=0.02, mat=S)
        b.poly(_line_pts((0.22, y - 0.08), (0.78, y), 0.08), z=0.02, mat=S)


def _ring(b, r_in, r_out, z, mat, n=40, cx=0.0, cy=0.0):
    verts, faces = [], []
    for i in range(n):
        a = 2 * math.pi * i / n
        verts += [(cx + r_in * math.cos(a), cy + r_in * math.sin(a), z),
                  (cx + r_out * math.cos(a), cy + r_out * math.sin(a), z)]
        j = (i + 1) % n
        faces.append((2 * i, 2 * j, 2 * j + 1, 2 * i + 1))
    b.custom(verts, faces, mat=mat)


def _g_money(b, P, S, btn):
    b.poly(circle_pts(0.92, 40), z=0.01, mat=P)
    _ring(b, 0.72, 0.79, 0.02, S)
    _text_glyph(b, "$", 1.15, (0.0, -0.04), 0.03, S)


def _g_energy(b, P, S, btn):
    b.poly([(0.20, 1.0), (-0.62, -0.08), (-0.05, -0.08), (-0.25, -1.0), (0.62, 0.15),
            (0.06, 0.15)], z=0.01, mat=P)


def _g_stress(b, P, S, btn):
    for (x, y, r) in ((-0.42, -0.05, 0.42), (0.05, 0.22, 0.55), (0.48, -0.05, 0.40)):
        b.poly(circle_pts(r, 24, x, y), z=0.01, mat=P)
    b.poly(rounded_rect_pts(1.75, 0.6, 0.3, cy=-0.25), z=0.01, mat=P)
    b.poly([(0.05, -0.15), (-0.18, -0.55), (0.0, -0.55), (-0.12, -0.95), (0.22, -0.42),
            (0.04, -0.42), (0.18, -0.15)], z=0.02, mat=S)


def _g_clock(b, P, S, btn):
    b.poly(circle_pts(0.92, 40), z=0.01, mat=P)
    b.poly(circle_pts(0.74, 40), z=0.02, mat=S)
    _thick_line(b, (0, 0), (0, 0.5), 0.14, 0.03, P)
    _thick_line(b, (0, 0), (0.36, -0.2), 0.14, 0.03, P)


def _g_pin(b, P, S, btn):
    pts = circle_pts(0.62, 30, 0, 0.30, a0=math.radians(-35), a1=math.radians(215), closed=False)
    b.poly(pts + [(0.0, -0.95)], z=0.01, mat=P)
    b.poly(circle_pts(0.26, 20, 0, 0.30), z=0.02, mat=S)


def _g_tasks(b, P, S, btn):
    b.poly(rounded_rect_pts(1.5, 1.85, 0.22), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.6, 0.28, 0.1, cy=0.92), z=0.02, mat=P)
    for i, y in enumerate((0.42, -0.05, -0.52)):
        _thick_line(b, (-0.52, y), (-0.38, y - 0.13), 0.1, 0.02, S)
        _thick_line(b, (-0.38, y - 0.13), (-0.16, y + 0.12), 0.1, 0.02, S)
        _thick_line(b, (0.05, y), (0.5, y), 0.1, 0.02, S)


def _g_phone(b, P, S, btn):
    b.poly(rounded_rect_pts(1.1, 1.95, 0.22), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.88, 1.45, 0.06, cy=0.05), z=0.02, mat=S)
    b.poly(circle_pts(0.08, 12, 0, -0.82), z=0.02, mat=S)


def _g_bag(b, P, S, btn):
    b.poly(arc_band_pts(0.28, 0.42, 0, 180, 14, 0, 0.45), z=0.01, mat=P)
    b.poly(rounded_rect_pts(1.6, 1.35, 0.28, cy=-0.25), z=0.01, mat=P)
    b.poly(rounded_rect_pts(1.6, 0.12, 0.05, cy=0.05), z=0.02, mat=S)
    b.poly(rounded_rect_pts(0.32, 0.26, 0.06, cy=0.05), z=0.03, mat=S)


def _g_home(b, P, S, btn):
    b.poly([(-1.0, 0.05), (0.0, 0.95), (1.0, 0.05), (0.78, 0.05), (0.78, -0.9), (-0.78, -0.9),
            (-0.78, 0.05)], z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.4, 0.6, 0.08, cy=-0.6), z=0.02, mat=S)


def _g_family(b, P, S, btn):
    for (x, s) in ((-0.38, 1.0), (0.45, 0.8)):
        b.poly(circle_pts(0.30 * s, 20, x, 0.42 * s), z=0.01, mat=P)
        b.poly(circle_pts(0.55 * s, 20, x, -0.62 + (1 - s) * 0.2, a0=0, a1=math.pi, closed=False),
               z=0.01, mat=P)


def _g_star(b, P, S, btn):
    b.poly(_star_pts(1.0, 0.45, cy=-0.05), z=0.01, mat=P)


def _g_gear(b, P, S, btn):
    b.poly(circle_pts(0.68, 32), z=0.01, mat=P)
    for i in range(8):
        a = i * 45
        b.poly([(x * math.cos(math.radians(a)) - y * math.sin(math.radians(a)),
                 x * math.sin(math.radians(a)) + y * math.cos(math.radians(a)))
                for x, y in ((0.55, -0.17), (0.95, -0.14), (0.95, 0.14), (0.55, 0.17))],
               z=0.01, mat=P)
    b.poly(circle_pts(0.28, 20), z=0.02, mat=S)


def _g_work(b, P, S, btn):
    b.poly(arc_band_pts(0.22, 0.36, 0, 180, 10, 0, 0.42), z=0.01, mat=P)
    b.poly(rounded_rect_pts(1.8, 1.25, 0.2, cy=-0.25), z=0.01, mat=P)
    b.poly(rounded_rect_pts(1.8, 0.10, 0.03, cy=-0.05), z=0.02, mat=S)
    b.poly(rounded_rect_pts(0.3, 0.24, 0.05, cy=-0.05), z=0.03, mat=P)


def _g_rest(b, P, S, btn):
    b.poly(rounded_rect_pts(1.9, 0.45, 0.1, cy=-0.35), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.2, 1.3, 0.08, -0.85, -0.05), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.6, 0.38, 0.15, -0.38, 0.08), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.15, 0.4, 0.05, 0.85, -0.7), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.15, 0.4, 0.05, -0.85, -0.7), z=0.01, mat=P)


def _g_hobby(b, P, S, btn):   # game controller
    b.poly(rounded_rect_pts(1.9, 1.1, 0.5), z=0.01, mat=P)
    for x in (-0.6, 0.6):
        b.poly(circle_pts(0.42, 20, x, -0.35), z=0.01, mat=P)
    b.poly(rounded_rect_pts(0.42, 0.13, 0.04, -0.5, 0.05), z=0.02, mat=S)
    b.poly(rounded_rect_pts(0.13, 0.42, 0.04, -0.5, 0.05), z=0.02, mat=S)
    for (x, y) in ((0.45, 0.15), (0.65, -0.05)):
        b.poly(circle_pts(0.1, 12, x, y), z=0.02, mat=S)


def _g_community(b, P, S, btn):  # house with heart
    _g_home(b, P, S, True)
    b.poly(_heart_pts(s=0.33, cy=-0.25), z=0.03, mat=S)


ICONS = {
    "health": (_g_heart, "UI_Heart", "UI_White"),
    "happiness": (_g_smile, "UI_Smile", "UI_SmileDark"),
    "skill": (_g_skill, "UI_Skill", "UI_White"),
    "money": (_g_money, "UI_Money", "UI_White"),
    "energy": (_g_energy, "UI_Energy", "UI_White"),
    "stress": (_g_stress, "UI_Stress", "UI_White"),
    "time": (_g_clock, "UI_Navy", "UI_White"),
    "map": (_g_pin, "UI_Red", "UI_White"),
    "tasks": (_g_tasks, "UI_Navy", "UI_White"),
    "phone": (_g_phone, "UI_Navy", "UI_Skill"),
    "inventory": (_g_bag, "UI_Orange", "UI_White"),
    "home": (_g_home, "UI_Navy", "UI_White"),
    "family": (_g_family, "UI_Orange", "UI_White"),
    "reputation": (_g_star, "UI_Energy", "UI_White"),
    "settings": (_g_gear, "UI_Navy", "UI_White"),
    "work": (_g_work, "Sign_Blue", "UI_White"),
    "rest": (_g_rest, "UI_Stress", "UI_White"),
    "hobby": (_g_hobby, "UI_Stress", "UI_White"),
    "community": (_g_community, "UI_Green", "UI_White"),
}

# 9-slice panels: (width, height, radius, fill, border colour or None, border px)
PANELS = {
    "panel_cream": (2.0, 2.0, 0.28, "UI_Cream", "UI_CreamDark", 0.04),
    "panel_white": (2.0, 2.0, 0.28, "UI_White", None, 0),
    "panel_navy": (2.0, 2.0, 0.28, "UI_Navy", None, 0),
    "card_option": (2.0, 2.0, 0.28, "UI_White", "UI_Grey", 0.04),
    "button_green": (2.0, 1.0, 0.5, "UI_Green", None, 0),
    "button_red": (2.0, 1.0, 0.5, "UI_Red", None, 0),
    "button_navy": (2.0, 1.0, 0.5, "UI_Navy", None, 0),
    "bar_bg": (4.0, 1.0, 0.5, "UI_Grey", None, 0),
    "bar_fill_health": (4.0, 1.0, 0.5, "UI_Heart", None, 0),
    "bar_fill_happiness": (4.0, 1.0, 0.5, "UI_Smile", None, 0),
    "bar_fill_skill": (4.0, 1.0, 0.5, "UI_Skill", None, 0),
    "bar_fill_money": (4.0, 1.0, 0.5, "UI_Money", None, 0),
    "bar_fill_energy": (4.0, 1.0, 0.5, "UI_Energy", None, 0),
    "bar_fill_stress": (4.0, 1.0, 0.5, "UI_Stress", None, 0),
    "avatar_frame": (2.0, 2.0, 0.3, "UI_White", None, 0),
}


def build_ui_2d():
    """Create the 2D shapes (kept in ML_UI2D, not exported as FBX)."""
    C = cat_coll("UI2D")
    out = []
    x = 0.0
    for name, (fn, P, S) in ICONS.items():
        for btn in (False, True):
            b = Builder(("UI_Btn_" if btn else "UI_Icon_") + name)
            if btn:
                b.poly(rounded_rect_pts(2.0, 2.0, 0.42), z=0.0, mat="UI_Navy")
                t0 = len(b.bm.verts)
                fn(b, "UI_White", "UI_Navy", True)
                # shrink the glyph to 58% inside the tile
                b.bm.verts.ensure_lookup_table()
                for v in b.bm.verts[t0:]:
                    v.co.x *= 0.58
                    v.co.y *= 0.58
            else:
                fn(b, P, S, False)
            o = b.to_object(C, loc=(x, -40 if btn else -37, 0), category="UI2D")
            o["mylife_export"] = False
            o["mylife_sprite"] = ("btn_" if btn else "icon_") + name
            o["mylife_sprite_size"] = 2.0
            out.append(o)
        x += 2.5
    x = 0.0
    for name, (w, h, r, fill, border, bw) in PANELS.items():
        b = Builder("UI_" + name)
        if border:
            b.poly(rounded_rect_pts(w, h, r, n=8), z=0.0, mat=border)
            b.poly(rounded_rect_pts(w - 2 * bw, h - 2 * bw, r - bw, n=8), z=0.01, mat=fill)
        else:
            b.poly(rounded_rect_pts(w, h, r, n=8), z=0.0, mat=fill)
        o = b.to_object(C, loc=(x, -44, 0), category="UI2D")
        o["mylife_export"] = False
        o["mylife_sprite"] = "ui_" + name
        o["mylife_sprite_wh"] = (w, h)
        out.append(o)
        x += w + 0.5
    return out


# =============================================================================
#  BUILD ALL + LAYOUT
# =============================================================================
def _pack_row(objs, y, gap=1.0):
    x = 0.0
    for o in objs:
        xs = [v[0] for v in o.bound_box]
        w = max(xs) - min(xs)
        o.location = (x - min(xs), y, 0)
        x += w + gap


def build_characters():
    return [build_character(c) for c in CHARACTERS] + [build_chandy()]


def build_vehicles():
    return [build_motorbike("Moto_Red"), build_motorbike("Moto_Blue"), build_remork(),
            build_bicycle()]


def build_buildings():
    return [build_school(), build_stilt_house(),
            build_stilt_house(wall="Wood_Light", roof="Roof_Red", name="BLD_StiltHouse_B"),
            build_shophouse("Wall_Mint"), build_shophouse("Wall_Yellow"),
            build_shophouse("Wall_Peach"), build_shophouse("Wall_Blue"),
            build_pagoda(), build_market_stall("Tarp_Red"),
            build_market_stall("Tarp_Blue", seed=1), build_market_stall("Tarp_Yellow", seed=2),
            build_coffee_stall(), build_bridge()]


def build_nature():
    return [build_sugar_palm(), build_sugar_palm("ENV_SugarPalm_B", seed=5, h=7.5),
            build_coconut_palm(), build_tree(), build_tree("ENV_Tree_B", seed=9, h=3.5),
            build_bush(), build_bush("ENV_Bush_Plain", seed=6, flowers=False),
            build_tile_grass(), build_tile_road("asphalt"), build_tile_road("laterite"),
            build_tile_rice(), build_tile_river()]


BUILDERS = {
    "Characters": (build_characters, 0.0, 0.6),
    "Props": (build_props, -4.0, 0.3),
    "Vehicles": (build_vehicles, -9.0, 1.0),
    "Nature": (build_nature, -22.0, 1.5),
    "Buildings": (build_buildings, -60.0, 4.0),
}


def build_category(cat):
    fn, y, gap = BUILDERS[cat]
    objs = fn()
    _pack_row(objs, y, gap)
    return objs


def build_all():
    out = []
    for cat in BUILDERS:
        out += build_category(cat)
    build_ui_2d()
    return out


# =============================================================================
#  KAMPONG CHAM DEMO SCENE (linked duplicates - edit an asset, scene updates)
# =============================================================================
def _place(src_name, loc, rz=0.0, coll=None, scale=1.0):
    src = bpy.data.objects.get(src_name)
    if src is None:
        return None
    o = src.copy()                       # linked duplicate (shares mesh data)
    o.location = loc
    o.rotation_euler = (0, 0, math.radians(rz))
    o.scale = (scale, scale, scale)
    o["mylife_export"] = False
    coll.objects.link(o)
    for ch in src.children:              # rigs: duplicate the skinned mesh too
        c = ch.copy()
        c.parent = o
        c["mylife_export"] = False
        for m in c.modifiers:
            if m.type == "ARMATURE":
                m.object = o
        coll.objects.link(c)
    return o


def build_demo_scene():
    """Layout echoing the concept art: school by the Mekong, market, houses."""
    if bpy.data.objects.get("BLD_School") is None:
        build_all()
    C = get_coll("ML_Scene_KampongCham")
    for o in list(C.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    OX, OY = 0.0, 120.0     # scene origin, away from the asset rows
    P = lambda x, y, z=0.0: (OX + x, OY + y, z)
    road_x, lat_y = 25, -15
    for ix in range(-4, 4):
        for iy in range(-3, 3):
            x, y = ix * 10 + 5, iy * 10 + 5
            if x == road_x:
                _place("ENV_Tile_Road_Asphalt", P(x, y), 0, C)
            elif y == lat_y:
                _place("ENV_Tile_Road_Laterite", P(x, y), 90, C)
            elif x <= -25 and y >= 5:
                _place("ENV_Tile_RicePaddy", P(x, y), 0, C)
            else:
                _place("ENV_Tile_Grass", P(x, y), 0, C)
    for ix in range(-4, 4):
        _place("ENV_Tile_River", P(ix * 10 + 5, 35), 0, C)
        _place("ENV_Tile_River", P(ix * 10 + 5, 45), 0, C)
    for ix in range(-4, 4):          # far bank of the Mekong
        x = ix * 10 + 5
        _place("ENV_Tile_Road_Asphalt" if x == road_x else "ENV_Tile_Grass", P(x, 55), 0, C)
    ap = Builder("ML_GroundApron")    # surrounding land (leaves the river open)
    ap.box((160, 95, 0.2), loc=(0, -17.5, -0.32), mat="Grass_Dark")
    ap.box((160, 40, 0.2), loc=(0, 70.0, -0.32), mat="Grass_Dark")
    ap.box((160, 20, 0.2), loc=(0, 40.0, -1.5), mat="Water_Deep")
    apron = ap.to_object(C, loc=P(0, 0), category="Scene")
    apron["mylife_export"] = False
    _place("BLD_Bridge", P(road_x, 40, 0.0), 0, C)
    _place("BLD_Bridge", P(road_x, 52, 0.0), 0, C)
    _place("BLD_School", P(0, 2), 0, C)
    _place("BLD_Pagoda", P(-14, 20), 0, C)
    _place("BLD_StiltHouse", P(-14, -24), 180, C)
    _place("BLD_StiltHouse_B", P(4, -25), 180, C)
    for i, n in enumerate(("Mint", "Yellow", "Peach", "Blue")):
        _place("BLD_Shophouse_" + n, P(16.5, -4 + i * 4.5), 90, C)
    for i, n in enumerate(("Red", "Blue", "Yellow", "Red", "Blue")):
        _place("BLD_MarketStall_" + n, P(11 + (i % 3) * 3.2, -9.5 - (i // 3) * 3.2 + 0.0, 0), 0, C)
    _place("BLD_CoffeeStall", P(-7, -11), 0, C)
    rnd = random.Random(4)
    spots = [(-36, -4), (-30, -8), (-22, 8), (-8, 24), (8, 24), (20, 26), (-38, 26),
             (32, 12), (33, -6), (36, -24), (-30, -27), (14, -27), (-24, -6)]
    for i, (x, y) in enumerate(spots):
        n = ["ENV_SugarPalm", "ENV_SugarPalm_B", "ENV_CoconutPalm", "ENV_Tree", "ENV_Tree_B"][i % 5]
        _place(n, P(x, y), rnd.uniform(0, 360), C)
    for (x, y) in ((-10, -9), (9, -10.5), (-4, -27), (22, 18), (-25, 0), (12, 28)):
        _place("ENV_Bush" if rnd.random() > 0.4 else "ENV_Bush_Plain", P(x, y), rnd.uniform(0, 360), C)
    _place("VEH_Motorbike_Red", P(8, -14.2), 90, C)
    _place("VEH_Motorbike_Blue", P(-18, -16.0), -90, C)
    _place("VEH_Remork", P(26.5, 2), 180, C)
    _place("VEH_Bicycle", P(-3.5, -12.5), 20, C)
    _place("RIG_Sokha", P(1.5, -11.6), 15, C)
    _place("RIG_Sreyneath", P(-1.0, -11.2), -10, C)
    _place("RIG_Sokunthea", P(12.5, -8.3), 0, C)
    _place("RIG_Taing", P(-27.5, 0.2), 30, C)
    _place("RIG_Vuth", P(18.8, 4.5), 80, C)
    for (x, y, c) in ((-6.2, -12.6, "PRP_PlasticStool"),):
        _place(c, P(x, y), 0, C)
    # camera + sun for the hero shot
    cam = bpy.data.objects.get("ML_SceneCamera")
    if cam is None:
        cam = bpy.data.objects.new("ML_SceneCamera", bpy.data.cameras.new("ML_SceneCamera"))
        C.objects.link(cam)
    elif cam.name not in C.objects:
        C.objects.link(cam)
    cam.data.lens = 40
    cam.location = Vector(P(58, -62, 52))
    target = Vector(P(2, 0, 0))
    cam.rotation_euler = (target - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.clip_end = 500
    _ensure_sun(bpy.context.scene, "ML_SceneSun", (52, 0, -40), 3.5)
    _ensure_world(bpy.context.scene)
    bpy.context.scene.camera = cam
    return C


def _ensure_sun(scene, name, rot, energy, color=(1.0, 0.93, 0.80)):
    sun = bpy.data.objects.get(name)
    if sun is None:
        sun = bpy.data.objects.new(name, bpy.data.lights.new(name, "SUN"))
    if sun.name not in scene.collection.objects:
        scene.collection.objects.link(sun)
    sun.data.energy = energy
    sun.data.color = color
    sun.data.angle = math.radians(3)
    sun.rotation_euler = [math.radians(a) for a in rot]
    return sun


def _ensure_world(scene, color=(0.62, 0.74, 0.92), strength=0.8):
    w = bpy.data.worlds.get("ML_Sky") or bpy.data.worlds.new("ML_Sky")
    w.use_nodes = True
    bg = w.node_tree.nodes.get("Background")
    bg.inputs[0].default_value = (*color, 1.0)
    bg.inputs[1].default_value = strength
    scene.world = w
    return w


# =============================================================================
#  SPRITE STUDIO - renders PNGs for Unity
# =============================================================================
def _engine_id(mode):
    items = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
    if mode == "AUTO":
        mode = "CYCLES" if bpy.app.background else "EEVEE"
    if mode == "EEVEE":
        for k in ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"):
            if k in items:
                return k
        return "CYCLES"
    return {"CYCLES": "CYCLES", "WORKBENCH": "BLENDER_WORKBENCH"}.get(mode, "CYCLES")


def _studio():
    sc = bpy.data.scenes.get("ML_SpriteStudio") or bpy.data.scenes.new("ML_SpriteStudio")
    cam = bpy.data.objects.get("ML_StudioCam")
    if cam is None:
        cam = bpy.data.objects.new("ML_StudioCam", bpy.data.cameras.new("ML_StudioCam"))
    if cam.name not in sc.collection.objects:
        sc.collection.objects.link(cam)
    cam.data.type = "ORTHO"
    cam.data.clip_end = 1000
    sc.camera = cam
    _ensure_sun(sc, "ML_StudioSun", (48, 8, -38), 3.0)
    _ensure_world(sc, (0.80, 0.85, 0.95), 0.75)
    sc.render.film_transparent = True
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_mode = "RGBA"
    sc.render.resolution_percentage = 100
    sc.view_settings.view_transform = "Standard"
    sc.view_settings.look = "None"
    return sc, cam


def _set_engine(sc, mode, samples=48):
    sc.render.engine = _engine_id(mode)
    if sc.render.engine == "CYCLES":
        sc.cycles.samples = samples
        sc.cycles.use_denoising = True
        sc.cycles.device = "CPU"
        try:
            sc.cycles.use_adaptive_sampling = True
        except AttributeError:
            pass
    elif sc.render.engine == "BLENDER_WORKBENCH":
        sh = sc.display.shading
        sh.light = "FLAT"
        sh.color_type = "MATERIAL"
        sc.display.render_aa = "32"
    else:
        try:
            sc.eevee.taa_render_samples = 32
        except AttributeError:
            pass


def _frame(cam, pts, rot_deg, margin=1.08, aspect=1.0):
    """Point the ortho camera along rot and fit all world points."""
    R = Euler([math.radians(a) for a in rot_deg], "XYZ").to_matrix()
    Rt = R.transposed()
    local = [Rt @ Vector(p) for p in pts]
    xs = [p.x for p in local]
    ys = [p.y for p in local]
    zs = [p.z for p in local]
    cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
    w, h = max(xs) - min(xs), max(ys) - min(ys)
    cam.rotation_euler = Euler([math.radians(a) for a in rot_deg], "XYZ")
    cam.location = R @ Vector((cx, cy, max(zs) + 20))
    cam.data.ortho_scale = max(w, h * aspect if aspect >= 1 else h / aspect) * margin \
        if aspect == 1.0 else max(w, h * aspect) * margin


def _world_pts(objs):
    pts = []
    for o in objs:
        if o.type in ("MESH",):
            pts += [o.matrix_world @ Vector(c) for c in o.bound_box]
    return pts


def _render_to(sc, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sc.render.filepath = path
    if hasattr(bpy.context, "temp_override"):
        with bpy.context.temp_override(scene=sc):
            bpy.ops.render.render(write_still=True, scene=sc.name)
    else:
        bpy.ops.render.render(write_still=True, scene=sc.name)


class _Linked:
    """Temporarily link objects into the studio scene."""
    def __init__(self, sc, objs):
        self.sc, self.objs = sc, [o for o in objs if o]

    def __enter__(self):
        for o in self.objs:
            if o.name not in self.sc.collection.objects:
                self.sc.collection.objects.link(o)
        return self

    def __exit__(self, *a):
        for o in self.objs:
            if o.name in self.sc.collection.objects:
                self.sc.collection.objects.unlink(o)


def _with_children(o):
    return [o] + list(o.children_recursive if hasattr(o, "children_recursive") else o.children)


def render_ui_sprites(out_dir, icon_px=256, panel_px=128):
    sc, cam = _studio()
    _set_engine(sc, "WORKBENCH")
    paths = []
    for o in bpy.data.collections["ML_UI2D"].objects:
        sprite = o.get("mylife_sprite")
        if not sprite:
            continue
        with _Linked(sc, [o]):
            loc = o.location
            cam.rotation_euler = (0, 0, 0)
            cam.location = (loc.x, loc.y, 10)
            if "mylife_sprite_wh" in o:
                w, h = o["mylife_sprite_wh"]
                scale = panel_px / 2.0
                sc.render.resolution_x = int(w * scale)
                sc.render.resolution_y = int(h * scale)
                cam.data.ortho_scale = max(w, h)
                sub = "UI"
            else:
                sc.render.resolution_x = sc.render.resolution_y = icon_px
                cam.data.ortho_scale = 2.0 * 1.12
                sub = "Icons"
            p = os.path.join(out_dir, "Sprites", sub, sprite + ".png")
            _render_to(sc, p)
            paths.append(p)
    return paths


def render_3d_sprites(out_dir, engine="AUTO", size=512, samples=48, only=None):
    """Inventory icons (props), character portraits + expressions, full-body
    character cards and thumbnails of every asset (build menus, phone apps)."""
    sc, cam = _studio()
    _set_engine(sc, engine, samples)
    paths = []
    view = (62, 0, 35)      # 3/4 view for props & thumbnails
    for o in bpy.data.collections["ML_Props"].objects:
        if only and only not in o.name:
            continue
        sc.render.resolution_x = sc.render.resolution_y = size // 2
        with _Linked(sc, [o]):
            _frame(cam, _world_pts([o]), view, margin=1.15)
            p = os.path.join(out_dir, "Sprites", "Inventory", "inv_" + o.name[4:].lower() + ".png")
            _render_to(sc, p)
            paths.append(p)
    for cat in ("Vehicles", "Buildings", "Nature"):
        for o in bpy.data.collections["ML_" + cat].objects:
            if o.parent is not None or (only and only not in o.name):
                continue
            sc.render.resolution_x = sc.render.resolution_y = size // 2
            objs = _with_children(o)
            with _Linked(sc, objs):
                _frame(cam, _world_pts(objs), (58, 0, 32), margin=1.1)
                p = os.path.join(out_dir, "Sprites", "Thumbnails", o.name.lower() + ".png")
                _render_to(sc, p)
                paths.append(p)
    for rig in bpy.data.collections["ML_Characters"].objects:
        if rig.type != "ARMATURE" or (only and only not in rig.name):
            continue
        mesh = next((c for c in rig.children if c.type == "MESH"), None)
        cid = rig.name[4:]
        with _Linked(sc, [rig, mesh]):
            base = rig.matrix_world.translation
            # full body card
            sc.render.resolution_x, sc.render.resolution_y = size, int(size * 1.5)
            pts = _world_pts([mesh])
            cam.rotation_euler = Euler((math.radians(88), 0, math.radians(-12)), "XYZ")
            R = cam.rotation_euler.to_matrix()
            Rt = R.transposed()
            loc = [Rt @ p for p in pts]
            cx = (min(p.x for p in loc) + max(p.x for p in loc)) / 2
            cy = (min(p.y for p in loc) + max(p.y for p in loc)) / 2
            hgt = max(p.y for p in loc) - min(p.y for p in loc)
            cam.location = R @ Vector((cx, cy, max(p.z for p in loc) + 20))
            cam.data.ortho_scale = hgt * 1.08
            p = os.path.join(out_dir, "Sprites", "Characters", "char_" + cid.lower() + "_full.png")
            _render_to(sc, p)
            paths.append(p)
            # portraits: neutral + expressions (HUD avatar, phone contacts)
            sc.render.resolution_x = sc.render.resolution_y = size // 2
            head = base + Vector((0, 0, 1.57))
            cam.rotation_euler = Euler((math.radians(86), 0, math.radians(-14)), "XYZ")
            R = cam.rotation_euler.to_matrix()
            cam.location = head + R @ Vector((0, 0, 20))
            cam.data.ortho_scale = 0.76
            keys = mesh.data.shape_keys.key_blocks
            for expr in ["Neutral"] + [k.name for k in keys[1:]]:
                for kb in keys[1:]:
                    kb.value = 1.0 if kb.name == expr else 0.0
                p = os.path.join(out_dir, "Sprites", "Portraits",
                                 "portrait_%s_%s.png" % (cid.lower(), expr.lower()))
                _render_to(sc, p)
                paths.append(p)
            for kb in keys[1:]:
                kb.value = 0.0
    return paths


def render_scene_preview(out_dir, engine="AUTO", res=(1600, 900), samples=64):
    if bpy.data.collections.get("ML_Scene_KampongCham") is None:
        build_demo_scene()
    sc = bpy.context.scene
    _set_engine(sc, engine, samples)
    sc.render.film_transparent = False
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.view_settings.view_transform = "Standard"
    sc.camera = bpy.data.objects["ML_SceneCamera"]
    hidden = []
    for c in root_coll().children:          # hide the asset rows for the shot
        lc = _find_layer_coll(bpy.context.view_layer.layer_collection, c.name)
        if lc and not lc.exclude:
            lc.exclude = True
            hidden.append(lc)
    p = os.path.join(out_dir, "Previews", "kampong_cham_scene.png")
    _render_to(sc, p)
    for lc in hidden:
        lc.exclude = False
    return p


def _find_layer_coll(lc, name):
    if lc.name == name:
        return lc
    for c in lc.children:
        r = _find_layer_coll(c, name)
        if r:
            return r
    return None


# =============================================================================
#  UNITY EXPORT  (FBX per asset + manifest.json)
# =============================================================================
def export_unity(out_dir):
    import json
    vl = bpy.context.view_layer
    done, manifest = [], []
    for cat in ("Characters", "Vehicles", "Buildings", "Nature", "Props"):
        coll = bpy.data.collections.get("ML_" + cat)
        if not coll:
            continue
        for o in list(coll.objects):
            if o.parent is not None or not o.get("mylife_export", False):
                continue
            objs = _with_children(o)
            for x in vl.objects:
                x.select_set(False)
            for x in objs:
                x.select_set(True)
            vl.objects.active = o
            old = o.location.copy()
            o.location = (0, 0, 0)
            vl.update()
            fname = o.name.replace("RIG_", "CHR_") if o.type == "ARMATURE" else o.name
            path = os.path.join(out_dir, "Models", cat, fname + ".fbx")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            is_char = o.type == "ARMATURE"
            bpy.ops.export_scene.fbx(
                filepath=path, use_selection=True,
                object_types={"MESH", "ARMATURE", "EMPTY"},
                apply_unit_scale=True, apply_scale_options="FBX_SCALE_ALL",
                axis_forward="-Z", axis_up="Y",
                bake_space_transform=not is_char,   # Unity: tick Bake Axis Conversion for characters
                use_mesh_modifiers=not is_char,     # keeps blendshapes on characters
                mesh_smooth_type="FACE", add_leaf_bones=False,
                primary_bone_axis="Y", secondary_bone_axis="X",
                use_armature_deform_only=True, bake_anim=False, path_mode="AUTO")
            o.location = old
            meshes = [x for x in objs if x.type == "MESH"]
            entry = {
                "name": fname, "category": cat,
                "file": os.path.relpath(path, out_dir).replace("\\", "/"),
                "triangles": sum(sum(len(p.vertices) - 2 for p in m.data.polygons) for m in meshes),
                "materials": sorted({s.material.name for m in meshes for s in m.material_slots if s.material}),
            }
            if is_char:
                m = meshes[0]
                entry["rig"] = "Humanoid"
                entry["blendshapes"] = [k.name for k in m.data.shape_keys.key_blocks[1:]]
                entry["profile"] = {k: _profile(o.name[4:]).get(k) for k in ("name_km", "age", "job", "place")}
            manifest.append(entry)
            done.append(path)
    pal = {k: v for k, v in PALETTE.items()}
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"game": "ជីវិតខ្ញុំ (My Life)", "kit_version": "%d.%d.%d" % bl_info["version"],
                   "units": "1 unit = 1 metre", "assets": manifest, "palette": pal},
                  f, ensure_ascii=False, indent=2)
    return done


# =============================================================================
#  HERO CHARACTER: CHANDY (kickboxer) - higher-detail fighter build
#  Same rig + blendshapes as the other characters, plus "Smirk" and "Fierce".
#  Modelled in A-pose for turnarounds and clean Humanoid retargeting.
# =============================================================================
PALETTE.update({
    "Skin_Fighter": "#D4946A", "Stubble": "#9C6648", "Hair_Orange": "#F2691C",
    "Hair_OrangeDark": "#B9440E", "Hair_Blonde": "#E8C976", "Cord_Blue": "#2B55A6",
    "Rash_Black": "#1C1D21", "Piping_Red": "#C9262D", "Shorts_Blue": "#2E5DB2",
    "Shorts_Gold": "#D8A532", "Rope_Gold": "#C9A04A", "Plaque_Red": "#B0232A",
    "Wrap_Gauze": "#DCD3C1", "Wrap_Dirty": "#B9AD95", "KneePad": "#232428",
    "Prajioud_Red": "#C1252B", "Prajioud_Blue": "#2A4C99", "Teeth": "#F3EEE2",
    "Turn_Floor": "#76777B",
})

EXTRA_CHARACTERS = {
    "Chandy": dict(name_km="ចាន់ឌី", age=28, job="Kickboxer", place="Phnom Penh",
                   label="TGR"),
}


def _profile(cid):
    return CHARACTERS.get(cid) or EXTRA_CHARACTERS.get(cid, {})


def _rot_deg(direction):
    e = align_z(direction).to_euler("XYZ")
    return tuple(math.degrees(a) for a in e)


def _text_3d(b, text, size, matrix, mat, extrude=0.003, group=None):
    cu = bpy.data.curves.new("ML_tmp_txt3", "FONT")
    cu.body = text
    cu.size = size
    cu.extrude = extrude
    cu.align_x, cu.align_y = "CENTER", "CENTER"
    ob = bpy.data.objects.new("ML_tmp_txt3", cu)
    bpy.context.scene.collection.objects.link(ob)
    bpy.context.view_layer.update()
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(bpy.context.evaluated_depsgraph_get()))
    t = b._tbm()
    t.from_mesh(me)
    bmesh.ops.transform(t, matrix=matrix, verts=t.verts)
    b._merge(t, mat, group=group)
    bpy.data.objects.remove(ob)
    bpy.data.curves.remove(cu)
    bpy.data.meshes.remove(me)


def _wrap_bands(b, p1, p2, r1, r2, n, group):
    """Hand/foot combat wraps: base tube + overlapping gauze bands."""
    b.cyl_between(p1, p2, r1, r2, mat="Wrap_Gauze", seg=12, smooth=True, group=group)
    d = Vector(p2) - Vector(p1)
    rot = _rot_deg(d)
    for i in range(n):
        t = (i + 0.5) / n
        c = Vector(p1).lerp(Vector(p2), t)
        rr = r1 + (r2 - r1) * t
        b.torus(rr + 0.002, 0.006, loc=c, rot=(rot[0] + (8 if i % 2 else -8), rot[1], rot[2]),
                mat="Wrap_Dirty" if i % 3 == 0 else "Wrap_Gauze", seg=12, ring=4, group=group)


def build_chandy(coll=None, loc=(0, 0, 0), label="TGR"):
    b = Builder("CHR_Chandy", seed=28)
    skin = "Skin_Fighter"
    J = {}
    for s, side in ((1, "L"), (-1, "R")):     # A-pose (arms ~45 deg)
        sh = Vector((0.245 * s, 0.0, 1.355))
        el = sh + Vector((0.195 * s, 0.01, -0.20))
        wr = el + Vector((0.165 * s, -0.035, -0.185))
        J["shoulder" + side], J["elbow" + side], J["wrist" + side] = sh, el, wr
        J["hand" + side] = wr + Vector((0.045 * s, -0.01, -0.05))
        J["hip" + side] = Vector((0.10 * s, 0.0, 0.90))
        J["knee" + side] = Vector((0.118 * s, -0.01, 0.50))
        J["ankle" + side] = Vector((0.13 * s, 0.0, 0.095))

    # ---------------- torso: rashguard over an athletic V-taper ----------------
    prof = [(0.148, 0.88), (0.146, 0.98), (0.150, 1.06), (0.178, 1.16), (0.212, 1.25),
            (0.232, 1.32), (0.212, 1.385), (0.13, 1.43), (0.072, 1.45)]
    b.lathe(prof, mat="Rash_Black", seg=18, scale=(1, 0.6, 1), smooth=True, group=_torso_group)
    for s in (1, -1):
        b.sphere(0.10, loc=(0.085 * s, -0.098, 1.255), scale=(1.1, 0.42, 0.72), mat="Rash_Black",
                 seg=14, rings=8, smooth=True, group="Chest")          # pecs
        b.sphere(0.10, loc=(0.165 * s, 0.02, 1.18), scale=(0.45, 0.85, 1.25), mat="Rash_Black",
                 seg=12, rings=8, smooth=True, group=_torso_group)    # lats
        b.sphere(0.08, loc=(0.085 * s, 0.035, 1.405), scale=(1.35, 0.8, 0.55), mat="Rash_Black",
                 seg=12, rings=6, smooth=True, group="Chest")          # traps
        for z in (0.985, 1.055, 1.125):                                 # abs under the shirt
            b.sphere(0.034, loc=(0.038 * s, -0.082, z), scale=(1.0, 0.4, 0.85), mat="Rash_Black",
                     seg=10, rings=6, smooth=True, group=_torso_group)
        # red piping: side seams, shoulder seams, chest line
        b.cyl_between((0.150 * s, 0.0, 0.92), (0.212 * s, -0.005, 1.29), 0.0055, mat="Piping_Red",
                      seg=6, group=_torso_group)
        b.cyl_between((0.074 * s, 0.0, 1.455), (0.235 * s, 0.0, 1.395), 0.0055, mat="Piping_Red",
                      seg=6, group="Chest")
        b.cyl_between((0.205 * s, -0.07, 1.31), (0.03 * s, -0.142, 1.19), 0.005, mat="Piping_Red",
                      seg=6, group="Chest")
    b.lathe([(0.074, 1.40), (0.072, 1.47), (0.07, 1.485)], mat="Rash_Black", seg=16,
            smooth=True, cap_top=False, cap_bottom=False, group="Neck")   # mock neck
    b.torus(0.071, 0.0055, loc=(0, 0, 1.483), mat="Piping_Red", seg=16, ring=4, group="Neck")
    b.cyl(0.064, 0.060, 0.12, loc=(0, 0.004, 1.50), mat=skin, seg=12, smooth=True, group="Neck")

    # ---------------- arms ------------------------------------------------------
    for side, s in (("L", 1), ("R", -1)):
        sh, el, wr, hd = J["shoulder" + side], J["elbow" + side], J["wrist" + side], J["hand" + side]
        ua, la, hand = "UpperArm." + side, "LowerArm." + side, "Hand." + side
        d_up, d_lo = el - sh, wr - el
        r_up, r_lo = _rot_deg(d_up), _rot_deg(d_lo)
        b.sphere(0.088, loc=sh + V(-0.01 * s, 0, 0.0), scale=(1.0, 0.95, 0.9), mat="Rash_Black",
                 seg=14, rings=8, smooth=True, group=ua)                   # deltoid
        hem = sh.lerp(el, 0.42)
        b.cyl_between(sh, hem, 0.086, 0.077, mat="Rash_Black", seg=14, smooth=True, group=ua)
        b.torus(0.078, 0.006, loc=hem, rot=r_up, mat="Piping_Red", seg=14, ring=4, group=ua)
        b.cyl_between(hem - d_up * 0.05, el, 0.074, 0.058, mat=skin, seg=12, smooth=True, group=ua)
        b.sphere(0.066, loc=sh.lerp(el, 0.64) + V(0, -0.026, 0.0), rot=r_up, scale=(1.0, 0.95, 1.75),
                 mat=skin, seg=12, rings=8, smooth=True, group=ua)          # biceps
        b.sphere(0.062, loc=sh.lerp(el, 0.6) + V(0, 0.028, 0.0), rot=r_up, scale=(1.0, 0.95, 1.8),
                 mat=skin, seg=12, rings=8, smooth=True, group=ua)          # triceps
        b.sphere(0.054, loc=el, mat=skin, seg=12, rings=8, smooth=True, group=la)
        b.cyl_between(el, wr, 0.064, 0.046, mat=skin, seg=12, smooth=True, group=la)
        b.sphere(0.068, loc=el.lerp(wr, 0.28) + V(0, -0.008, 0), rot=r_lo, scale=(1.05, 0.95, 1.9),
                 mat=skin, seg=12, rings=8, smooth=True, group=la)          # forearm mass
        _wrap_bands(b, wr + d_lo.normalized() * 0.01, el.lerp(wr, 0.55), 0.05, 0.057, 5, la)
        # fist: skin with gauze over the knuckles and palm
        b.box((0.098, 0.108, 0.112), loc=hd, rot=r_lo, mat=skin, bevel=0.03, seg=2, group=hand)
        b.box((0.104, 0.114, 0.06), loc=hd + d_lo.normalized() * 0.012, rot=r_lo,
              mat="Wrap_Gauze", bevel=0.022, seg=2, group=hand)
        b.sphere(0.02, loc=hd + V(-0.035 * s, -0.045, 0.02), scale=(1, 1, 1.6), rot=r_lo, mat=skin,
                 seg=8, rings=5, smooth=True, group=hand)                   # thumb
        if side == "L":   # prajioud: woven red/blue arm band, knot and hanging tails
            c = sh.lerp(el, 0.55)
            dn = d_up.normalized()
            for k, m in enumerate(("Prajioud_Blue", "Prajioud_Red", "Prajioud_Blue")):
                b.torus(0.073, 0.014, loc=c + dn * (k - 1) * 0.022, rot=r_up, mat=m, seg=16,
                        ring=6, smooth=True, group=ua)
            knot = c + V(0.055, 0.035, 0.0)
            b.sphere(0.028, loc=knot, mat="Prajioud_Red", seg=10, rings=6, smooth=True, group=ua)
            for k, (ox, ang) in enumerate(((0.0, 8), (0.018, -12))):
                top = knot + V(ox, 0.01, -0.01)
                bot = top + V(0.03 + ox, 0.03, -0.20 + k * 0.03)
                b.box((0.035, 0.008, (bot - top).length), loc=(top + bot) / 2,
                      rot=_rot_deg(bot - top), mat="Prajioud_Red", group=ua)

    # ---------------- shorts + championship waistband ---------------------------
    b.lathe([(0.15, 0.76), (0.168, 0.82), (0.174, 0.88), (0.172, 0.94)], mat="Shorts_Blue", seg=18,
            scale=(1, 0.72, 1), smooth=True, group="Hips")
    for side, s in (("L", 1), ("R", -1)):
        x = 0.106 * s
        b.lathe([(0.112, 0.87), (0.128, 0.77), (0.140, 0.675)], loc=(x, 0, 0), mat="Shorts_Blue",
                seg=16, scale=(1, 0.92, 1), cap_top=False, cap_bottom=False, smooth=True,
                group="UpperLeg." + side)
        b.torus(0.140, 0.011, loc=(x, 0, 0.675), scale=(1, 0.92, 1), mat="Shorts_Gold", seg=16,
                ring=4, group="UpperLeg." + side)
        for dy in (-0.022, 0.022):          # side stripes
            b.cyl_between((x + 0.116 * s, dy, 0.865), (x + 0.141 * s, dy * 1.1, 0.68), 0.0075,
                          mat="Shorts_Gold", seg=6, group="UpperLeg." + side)
        b.cyl_between((0.13 * s, -0.112, 0.93), (0.01 * s, -0.112, 0.80), 0.009,
                      mat="Shorts_Gold", seg=6, group="Hips")              # front V trim
    b.lathe([(0.172, 0.935), (0.178, 0.95), (0.178, 1.025), (0.172, 1.04)], mat="Rope_Gold",
            seg=20, scale=(1, 0.72, 1), smooth=True, group="Hips")
    for z in (0.945, 1.03):              # rope edges
        b.torus(0.178, 0.011, loc=(0, 0, z), scale=(1, 0.72, 1), mat="Rope_Gold", seg=24, ring=5,
                group="Hips")
    for i in range(24):                  # rope twists
        a = 2 * math.pi * i / 24
        p = V(0.181 * math.cos(a), 0.181 * 0.72 * math.sin(a), 0.988)
        b.box((0.012, 0.008, 0.07), loc=p, rot=(0, 30, math.degrees(a) + 90), mat="Shorts_Gold",
              group="Hips")
    b.box((0.16, 0.02, 0.068), loc=(0, -0.128, 0.988), mat="Plaque_Red", bevel=0.009, seg=2,
          group="Hips")
    _text_3d(b, label, 0.052, T((0, -0.1395, 0.986), (90, 0, 0)), "Shorts_Gold", group="Hips")

    # ---------------- legs, knee pads, bare wrapped feet -------------------------
    for side, s in (("L", 1), ("R", -1)):
        hp, kn, an = J["hip" + side], J["knee" + side], J["ankle" + side]
        ul, ll, ft = "UpperLeg." + side, "LowerLeg." + side, "Foot." + side
        b.cyl_between(hp.lerp(kn, 0.28), kn, 0.092, 0.068, mat=skin, seg=14, smooth=True, group=ul)
        b.sphere(0.072, loc=hp.lerp(kn, 0.6) + V(0, -0.028, 0), scale=(1.0, 0.95, 2.0), mat=skin,
                 seg=12, rings=8, smooth=True, group=ul)                    # quads
        b.lathe([(0.076, kn.z - 0.095), (0.084, kn.z - 0.05), (0.086, kn.z + 0.04),
                 (0.079, kn.z + 0.085)], loc=(kn.x, kn.y, 0), mat="KneePad", seg=16,
                cap_top=False, cap_bottom=False, smooth=True, group=ll)
        b.sphere(0.07, loc=kn + V(0, -0.045, -0.005), scale=(1.0, 0.55, 1.2), mat="KneePad",
                 seg=14, rings=8, smooth=True, group=ll)
        b.cyl_between(kn, an + V(0, 0, 0.06), 0.07, 0.046, mat=skin, seg=12, smooth=True, group=ll)
        b.sphere(0.072, loc=kn.lerp(an, 0.3) + V(0, 0.028, 0), scale=(1.0, 1.0, 2.0), mat=skin,
                 seg=12, rings=8, smooth=True, group=ll)                    # calves
        _wrap_bands(b, an + V(0, 0, -0.02), an + V(0, 0, 0.16), 0.05, 0.046, 5, ft)
        b.box((0.098, 0.24, 0.064), loc=(an.x, -0.065, 0.036), mat=skin, bevel=0.026, seg=2,
              group=ft)
        b.box((0.098, 0.095, 0.064), loc=(an.x, -0.035, 0.036), mat="Wrap_Gauze", bevel=0.024,
              seg=2, group=ft)
        for k, (ox, r) in enumerate(((-0.03, 0.018), (-0.012, 0.014), (0.004, 0.013),
                                     (0.019, 0.012), (0.032, 0.011))):
            b.sphere(r, loc=(an.x - ox * s, -0.168 + abs(ox) * 0.35, 0.018), mat=skin, seg=8,
                     rings=5, smooth=True, group=ft)                         # toes

    # ---------------- head & face ----------------------------------------------
    hc = HEAD_C
    b.sphere(1.0, loc=hc, scale=(0.158, 0.155, 0.182), mat=skin, seg=18, rings=14, smooth=True,
             group="Head")
    b.sphere(0.085, loc=hc + V(0, -0.05, -0.11), scale=(1.22, 1.0, 0.82), mat="Stubble", seg=14,
             rings=8, smooth=True, group="Head")                            # jaw / stubble
    for s in (1, -1):
        b.sphere(0.034, loc=hc + V(0.156 * s, 0.01, -0.02), scale=(0.45, 0.8, 1.1), mat=skin,
                 seg=8, rings=6, smooth=True, group="Head")
        b.sphere(0.04, loc=hc + V(0.085 * s, -0.098, -0.025), scale=(1.1, 0.45, 0.7), mat=skin,
                 seg=12, rings=8, smooth=True, group="Head")                # cheekbones (subtle)
    b.sphere(0.024, loc=hc + V(0, -0.156, -0.04), scale=(0.85, 0.9, 1.1), mat=skin, seg=12,
             rings=6, smooth=True, group="Head")
    for s in (1, -1):
        sd = "L" if s > 0 else "R"
        b.sphere(0.026, loc=hc + V(0.056 * s, -0.137, 0.0), scale=(0.95, 0.45, 0.95), mat="Eye",
                 seg=10, rings=6, smooth=True, group="Head", tag="eye_" + sd)
        b.sphere(0.007, loc=hc + V(0.056 * s + 0.007, -0.15, 0.009), mat="EyeWhite", seg=6,
                 rings=4, group="Head", tag="hl_" + sd)
        b.box((0.058, 0.014, 0.017), loc=hc + V(0.057 * s, -0.142, 0.05), rot=(0, -16 * s, 0),
              mat="Hair_OrangeDark", bevel=0.004, group="Head", tag="brow_" + sd)
    mv, mf = _mouth_mesh(MOUTH_NEUTRAL)
    b.custom(mv, mf, mat="Mouth", matrix=Matrix.Translation(hc + V(0, -0.135, -0.085)),
             group="Head", tag="mouth")
    b.box((0.03, 0.006, 0.006), loc=hc + V(0.006, -0.132, -0.082), mat="Teeth", group="Head")

    # ---------------- hair: spiky orange + high blonde ponytail -----------------
    _hair_cap(b, "Hair_Orange", front_cut=0.42, side_cut=-0.12, back_cut=-0.5, grow=1.07)
    rng = b.rng
    crown = hc + V(0, 0.01, 0.12)
    spikes = [(-0.11, 0.00, 0.0), (-0.05, -0.04, 0.4), (0.0, 0.02, 0.6), (0.06, -0.03, 0.3),
              (0.11, 0.01, 0.1), (-0.08, 0.07, 0.5), (0.07, 0.07, 0.5), (0.0, 0.10, 0.4),
              (-0.03, -0.09, 0.2), (0.04, -0.09, 0.1)]
    for i, (x, y, extra) in enumerate(spikes):
        base = crown + V(x, y, 0.03 - abs(x) * 0.25)
        d = V(x * 2.4, y * 1.4 + 0.12, 1.0).normalized()
        ln = 0.17 + extra * 0.18 + rng.uniform(0, 0.04)
        b.cyl(0.05, 0.0, ln, matrix=Matrix.Translation(base + d * ln / 2) @ align_z(d),
              mat="Hair_Orange" if i % 3 else "Hair_OrangeDark", seg=6, group="Head")
    for x, dx in ((-0.07, 0.3), (-0.01, 0.4), (0.05, 0.5)):              # fringe swoop
        base = hc + V(x, -0.12, 0.155)
        d = V(dx, -0.75, -0.2).normalized()
        b.cyl(0.033, 0.0, 0.12, matrix=Matrix.Translation(base + d * 0.06) @ align_z(d),
              mat="Hair_Orange", seg=6, group="Head")
    for s in (1, -1):
        b.box((0.012, 0.03, 0.06), loc=hc + V(0.152 * s, -0.035, 0.0), mat="Hair_OrangeDark",
              bevel=0.004, group="Head")
    pts = [hc + V(0, 0.11, 0.16), hc + V(0, 0.21, 0.19), hc + V(0, 0.28, 0.08),
           hc + V(0, 0.30, -0.10), hc + V(0, 0.28, -0.28), hc + V(0, 0.24, -0.43)]
    radii = [0.046, 0.052, 0.05, 0.042, 0.03, 0.008]
    for i in range(len(pts) - 1):
        b.cyl_between(pts[i], pts[i + 1], radii[i], radii[i + 1], mat="Hair_Blonde", seg=10,
                      smooth=True, group="Head")
        b.sphere(radii[i + 1], loc=pts[i + 1], mat="Hair_Blonde", seg=10, rings=6, smooth=True,
                 group="Head")
    for k in range(5):                    # loose strands at the tip
        p = pts[3].lerp(pts[4], 0.5)
        d = V(rng.uniform(-0.25, 0.25), rng.uniform(-0.1, 0.25), -1.0).normalized()
        b.cyl(0.018, 0.0, 0.2, matrix=Matrix.Translation(p + d * 0.1) @ align_z(d),
              mat="Hair_Blonde", seg=5, group="Head")
    seg_d = pts[1] - pts[0]
    for k in range(3):                    # blue wrap cords
        c = pts[0].lerp(pts[1], 0.25 + 0.25 * k)
        b.torus(0.05, 0.009, loc=c, rot=_rot_deg(seg_d), mat="Cord_Blue", seg=12, ring=4,
                group="Head")

    coll = coll or cat_coll("Characters")
    obj = b.to_object(coll, category="Characters")
    _add_face_shapekeys(obj, b)
    _add_chandy_keys(obj, b)
    for k, v in EXTRA_CHARACTERS["Chandy"].items():
        obj["mylife_" + k] = v
    rig = _build_rig(obj, False, J, coll)
    rig.location = loc
    return rig


def _add_chandy_keys(obj, b):
    base = [v.co.copy() for v in obj.data.vertices]
    idx = b.tag_index
    mc = HEAD_C + V(0, -0.135, -0.085)

    def centre(ids):
        c = Vector()
        for i in ids:
            c += base[i]
        return c / max(len(ids), 1)

    def squint(kb, amt):
        for sd in ("L", "R"):
            c = centre(idx["eye_" + sd])
            for i in idx["eye_" + sd]:
                d = base[i] - c
                kb.data[i].co = c + V(d.x, d.y, d.z * amt) + V(0, 0, -0.003)
    kb = obj.shape_key_add(name="Smirk", from_mix=False)
    for k, i in enumerate(idx["mouth"]):
        a = 2 * math.pi * (k % MOUTH_N) / MOUTH_N
        w, h = 0.031, 0.008
        x = w * math.cos(a)
        z = h * math.sin(a) + (0.024 if x > 0 else 0.002) * (x / w) ** 2 + 0.006 * (x / w)
        kb.data[i].co = mc + V(x + 0.004, 0.0 if k < MOUTH_N else 0.014, z)
    squint(kb, 0.8)
    kb.value = 0.0
    kb = obj.shape_key_add(name="Fierce", from_mix=False)
    for sd, s in (("L", 1), ("R", -1)):
        for i in idx["brow_" + sd]:
            inner = 1.0 - min(abs(base[i].x - 0.028 * s) / 0.058, 1.0)
            kb.data[i].co = base[i] + V(-0.004 * s * inner, 0, -0.012 * inner)
    squint(kb, 0.7)
    kb.value = 0.0


def hero_look():
    """Blender-render-only material detail: skin SSS, sweat sheen, pore and
    fabric-weave bump. (Unity receives the flat base colours.)"""
    def setin(bsdf, names, val):
        for n in names:
            if n in bsdf.inputs:
                bsdf.inputs[n].default_value = val
                return

    def bump(m, kind, scale, strength):
        nt = m.node_tree
        bsdf = nt.nodes.get("Principled BSDF")
        tc = nt.nodes.new("ShaderNodeTexCoord")
        bp = nt.nodes.new("ShaderNodeBump")
        bp.inputs["Strength"].default_value = strength
        bp.inputs["Distance"].default_value = 0.002
        if kind == "noise":
            tx = nt.nodes.new("ShaderNodeTexNoise")
            tx.inputs["Scale"].default_value = scale
            tx.inputs["Detail"].default_value = 8.0
            nt.links.new(tc.outputs["Object"], tx.inputs["Vector"])
            nt.links.new(tx.outputs["Fac"], bp.inputs["Height"])
        else:   # weave: two crossing wave textures
            mx = nt.nodes.new("ShaderNodeMath")
            mx.operation = "ADD"
            for k, dirn in enumerate(("X", "Z")):
                wv = nt.nodes.new("ShaderNodeTexWave")
                wv.bands_direction = dirn
                wv.inputs["Scale"].default_value = scale
                nt.links.new(tc.outputs["Object"], wv.inputs["Vector"])
                nt.links.new(wv.outputs["Fac"], mx.inputs[k])
            nt.links.new(mx.outputs["Value"], bp.inputs["Height"])
        nt.links.new(bp.outputs["Normal"], bsdf.inputs["Normal"])

    for key, kind in (("Skin_Fighter", "skin"), ("Stubble", "skin"), ("Rash_Black", "weave"),
                      ("Shorts_Blue", "satin"), ("Shorts_Gold", "satin"), ("Rope_Gold", "weave"),
                      ("Wrap_Gauze", "weave"), ("Wrap_Dirty", "weave"), ("KneePad", "weave"),
                      ("Prajioud_Red", "weave"), ("Prajioud_Blue", "weave"),
                      ("Hair_Orange", "hair"), ("Hair_OrangeDark", "hair"), ("Hair_Blonde", "hair")):
        m = get_mat(key)
        if m.get("ml_hero"):
            continue
        m["ml_hero"] = True
        bsdf = m.node_tree.nodes.get("Principled BSDF")
        col = bsdf.inputs["Base Color"].default_value[:]
        if kind == "skin":
            setin(bsdf, ["Subsurface Weight", "Subsurface"], 0.18)
            setin(bsdf, ["Subsurface Color"], col)
            setin(bsdf, ["Subsurface Radius"], (0.9, 0.45, 0.25))
            setin(bsdf, ["Subsurface Scale"], 0.01)
            bsdf.inputs["Roughness"].default_value = 0.42
            setin(bsdf, ["Coat Weight", "Clearcoat"], 0.18)          # sweat sheen
            setin(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.25)
            bump(m, "noise", 450.0, 0.12)                            # pores
        elif kind == "weave":
            bsdf.inputs["Roughness"].default_value = 0.8
            bump(m, "weave", 260.0, 0.25)
        elif kind == "satin":
            bsdf.inputs["Roughness"].default_value = 0.32
            setin(bsdf, ["Sheen Weight", "Sheen"], 0.4)
            bump(m, "weave", 400.0, 0.08)
        elif kind == "hair":
            bsdf.inputs["Roughness"].default_value = 0.4
            bump(m, "noise", 120.0, 0.35)


def render_turnaround(out_dir, cid="Chandy", engine="AUTO", samples=48, res=(2400, 1000),
                      expression="Smirk", closeup=True, turnaround=True):
    """Front / 3-4 / side / back turnaround on a neutral grey background,
    plus a 3/4 close-up. Saved to <out>/Previews/."""
    rig = bpy.data.objects.get("RIG_" + cid)
    if rig is None:
        rig = build_chandy() if cid == "Chandy" else build_character(cid)
    mesh = next(c for c in rig.children if c.type == "MESH")
    hero_look()
    sc = bpy.data.scenes.get("ML_Turnaround") or bpy.data.scenes.new("ML_Turnaround")
    for o in list(sc.collection.objects):
        sc.collection.objects.unlink(o)
    w = bpy.data.worlds.get("ML_Gray") or bpy.data.worlds.new("ML_Gray")
    w.use_nodes = True
    w.node_tree.nodes["Background"].inputs[0].default_value = (0.30, 0.30, 0.31, 1)
    w.node_tree.nodes["Background"].inputs[1].default_value = 1.0
    sc.world = w
    _set_engine(sc, engine, samples)
    sc.render.film_transparent = False
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_mode = "RGB"
    vts = [e.identifier for e in sc.view_settings.bl_rna.properties["view_transform"].enum_items]
    sc.view_settings.view_transform = "AgX" if "AgX" in vts else ("Filmic" if "Filmic" in vts else "Standard")
    temp = []
    fb = Builder("ML_TurnFloor")
    fb.box((40, 40, 0.02), loc=(0, 0, -0.01), mat="Turn_Floor")
    floor = fb.to_object(sc.collection, category="Scene")
    floor["mylife_export"] = False
    temp.append(floor)
    gap = 1.55
    copies = []
    for i, ang in enumerate((0, 45, 90, 180)):
        r2 = rig.copy()
        r2.location = ((i - 1.5) * gap, 0, 0)
        r2.rotation_euler = (0, 0, math.radians(ang))
        r2["mylife_export"] = False
        sc.collection.objects.link(r2)
        m2 = mesh.copy()
        m2.parent = r2
        m2["mylife_export"] = False
        for md in m2.modifiers:
            if md.type == "ARMATURE":
                md.object = r2
        sc.collection.objects.link(m2)
        temp += [r2, m2]
        copies.append(r2)
    sun = bpy.data.objects.get("ML_TurnKey") or bpy.data.objects.new(
        "ML_TurnKey", bpy.data.lights.new("ML_TurnKey", "SUN"))
    sun.data.energy, sun.data.angle = 3.2, math.radians(8)
    sun.rotation_euler = [math.radians(a) for a in (52, 0, -32)]
    rim = bpy.data.objects.get("ML_TurnRim") or bpy.data.objects.new(
        "ML_TurnRim", bpy.data.lights.new("ML_TurnRim", "AREA"))
    rim.data.energy, rim.data.size = 900, 4.0
    rim.location = (0, 4.0, 3.2)
    rim.rotation_euler = (V(0, 0, 1.0) - rim.location).to_track_quat("-Z", "Y").to_euler()
    for L in (sun, rim):
        sc.collection.objects.link(L)
    cam = bpy.data.objects.get("ML_TurnCam") or bpy.data.objects.new(
        "ML_TurnCam", bpy.data.cameras.new("ML_TurnCam"))
    sc.collection.objects.link(cam)
    sc.camera = cam
    cam.data.type = "ORTHO"
    cam.data.ortho_scale = gap * 4 + 0.3
    cam.rotation_euler = (math.radians(88), 0, 0)
    cam.location = (0, -15, 0.98 + 15 * math.tan(math.radians(2)))
    keys = mesh.data.shape_keys.key_blocks
    for kb in keys[1:]:
        kb.value = 1.0 if kb.name == expression else 0.0
    if expression == "Smirk" and "Fierce" in keys:
        keys["Fierce"].value = 0.6
    sc.render.resolution_x, sc.render.resolution_y = res
    paths = []
    if turnaround:
        paths.append(os.path.join(out_dir, "Previews", cid.lower() + "_turnaround.png"))
        _render_to(sc, paths[-1])
    if closeup:
        sc.render.resolution_x = sc.render.resolution_y = 1200
        c = copies[1]
        cam.data.ortho_scale = 0.62
        cam.rotation_euler = (math.radians(88), 0, 0)
        cam.location = (c.location.x, -15, 1.60 + 15 * math.tan(math.radians(2)))
        paths.append(os.path.join(out_dir, "Previews", cid.lower() + "_closeup.png"))
        _render_to(sc, paths[-1])
    for kb in keys[1:]:
        kb.value = 0.0
    for o in temp:
        bpy.data.objects.remove(o, do_unlink=True)
    for L in (sun, rim, cam):
        if L.name in sc.collection.objects:
            sc.collection.objects.unlink(L)
    return paths


# =============================================================================
#  BLENDER UI  (View3D > Sidebar > My Life)
# =============================================================================
def _out_dir(context):
    d = bpy.path.abspath(context.scene.mylife_out_dir) if context.scene.mylife_out_dir else ""
    if not d:
        base = os.path.dirname(bpy.data.filepath) if bpy.data.filepath else os.path.expanduser("~")
        d = os.path.join(base, "MyLife_Export")
    return d


class MYLIFE_OT_build(bpy.types.Operator):
    bl_idname = "mylife.build"
    bl_label = "Build"
    bl_description = "Build (or rebuild) assets of a category"
    bl_options = {"REGISTER", "UNDO"}
    category: bpy.props.EnumProperty(items=[(k, k, "") for k in ["ALL", "UI2D", "SCENE"] + list(BUILDERS)])

    def execute(self, context):
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        if self.category == "ALL":
            build_all()
        elif self.category == "UI2D":
            build_ui_2d()
        elif self.category == "SCENE":
            build_demo_scene()
        else:
            build_category(self.category)
        self.report({"INFO"}, "My Life: built %s" % self.category)
        return {"FINISHED"}


class MYLIFE_OT_render(bpy.types.Operator):
    bl_idname = "mylife.render"
    bl_label = "Render Sprites"
    bl_description = "Render 2D sprites (UI icons, inventory, portraits, thumbnails) to PNG"
    what: bpy.props.EnumProperty(items=[("UI", "2D UI", ""), ("3D", "3D sprites", ""),
                                        ("SCENE", "Scene preview", "")])

    def execute(self, context):
        out = _out_dir(context)
        if self.what == "UI":
            if not bpy.data.collections.get("ML_UI2D"):
                build_ui_2d()
            n = len(render_ui_sprites(out, context.scene.mylife_icon_px))
        elif self.what == "3D":
            n = len(render_3d_sprites(out, context.scene.mylife_engine, context.scene.mylife_sprite_px))
        else:
            render_scene_preview(out, context.scene.mylife_engine)
            n = 1
        self.report({"INFO"}, "My Life: %d images -> %s" % (n, out))
        return {"FINISHED"}


class MYLIFE_OT_export(bpy.types.Operator):
    bl_idname = "mylife.export"
    bl_label = "Export FBX for Unity"
    bl_description = "Export every asset as its own FBX + manifest.json"

    def execute(self, context):
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        out = _out_dir(context)
        n = len(export_unity(out))
        self.report({"INFO"}, "My Life: exported %d FBX -> %s" % (n, out))
        return {"FINISHED"}


class MYLIFE_PT_panel(bpy.types.Panel):
    bl_label = "ជីវិតខ្ញុំ  My Life Kit"
    bl_idname = "MYLIFE_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "My Life"

    def draw(self, context):
        L = self.layout
        sc = context.scene
        col = L.column(align=True)
        col.label(text="1. Build 3D assets")
        col.operator("mylife.build", text="Build Everything", icon="WORLD").category = "ALL"
        g = col.grid_flow(columns=2, align=True)
        for k, ic in (("Characters", "ARMATURE_DATA"), ("Vehicles", "AUTO"),
                      ("Buildings", "HOME"), ("Nature", "OUTLINER_OB_FORCE_FIELD"),
                      ("Props", "PACKAGE"), ("UI2D", "IMAGE_DATA")):
            g.operator("mylife.build", text=k, icon=ic).category = k
        col.operator("mylife.build", text="Kampong Cham demo scene", icon="SCENE_DATA").category = "SCENE"
        L.separator()
        col = L.column(align=True)
        col.label(text="2. Render 2D sprites")
        col.prop(sc, "mylife_engine", text="Engine")
        row = col.row(align=True)
        row.prop(sc, "mylife_icon_px", text="Icon px")
        row.prop(sc, "mylife_sprite_px", text="Sprite px")
        col.operator("mylife.render", text="UI icons & panels", icon="IMAGE_RGB_ALPHA").what = "UI"
        col.operator("mylife.render", text="Inventory, portraits, thumbs", icon="RENDER_STILL").what = "3D"
        col.operator("mylife.render", text="Scene preview", icon="CAMERA_DATA").what = "SCENE"
        L.separator()
        col = L.column(align=True)
        col.label(text="3. Export to Unity")
        col.prop(sc, "mylife_out_dir", text="")
        col.operator("mylife.export", text="Export FBX + manifest", icon="EXPORT")


CLASSES = (MYLIFE_OT_build, MYLIFE_OT_render, MYLIFE_OT_export, MYLIFE_PT_panel)


def register():
    S = bpy.types.Scene
    S.mylife_out_dir = bpy.props.StringProperty(
        name="Output folder", subtype="DIR_PATH", default="",
        description="Empty = 'MyLife_Export' next to the .blend file")
    S.mylife_engine = bpy.props.EnumProperty(
        name="Engine", default="AUTO",
        items=[("AUTO", "Auto", "EEVEE in the UI, Cycles in background mode"),
               ("EEVEE", "EEVEE", "Fast"), ("CYCLES", "Cycles", "Best quality"),
               ("WORKBENCH", "Workbench", "Flat, instant")])
    S.mylife_icon_px = bpy.props.IntProperty(name="Icon px", default=256, min=32, max=2048)
    S.mylife_sprite_px = bpy.props.IntProperty(name="Sprite px", default=512, min=64, max=4096)
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
    for p in ("mylife_out_dir", "mylife_engine", "mylife_icon_px", "mylife_sprite_px"):
        if hasattr(bpy.types.Scene, p):
            delattr(bpy.types.Scene, p)


# =============================================================================
#  COMMAND LINE:  blender -b -P mylife_kit.py -- --build --render --export --out DIR
# =============================================================================
def _cli(argv):
    import argparse
    ap = argparse.ArgumentParser(prog="mylife_kit")
    ap.add_argument("--build", action="store_true")
    ap.add_argument("--scene", action="store_true")
    ap.add_argument("--render", action="store_true")
    ap.add_argument("--preview", action="store_true")
    ap.add_argument("--export", action="store_true")
    ap.add_argument("--turnaround", default="", help="character id, e.g. Chandy")
    ap.add_argument("--save", default="")
    ap.add_argument("--out", default=os.path.join(os.getcwd(), "MyLife_Export"))
    ap.add_argument("--engine", default="AUTO")
    ap.add_argument("--samples", type=int, default=48)
    a = ap.parse_args(argv)
    out = os.path.abspath(a.out)
    for o in [o for o in bpy.data.objects if o.name in ("Cube", "Light", "Camera")]:
        bpy.data.objects.remove(o, do_unlink=True)
    if a.build or a.render or a.export or a.scene or a.preview:
        build_all()
    if a.scene or a.preview:
        build_demo_scene()
    if a.render:
        print("UI sprites:", len(render_ui_sprites(out)))
        print("3D sprites:", len(render_3d_sprites(out, a.engine, samples=a.samples)))
    if a.preview:
        print("Preview:", render_scene_preview(out, a.engine, samples=a.samples))
    if a.turnaround:
        print("Turnaround:", render_turnaround(out, a.turnaround, a.engine, a.samples))
    if a.export:
        print("FBX files:", len(export_unity(out)))
    if a.save:
        bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(a.save))


if __name__ == "__main__":
    try:
        register()
    except ValueError:      # already registered (script run twice)
        unregister()
        register()
    if "--" in sys.argv:
        _cli(sys.argv[sys.argv.index("--") + 1:])
