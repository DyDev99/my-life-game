# =============================================================================
#  SUPERCAR ASSET GENERATOR  - game-ready Blender vehicle (original design)
#  Builds a separated, rigged-by-hierarchy, PBR-textured supercar with LOD0-3
#  and exports FBX for Unity / Unreal.
#
#  Blender 3.6 LTS / 4.x (tested 4.2 LTS)
#   GUI : Scripting > open > Run Script, then View3D > Sidebar > "Supercar"
#   CLI : blender -b -P supercar_kit.py -- --export --render --out ./Supercar_Export
# =============================================================================
bl_info = {"name": "Supercar Asset Generator", "author": "My Life team", "version": (1, 0, 0),
           "blender": (3, 6, 0), "location": "View3D > Sidebar > Supercar",
           "description": "Game-ready supercar with separate parts, LODs and PBR materials",
           "category": "Add Mesh"}

import bpy
import bmesh
import math
import os
import random
import sys
from mathutils import Vector, Matrix, Euler


def hex_rgba(h):
    h = h.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    a = int(h[6:8], 16) / 255.0 if len(h) == 8 else 1.0

    def lin(c):  # sRGB -> linear (Blender colour sockets are linear)
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return (lin(r), lin(g), lin(b), a)



# -----------------------------------------------------------------------------
#  Small math helpers
# -----------------------------------------------------------------------------
def V(*a):
    return Vector(a[0] if len(a) == 1 else a)


def T(loc=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1)):
    """Transform matrix. rot in DEGREES (XYZ euler)."""
    r = Euler([math.radians(a) for a in rot], "XYZ").to_matrix().to_4x4()
    s = Matrix.Diagonal((scale[0], scale[1], scale[2], 1.0))
    return Matrix.Translation(Vector(loc)) @ r @ s


def align_z(direction):
    """Rotation matrix that maps +Z onto `direction`."""
    d = Vector(direction).normalized()
    return Vector((0, 0, 1)).rotation_difference(d).to_matrix().to_4x4()


def circle_pts(r, n, cx=0.0, cy=0.0, a0=0.0, a1=2 * math.pi, closed=True,
               sx=1.0, sy=1.0):
    pts = []
    cnt = n if closed else n + 1
    for i in range(cnt):
        a = a0 + (a1 - a0) * i / n
        pts.append((cx + r * sx * math.cos(a), cy + r * sy * math.sin(a)))
    return pts


def rounded_rect_pts(w, h, r, cx=0.0, cy=0.0, n=6):
    r = min(r, w / 2, h / 2)
    pts = []
    corners = [(w / 2 - r, h / 2 - r, 0), (-w / 2 + r, h / 2 - r, 90),
               (-w / 2 + r, -h / 2 + r, 180), (w / 2 - r, -h / 2 + r, 270)]
    for x, y, a in corners:
        for i in range(n + 1):
            t = math.radians(a + 90 * i / n)
            pts.append((cx + x + r * math.cos(t), cy + y + r * math.sin(t)))
    return pts


def arc_band_pts(r_in, r_out, a0, a1, n=16, cx=0.0, cy=0.0):
    """Thick arc as a polygon (angles in degrees)."""
    outer = [(cx + r_out * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
              cy + r_out * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
             for i in range(n + 1)]
    inner = [(cx + r_in * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
              cy + r_in * math.sin(math.radians(a0 + (a1 - a0) * i / n)))
             for i in range(n, -1, -1)]
    return outer + inner


# -----------------------------------------------------------------------------
#  Builder: every asset is assembled from primitives into ONE mesh object with
#  several material slots (= one draw call per material in Unity). Primitives
#  can carry a vertex-group name (rigging) and a tag (shape keys).
# -----------------------------------------------------------------------------
class Builder:
    def __init__(self, name, seed=1):
        self.name = name
        self.bm = bmesh.new()
        self.uv = self.bm.loops.layers.uv.verify()
        # layers must exist before any vertex is created (adding a layer later
        # invalidates python references to existing BMVerts)
        self.deform = self.bm.verts.layers.deform.verify()
        self.mats = []
        self.groups = []
        self.tags = {}
        self.rng = random.Random(seed)

    # ---- internals ----------------------------------------------------------
    def _mi(self, mat):
        if mat not in self.mats:
            self.mats.append(mat)
        return self.mats.index(mat)

    def _gi(self, g):
        if g not in self.groups:
            self.groups.append(g)
        return self.groups.index(g)

    @staticmethod
    def _tbm():
        t = bmesh.new()
        t.loops.layers.uv.verify()
        return t

    def _merge(self, t, mat, smooth=False, group=None, tag=None, mats=None):
        """Copy temp bmesh `t` into the asset. `mats` (optional) is a function
        face_index -> material key for multi-colour primitives."""
        tuv = t.loops.layers.uv.active
        vmap = {}
        for v in t.verts:
            vmap[v] = self.bm.verts.new(v.co)
        for i, f in enumerate(t.faces):
            try:
                nf = self.bm.faces.new([vmap[v] for v in f.verts])
            except ValueError:
                continue
            nf.material_index = self._mi(mats(i) if mats else mat)
            nf.smooth = smooth
            if tuv is not None:
                for l, nl in zip(f.loops, nf.loops):
                    nl[self.uv].uv = l[tuv].uv
        new_verts = list(vmap.values())
        if group:
            for v in new_verts:
                g = group(v.co) if callable(group) else group
                v[self.deform][self._gi(g)] = 1.0
        if tag:
            self.tags.setdefault(tag, []).extend(new_verts)
        t.free()
        return new_verts

    # ---- primitives -----------------------------------------------------------
    def box(self, size, loc=(0, 0, 0), rot=(0, 0, 0), mat="Cloth_White",
            bevel=0.0, seg=1, **kw):
        t = self._tbm()
        bmesh.ops.create_cube(t, size=1.0, calc_uvs=True)
        bmesh.ops.transform(t, matrix=Matrix.Diagonal((*size, 1)), verts=t.verts)
        if bevel > 0:
            bmesh.ops.bevel(t, geom=list(t.edges), offset=bevel, offset_type="OFFSET",
                            segments=seg, profile=0.5, affect="EDGES",
                            clamp_overlap=True)
        bmesh.ops.transform(t, matrix=T(loc, rot), verts=t.verts)
        return self._merge(t, mat, **kw)

    def cyl(self, r1, r2, depth, loc=(0, 0, 0), rot=(0, 0, 0), mat="Metal",
            seg=8, cap=True, scale=(1, 1, 1), matrix=None, **kw):
        """Cylinder/cone along local Z, centred at loc. r1 = bottom radius."""
        t = self._tbm()
        bmesh.ops.create_cone(t, cap_ends=cap, cap_tris=False, segments=seg,
                              radius1=max(r1, 1e-4), radius2=max(r2, 1e-4),
                              depth=depth, calc_uvs=True)
        m = matrix if matrix is not None else T(loc, rot, scale)
        bmesh.ops.transform(t, matrix=m, verts=t.verts)
        return self._merge(t, mat, **kw)

    def cyl_between(self, p1, p2, r1, r2=None, mat="Metal", seg=8, **kw):
        p1, p2 = Vector(p1), Vector(p2)
        d = p2 - p1
        m = Matrix.Translation((p1 + p2) / 2) @ align_z(d)
        return self.cyl(r1, r1 if r2 is None else r2, d.length, mat=mat, seg=seg,
                        matrix=m, **kw)

    def sphere(self, r, loc=(0, 0, 0), scale=(1, 1, 1), rot=(0, 0, 0),
               mat="Cloth_White", seg=12, rings=8, smooth=False, jitter=0.0, **kw):
        t = self._tbm()
        bmesh.ops.create_uvsphere(t, u_segments=seg, v_segments=rings, radius=r,
                                  calc_uvs=True)
        if jitter:
            for v in t.verts:
                v.co += Vector([self.rng.uniform(-jitter, jitter) for _ in range(3)])
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        return self._merge(t, mat, smooth=smooth, **kw)

    def ico(self, r, loc=(0, 0, 0), scale=(1, 1, 1), rot=(0, 0, 0), mat="Leaf",
            subdiv=1, jitter=0.0, **kw):
        t = self._tbm()
        bmesh.ops.create_icosphere(t, subdivisions=subdiv, radius=r, calc_uvs=True)
        if jitter:
            for v in t.verts:
                v.co += Vector([self.rng.uniform(-jitter, jitter) * r for _ in range(3)])
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        return self._merge(t, mat, **kw)

    def torus(self, R, r, loc=(0, 0, 0), rot=(0, 0, 0), mat="Rubber", seg=16,
              ring=6, arc=360.0, scale=(1, 1, 1), **kw):
        """Torus in local XY plane (axis = Z). `arc` < 360 gives an open tube."""
        t = self._tbm()
        closed = arc >= 359.9
        n = seg if closed else seg + 1
        rows = []
        for i in range(n):
            a = math.radians(arc * i / seg)
            row = []
            for j in range(ring):
                b = 2 * math.pi * j / ring
                rr = R + r * math.cos(b)
                row.append(t.verts.new((rr * math.cos(a), rr * math.sin(a),
                                        r * math.sin(b))))
            rows.append(row)
        for i in range(seg if closed else seg):
            a, b = rows[i], rows[(i + 1) % n]
            for j in range(ring):
                t.faces.new((a[j], b[j], b[(j + 1) % ring], a[(j + 1) % ring]))
        if not closed:
            t.faces.new(list(reversed(rows[0])))
            t.faces.new(rows[-1])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        return self._merge(t, mat, **kw)

    def lathe(self, profile, loc=(0, 0, 0), rot=(0, 0, 0), mat="Clay", seg=12,
              scale=(1, 1, 1), cap_bottom=True, cap_top=True, smooth=False,
              jag=None, mats=None, **kw):
        """Revolve a list of (radius, z) points around Z. `jag(i, j)` can
        return a radius multiplier for pleats/flutes."""
        t = self._tbm()
        rows = []
        for j, (r, z) in enumerate(profile):
            row = []
            for i in range(seg):
                a = 2 * math.pi * i / seg
                rr = r * (jag(i, j) if jag else 1.0)
                row.append(t.verts.new((rr * math.cos(a), rr * math.sin(a), z)))
            rows.append(row)
        for j in range(len(rows) - 1):
            a, b = rows[j], rows[j + 1]
            for i in range(seg):
                t.faces.new((a[i], a[(i + 1) % seg], b[(i + 1) % seg], b[i]))
        if cap_bottom and profile[0][0] > 1e-4:
            t.faces.new(list(reversed(rows[0])))
        if cap_top and profile[-1][0] > 1e-4:
            t.faces.new(rows[-1])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        bmesh.ops.transform(t, matrix=T(loc, rot, scale), verts=t.verts)
        fm = None
        if mats:
            fm = lambda fi: mats(fi % seg, fi // seg) if fi < seg * (len(rows) - 1) else mat
        return self._merge(t, mat, smooth=smooth, mats=fm, **kw)

    def prism(self, pts, depth, loc=(0, 0, 0), rot=(0, 0, 0), mat="Wood",
              matrix=None, center=True, mats=None, **kw):
        """Extrude a 2D polygon (local XY) along local Z."""
        t = self._tbm()
        z0 = -depth / 2 if center else 0.0
        bot = [t.verts.new((x, y, z0)) for x, y in pts]
        top = [t.verts.new((x, y, z0 + depth)) for x, y in pts]
        n = len(pts)
        t.faces.new(list(reversed(bot)))
        t.faces.new(top)
        for i in range(n):
            t.faces.new((bot[i], bot[(i + 1) % n], top[(i + 1) % n], top[i]))
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        ngons = [f for f in t.faces if len(f.verts) > 4]
        if ngons:
            bmesh.ops.triangulate(t, faces=ngons, quad_method="BEAUTY",
                                  ngon_method="BEAUTY")
        m = matrix if matrix is not None else T(loc, rot)
        bmesh.ops.transform(t, matrix=m, verts=t.verts)
        return self._merge(t, mat, mats=mats, **kw)

    def prism_x(self, pts_yz, length, loc=(0, 0, 0), mat="Roof_Red", **kw):
        """Profile drawn in the YZ plane, extruded along X (roofs, rails)."""
        return self.prism(pts_yz, length, matrix=T(loc, (90, 0, 90)), mat=mat, **kw)

    def poly(self, pts, z=0.0, mat="UI_White", loc=(0, 0, 0)):
        """Single flat face in XY (2D UI shapes)."""
        t = self._tbm()
        vs = [t.verts.new((x + loc[0], y + loc[1], z + loc[2])) for x, y in pts]
        f = t.faces.new(vs)
        f.normal_update()
        if f.normal.z < 0:
            f.normal_flip()
        bmesh.ops.triangulate(t, faces=[f], quad_method="BEAUTY", ngon_method="BEAUTY")
        return self._merge(t, mat)

    def custom(self, verts, faces, mat="Cloth_White", matrix=None, smooth=False, **kw):
        t = self._tbm()
        vs = [t.verts.new(v) for v in verts]
        for f in faces:
            t.faces.new([vs[i] for i in f])
        if matrix is not None:
            bmesh.ops.transform(t, matrix=matrix, verts=t.verts)
        return self._merge(t, mat, smooth=smooth, **kw)

    def hip_roof(self, L, D, H, loc=(0, 0, 0), mat="Roof_Red", thick=0.12, rot=(0, 0, 0)):
        """Four-sided hip roof, L along X, D along Y. loc = centre of eave base."""
        hl = L / 2
        hd = D / 2
        rl = max(hl - hd, 0.05)
        top = [(-hl, -hd, 0), (hl, -hd, 0), (hl, hd, 0), (-hl, hd, 0),
               (-rl, 0, H), (rl, 0, H)]
        bot = [(x, y, z - thick) for x, y, z in top]
        verts = top + bot
        faces = [(0, 1, 5, 4), (1, 2, 5), (2, 3, 4, 5), (3, 0, 4),
                 (10, 11, 7, 6), (11, 8, 7), (11, 10, 9, 8), (10, 6, 9),
                 (0, 6, 7, 1), (1, 7, 8, 2), (2, 8, 9, 3), (3, 9, 6, 0)]
        t = self._tbm()
        vs = [t.verts.new(v) for v in verts]
        for f in faces:
            t.faces.new([vs[i] for i in f])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        bmesh.ops.transform(t, matrix=T(loc, rot), verts=t.verts)
        return self._merge(t, mat)

    def gable_roof(self, L, D, H, loc=(0, 0, 0), mat="Roof_Red", thick=0.12,
                   overhang=0.4):
        """Gable roof: ridge along X. loc = centre of eave base."""
        w = D / 2 + overhang
        pts = [(-w, 0), (0, H), (w, 0), (w, -thick), (0, H - thick * 1.4), (-w, -thick)]
        return self.prism_x(pts, L + 2 * overhang, loc=loc, mat=mat)

    # ---- finish -------------------------------------------------------------
    def to_object(self, coll, loc=(0, 0, 0), category="Misc"):
        old = bpy.data.objects.get(self.name)
        if old:
            data = old.data
            bpy.data.objects.remove(old, do_unlink=True)
            if data and data.users == 0 and isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)
        self.bm.verts.index_update()
        self.tag_index = {k: [v.index for v in vs] for k, vs in self.tags.items()}
        self.bm.normal_update()
        me = bpy.data.meshes.new(self.name)
        self.bm.to_mesh(me)
        self.bm.free()
        for m in self.mats:
            me.materials.append(get_mat(m))
        obj = bpy.data.objects.new(self.name, me)
        coll.objects.link(obj)
        for g in self.groups:
            obj.vertex_groups.new(name=g)
        obj.location = loc
        obj["mylife_category"] = category
        obj["mylife_export"] = True
        return obj



# =============================================================================
#  CAR CONFIG  (metres; car faces -Y in Blender -> +Z forward in Unity)
# =============================================================================
L = 4.60
HL = L / 2
AX_F, AX_R = 1.18, 3.86            # axle positions from the nose
R_F, R_R = 0.335, 0.355            # tyre outer radius
TW_F, TW_R = 0.27, 0.33            # tyre width
RIM_F, RIM_R = 0.255, 0.27         # rim radius
WX_F, WX_R = 0.85, 0.835           # wheel centre |x|

W = [(0, 0.70), (0.15, 0.86), (0.4, 0.94), (0.85, 0.975), (1.18, 0.985), (1.6, 0.97),
     (2.15, 0.935), (2.65, 0.945), (3.15, 0.985), (3.55, 1.0), (3.95, 1.0), (4.35, 0.985),
     (4.6, 0.93)]
ZB = [(0, 0.17), (0.3, 0.115), (4.3, 0.115), (4.6, 0.20)]
ZMID = [(0, 0.38), (0.6, 0.46), (2.4, 0.48), (4.6, 0.54)]
ZSH = [(0, 0.50), (0.3, 0.62), (0.8, 0.735), (1.18, 0.775), (1.65, 0.725), (2.2, 0.735),
       (2.9, 0.79), (3.5, 0.875), (3.9, 0.89), (4.35, 0.86), (4.6, 0.80)]
ZHOOD = [(0, 0.48), (0.3, 0.58), (0.9, 0.665), (1.5, 0.735), (1.85, 0.785), (2.2, 0.80),
         (3.0, 0.84), (3.4, 0.90), (3.9, 0.915), (4.35, 0.90), (4.6, 0.82)]
ZROOF = [(1.84, 0.785), (2.05, 0.93), (2.3, 1.07), (2.55, 1.13), (2.85, 1.14), (3.15, 1.10),
         (3.5, 1.01), (3.85, 0.94), (4.05, 0.915)]
BOUNDS = [0.55, 1.55, 1.84, 1.95, 2.15, 2.40, 2.95, 3.05, 3.30, 3.45, 4.15]


def pchip(keys, s):
    xs = [k[0] for k in keys]
    ys = [k[1] for k in keys]
    n = len(xs)
    if s <= xs[0]:
        return ys[0]
    if s >= xs[-1]:
        return ys[-1]
    d = [(ys[i + 1] - ys[i]) / (xs[i + 1] - xs[i]) for i in range(n - 1)]
    m = [d[0]] + [0.0 if d[i - 1] * d[i] <= 0 else 2.0 / (1.0 / d[i - 1] + 1.0 / d[i])
                  for i in range(1, n - 1)] + [d[-1]]
    i = max(j for j in range(n - 1) if xs[j] <= s)
    h = xs[i + 1] - xs[i]
    t = (s - xs[i]) / h
    return ((2 * t ** 3 - 3 * t ** 2 + 1) * ys[i] + (t ** 3 - 2 * t ** 2 + t) * h * m[i] +
            (-2 * t ** 3 + 3 * t ** 2) * ys[i + 1] + (t ** 3 - t ** 2) * h * m[i + 1])


def cabin(s):
    if ZROOF[0][0] < s < ZROOF[-1][0]:
        return max(pchip(ZROOF, s) - pchip(ZHOOD, s), 0.0)
    return 0.0


def section(s):
    """11 points (x, z) of the right half-section, bottom centre -> top centre."""
    w, zb, zm = pchip(W, s), pchip(ZB, s), pchip(ZMID, s)
    zs, zh = pchip(ZSH, s), pchip(ZHOOD, s)
    c = cabin(s)
    k = min(max(c / 0.10, 0.0), 1.0)
    x7 = (w - 0.19) * (1 - k) + 0.80 * k

    def hood(x):
        return zh + (zs - 0.015 - zh) * (x / x7) ** 2
    x8 = 0.55 * x7 * (1 - k) + 0.74 * k
    x9 = 0.24 * x7 * (1 - k) + 0.56 * k
    return [(0.0, zb), (w - 0.13, zb), (w - 0.035, zb + 0.045), (w, zb + 0.19),
            (w + 0.005, zm), (w - 0.015, zs - 0.045), (w - 0.085, zs), (x7, hood(x7)),
            (x8, hood(x8) + 0.62 * c), (x9, hood(x9) + c), (0.0, hood(0.0) + c + 0.012 * k)]


def surf(s, jf, side):
    s = min(max(s, 0.0), L)
    jf = min(max(jf, 0.0), 10.0)
    pts = section(s)
    j = min(int(jf), 9)
    t = jf - j
    x = pts[j][0] * (1 - t) + pts[j + 1][0] * t
    z = pts[j][1] * (1 - t) + pts[j + 1][1] * t
    return Vector((side * x, s - HL, z))


def surf_normal(s, jf, side):
    ds = surf(s + 0.01, jf, side) - surf(s - 0.01, jf, side)
    dj = surf(s, jf + 0.05, side) - surf(s, jf - 0.05, side)
    n = ds.cross(dj)
    if n.length < 1e-9:
        n = Vector((side, 0, 0))
    n.normalize()
    p = surf(s, jf, side)
    if n.dot(p - Vector((0, p.y, 0.55))) < 0:
        n = -n
    return n


def jf_for_x(s, x):
    pts = section(s)
    for j in range(7, 10):
        x0, x1 = pts[j][0], pts[j + 1][0]
        if (x0 - x) * (x1 - x) <= 0 and x0 != x1:
            return j + (x0 - x) / (x0 - x1)
    return 8.0


def stations():
    st = [round(i * 0.06, 4) for i in range(int(L / 0.06) + 1)] + [L] + BOUNDS
    st = sorted(set(round(x, 4) for x in st))
    keep = []
    for x in st:
        if x in BOUNDS or x in (0.0, L) or min(abs(x - b) for b in BOUNDS) > 0.02:
            keep.append(x)
    return keep


# =============================================================================
#  MATERIALS + TEXTURES
# =============================================================================
MATDEF = {
    "CarPaint": dict(c="#F4C20D", m=0.35, r=0.30, coat=1.0, coat_r=0.03),
    "Carbon": dict(c="#FFFFFF", m=0.1, r=0.38, coat=0.25, coat_r=0.12, tex="T_Carbon"),
    "Glass": dict(c="#06090C", r=0.02, alpha=0.62),
    "Glass_Dark": dict(c="#0A0D10", r=0.05),
    "Rubber": dict(c="#151515", r=0.88, nrm="T_Tire_Normal"),
    "RimBlack": dict(c="#0D0E10", m=0.55, r=0.22, coat=0.6),
    "Metal": dict(c="#8C8F94", m=1.0, r=0.32),
    "Metal_Dark": dict(c="#3A3C40", m=1.0, r=0.45),
    "Chrome": dict(c="#E2E4E8", m=1.0, r=0.05),
    "Plastic_Black": dict(c="#111113", r=0.65),
    "Plastic_Gloss": dict(c="#060607", r=0.08, coat=0.5),
    "Grille": dict(c="#FFFFFF", r=0.5, tex="T_Grille"),
    "Leather": dict(c="#1E1A19", r=0.55),
    "BrakeDisc": dict(c="#707276", m=1.0, r=0.42),
    "Caliper": dict(c="#F2B705", m=0.1, r=0.3, coat=0.6),
    "LED_Head": dict(c="#EEF3FF", r=0.2, em="#F4F8FF", es=3.0),
    "Light_Turn_L": dict(c="#B86000", r=0.2, em="#FF8C00", es=0.0),
    "Light_Turn_R": dict(c="#B86000", r=0.2, em="#FF8C00", es=0.0),
    "Light_Tail": dict(c="#560000", r=0.2, em="#FF1010", es=1.5),
    "Light_Brake": dict(c="#640000", r=0.2, em="#FF0000", es=0.0),
    "Light_Reverse": dict(c="#D0D0D0", r=0.2, em="#FFFFFF", es=0.0),
}
TILE = {"Carbon": 4.0, "Grille": 5.0, "Leather": 2.0, "Rubber": "cyl"}
TEX_DIR = [None]


def _setin(bsdf, names, val):
    for n in names:
        if n in bsdf.inputs:
            bsdf.inputs[n].default_value = val
            return bsdf.inputs[n]
    return None


def get_mat(key):
    name = "MAT_" + key
    m = bpy.data.materials.get(name)
    if m:
        return m
    d = MATDEF[key]
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    col = hex_rgba(d["c"])
    m.diffuse_color = col
    bsdf.inputs["Base Color"].default_value = col
    bsdf.inputs["Metallic"].default_value = d.get("m", 0.0)
    bsdf.inputs["Roughness"].default_value = d.get("r", 0.5)
    if d.get("coat"):
        _setin(bsdf, ["Coat Weight", "Clearcoat"], d["coat"])
        _setin(bsdf, ["Coat Roughness", "Clearcoat Roughness"], d.get("coat_r", 0.05))
    if "em" in d:
        _setin(bsdf, ["Emission Color", "Emission"], hex_rgba(d["em"]))
        _setin(bsdf, ["Emission Strength"], d["es"])
    if "alpha" in d:
        bsdf.inputs["Alpha"].default_value = d["alpha"]
        if hasattr(m, "surface_render_method"):
            m.surface_render_method = "BLENDED"
        if hasattr(m, "blend_method"):
            try:
                m.blend_method = "BLEND"
            except Exception:
                pass
    for slot, socket, noncolor in (("tex", "Base Color", False), ("nrm", None, True)):
        tname = d.get(slot)
        if not tname:
            continue
        img = bpy.data.images.get(tname)
        if img is None:
            continue
        tn = nt.nodes.new("ShaderNodeTexImage")
        tn.image = img
        if slot == "tex":
            nt.links.new(tn.outputs["Color"], bsdf.inputs["Base Color"])
            nimg = bpy.data.images.get(tname.replace("_BaseColor", "") + "_Normal")
            if nimg is None:
                nimg = bpy.data.images.get(tname + "_Normal")
            if nimg:
                d2 = dict(d)
                _hook_normal(nt, bsdf, nimg)
        else:
            _hook_normal(nt, bsdf, img, tn)
    m["mylife_car"] = key
    return m


def _hook_normal(nt, bsdf, img, tn=None):
    if tn is None:
        tn = nt.nodes.new("ShaderNodeTexImage")
        tn.image = img
    nm = nt.nodes.new("ShaderNodeNormalMap")
    nt.links.new(tn.outputs["Color"], nm.inputs["Color"])
    nt.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])


def make_textures(tex_dir):
    import numpy as np
    os.makedirs(tex_dir, exist_ok=True)
    TEX_DIR[0] = tex_dir

    def save(name, rgb, noncolor):
        h, w = rgb.shape[:2]
        img = bpy.data.images.get(name)
        if img:
            bpy.data.images.remove(img)
        img = bpy.data.images.new(name, w, h, alpha=False, float_buffer=False)
        if noncolor:
            img.colorspace_settings.name = "Non-Color"
        px = np.ones((h, w, 4), dtype=np.float32)
        px[..., :3] = rgb
        img.pixels.foreach_set(px.ravel())
        path = os.path.join(tex_dir, name + ".png")
        img.filepath_raw = path
        img.file_format = "PNG"
        img.save()
        return img

    def normal(hgt, k):
        gy, gx = np.gradient(hgt)
        n = np.dstack((-gx * k, -gy * k, np.ones_like(hgt)))
        n /= np.linalg.norm(n, axis=2, keepdims=True)
        return n * 0.5 + 0.5

    N = 1024
    j, i = np.meshgrid(np.arange(N), np.arange(N))
    cell = 32
    ti, tj = i // cell, j // cell
    fi, fj = (i % cell) / cell, (j % cell) / cell
    dirn = ((ti + tj) % 2).astype(bool)
    along = np.where(dirn, fj, fi)
    across = np.where(dirn, fi, fj)
    hgt = np.sin(np.pi * across) * 0.7 + 0.15 * np.cos(2 * np.pi * along * 5)
    base = 0.035 + 0.075 * hgt
    rgb = np.dstack((base, base * 1.02, base * 1.1))
    save("T_Carbon", np.clip(rgb, 0, 1), False)
    save("T_Carbon_Normal", normal(hgt, 3.0), True)

    G = 512
    j, i = np.meshgrid(np.arange(G), np.arange(G))
    a = ((i + j) / 22.0) % 1.0
    b = ((i - j) / 22.0) % 1.0
    bars = np.maximum(np.clip(1 - np.abs(a - 0.5) * 9, 0, 1), np.clip(1 - np.abs(b - 0.5) * 9, 0, 1))
    hgt = bars
    base = 0.01 + 0.05 * bars
    save("T_Grille", np.dstack((base, base, base)), False)
    save("T_Grille_Normal", normal(hgt, 4.0), True)

    T_ = 1024
    j, i = np.meshgrid(np.arange(T_), np.arange(T_))
    u, v = j / T_, i / T_
    grooves = np.zeros_like(u)
    for c in (0.28, 0.5, 0.72):
        grooves = np.maximum(grooves, np.clip(1 - np.abs(v - c) / 0.025, 0, 1))
    sipes = np.clip(1 - np.abs(((u * 6 + v * 1.5) % 1.0) - 0.5) / 0.04, 0, 1) * 0.5
    hgt = 1 - np.maximum(grooves, sipes)
    save("T_Tire_Normal", normal(hgt, 4.0), True)


# =============================================================================
#  BUILDER EXTENSIONS
# =============================================================================
class CarBuilder(Builder):
    def ring(self, profile, seg=32, matrix=None, mat="Metal", **kw):
        """Closed profile (r, z) revolved around Z -> closed manifold solid."""
        t = self._tbm()
        rows = []
        for (r, z) in profile:
            rows.append([t.verts.new((r * math.cos(2 * math.pi * i / seg),
                                      r * math.sin(2 * math.pi * i / seg), z))
                         for i in range(seg)])
        n = len(rows)
        for j in range(n):
            a, b2 = rows[j], rows[(j + 1) % n]
            for i in range(seg):
                t.faces.new((a[i], a[(i + 1) % seg], b2[(i + 1) % seg], b2[i]))
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        if matrix is not None:
            bmesh.ops.transform(t, matrix=matrix, verts=t.verts)
        return self._merge(t, mat, **kw)

    def solid(self, verts, faces, mat, **kw):
        t = self._tbm()
        vs = [t.verts.new(v) for v in verts]
        for f in faces:
            t.faces.new([vs[i] for i in f])
        bmesh.ops.recalc_face_normals(t, faces=t.faces)
        return self._merge(t, mat, **kw)

    def quadbox(self, c8, mat, **kw):
        """8 corners: bottom 0-3, top 4-7 (same winding)."""
        return self.solid(c8, [(0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5),
                               (2, 3, 7, 6), (3, 0, 4, 7)], mat, **kw)

    def decal(self, fn, nu, nv, side, off, thick, mat):
        """Thin solid patch that follows the body surface. fn(u,v)->(s, jf)."""
        top, bot = [], []
        for iu in range(nu + 1):
            for iv in range(nv + 1):
                s, jf = fn(iu / nu, iv / nv)
                p, n = surf(s, jf, side), surf_normal(s, jf, side)
                top.append(p + n * (off + thick))
                bot.append(p + n * off)
        N = len(top)
        idx = lambda a, b_: a * (nv + 1) + b_
        faces = []
        for iu in range(nu):
            for iv in range(nv):
                a, b_, c, d = idx(iu, iv), idx(iu + 1, iv), idx(iu + 1, iv + 1), idx(iu, iv + 1)
                faces += [(a, b_, c, d), (N + d, N + c, N + b_, N + a)]
        border = ([idx(iu, 0) for iu in range(nu)] + [idx(nu, iv) for iv in range(nv)] +
                  [idx(iu, nv) for iu in range(nu, 0, -1)] + [idx(0, iv) for iv in range(nv, 0, -1)])
        for k in range(len(border)):
            p, q = border[k], border[(k + 1) % len(border)]
            faces.append((p, q, N + q, N + p))
        return self.solid([tuple(v) for v in top + bot], faces, mat)


# =============================================================================
#  SCENE ORGANISATION
# =============================================================================
COLL_TREE = {
    "Car_Root": None, "Body": "Car_Root", "Exterior": "Car_Root", "Hood": "Exterior",
    "Doors": "Exterior", "Bumpers": "Exterior", "Spoiler": "Exterior", "Mirrors": "Exterior",
    "Glass": "Car_Root", "Lights": "Car_Root", "Headlights": "Lights", "Taillights": "Lights",
    "Wheels": "Car_Root", "Wheel_FL": "Wheels", "Wheel_FR": "Wheels", "Wheel_RL": "Wheels",
    "Wheel_RR": "Wheels", "Brakes": "Car_Root", "Exhaust": "Car_Root", "Interior": "Car_Root",
}
PIVOTS = {}


def coll(name):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
        parent = COLL_TREE.get(name)
        (bpy.data.collections[parent] if parent else bpy.context.scene.collection).children.link(c)
    return c


def clear_car():
    for o in list(bpy.data.objects):
        if o.name.startswith(("CAR_", "ML_Cut")):
            bpy.data.objects.remove(o, do_unlink=True)
    for me in list(bpy.data.meshes):
        if me.users == 0:
            bpy.data.meshes.remove(me)
    for name in COLL_TREE:
        coll(name)


def empty(name, pivot, parent=None, collection="Car_Root", rot=(0, 0, 0)):
    o = bpy.data.objects.new(name, None)
    o.empty_display_type = "PLAIN_AXES"
    o.empty_display_size = 0.15
    coll(collection).objects.link(o)
    _parent(o, pivot, parent)
    o.rotation_euler = [math.radians(a) for a in rot]
    return o


def _parent(o, pivot, parent):
    PIVOTS[o.name] = Vector(pivot)
    if parent is not None:
        o.parent = parent
        o.location = Vector(pivot) - PIVOTS[parent.name]
    else:
        o.location = Vector(pivot)


def merge_mesh(b, me):
    for f in b.bm.faces:
        f.tag = True
    b.bm.from_mesh(me)
    names = [m.name[4:] if m else "Plastic_Black" for m in me.materials]
    for f in b.bm.faces:
        if not f.tag:
            f.material_index = b._mi(names[f.material_index] if names else "Plastic_Black")
            f.tag = True


def finalize(b, name, collection, pivot=(0, 0, 0), parent=None, sharp_deg=38.0, uv=True):
    bm = b.bm
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
    for f in bm.faces:
        f.smooth = True
    for e in bm.edges:
        e.smooth = len(e.link_faces) == 2 and e.calc_face_angle(0.0) < math.radians(sharp_deg)
    bm.normal_update()
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    me.transform(Matrix.Translation(-Vector(pivot)))
    if hasattr(me, "use_auto_smooth"):
        me.use_auto_smooth = True
        me.auto_smooth_angle = math.pi
    for k in b.mats:
        me.materials.append(get_mat(k))
    obj = bpy.data.objects.new(name, me)
    coll(collection).objects.link(obj)
    _parent(obj, pivot, parent)
    if uv:
        unwrap(obj)
    return obj


def unwrap(obj):
    """UV0: Smart UV Project (organised islands for 2K/4K painting/baking);
    tiling materials (carbon, grille, leather, tyre tread) get metric UVs."""
    vl = bpy.context.view_layer
    try:
        vl.update()
        for o in list(vl.objects):
            if o is not None and o != obj:
                o.select_set(False)
        obj.select_set(True)
        vl.objects.active = obj
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.004)
        bpy.ops.object.mode_set(mode="OBJECT")
    except Exception as ex:
        print("smart_project failed on", obj.name, ex)
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    me = obj.data
    keys = [m.name[4:] for m in me.materials]
    if not any(k in TILE for k in keys):
        return
    bm = bmesh.new()
    bm.from_mesh(me)
    uvl = bm.loops.layers.uv.verify()
    for f in bm.faces:
        mode = TILE.get(keys[f.material_index]) if f.material_index < len(keys) else None
        if mode is None:
            continue
        if mode == "cyl":
            us = []
            for l in f.loops:
                co = l.vert.co
                us.append(math.atan2(co.z, co.y) / (2 * math.pi) * 24.0)
            u0 = us[0]
            for l, u in zip(f.loops, us):
                while u - u0 > 12:
                    u -= 24
                while u0 - u > 12:
                    u += 24
                l[uvl].uv = (u, l.vert.co.x * 8.0)
            continue
        n = f.normal
        ax = max(range(3), key=lambda a: abs(n[a]))
        for l in f.loops:
            co = l.vert.co
            p = (co.y, co.z) if ax == 0 else ((co.x, co.z) if ax == 1 else (co.x, co.y))
            l[uvl].uv = (p[0] * mode, p[1] * mode)
    bm.to_mesh(me)
    bm.free()


# =============================================================================
#  BODY SHELL (lofted sections -> separate panels -> solidify + wheel arches)
# =============================================================================
def part_of(sm, band, side):
    S = "L" if side > 0 else "R"
    if sm < 0.55:
        return "FrontBumper", ("Plastic_Black" if band == 0 else "CarPaint")
    if sm > 4.15:
        return "RearBumper", ("Plastic_Black" if band == 0 else "CarPaint")
    if band == 0:
        return "Body", "Plastic_Black"
    if band in (1, 2):
        if 1.55 <= sm <= 3.45:
            return "SideSkirt_" + S, "Carbon"
        if sm < 1.55:
            return "Fender_F_" + S, "CarPaint"
    if 3 <= band <= 6:
        if 1.95 <= sm <= 2.95:
            return "Door_" + S, "CarPaint"
        if sm < 1.95:
            return "Fender_F_" + S, "CarPaint"
    if band >= 7 and sm < 1.84:
        return "Hood", "CarPaint"
    if band >= 8:
        if sm < 2.40:
            return "Glass_Windshield", "Glass"
        if sm < 2.95:
            return "Body", "Carbon"            # carbon roof
        if sm < 3.30:
            return "Glass_Rear", "Glass"
        if sm <= 4.15:
            return "EngineCover", "CarPaint"
    if band == 7 and 2.15 <= sm <= 2.95:
        return "Glass_Side_" + S, "Glass"
    return "Body", "CarPaint"


class RawPart:
    def __init__(self):
        self.bm = bmesh.new()
        self.bm.loops.layers.uv.verify()
        self.vmap = {}
        self.mats = []

    def v(self, key, co):
        if key not in self.vmap:
            self.vmap[key] = self.bm.verts.new(co)
        return self.vmap[key]

    def face(self, keys, cos, mat, outward=None):
        vs = [self.v(k, c) for k, c in zip(keys, cos)]
        f = self.bm.faces.new(vs)
        f.normal_update()
        c = f.calc_center_median()
        ref = outward if outward is not None else (c - Vector((0, c.y, 0.55)))
        if f.normal.dot(ref) < 0:
            f.normal_flip()
        if mat not in self.mats:
            self.mats.append(mat)
        f.material_index = self.mats.index(mat)


def build_shell():
    ST = stations()
    secs = [section(s) for s in ST]
    parts = {}

    def key(i, j, side):
        return (i, j, 0 if j in (0, 10) else side)

    def co(i, j, side):
        x, z = secs[i][j]
        return (side * x if j not in (0, 10) else 0.0, ST[i] - HL, z)
    for i in range(len(ST) - 1):
        sm = (ST[i] + ST[i + 1]) / 2
        for side in (1, -1):
            for j in range(10):
                part, mat = part_of(sm, j, side)
                ks = [key(i, j, side), key(i + 1, j, side), key(i + 1, j + 1, side), key(i, j + 1, side)]
                cs = [co(i, j, side), co(i + 1, j, side), co(i + 1, j + 1, side), co(i, j + 1, side)]
                parts.setdefault(part, RawPart()).face(ks, cs, mat)
    for i, part, out in ((0, "FrontBumper", Vector((0, -1, 0))),
                         (len(ST) - 1, "RearBumper", Vector((0, 1, 0)))):
        loop = [0] + list(range(1, 11)) + list(range(9, 0, -1))
        sides = [0] + [1] * 10 + [-1] * 9
        ks = [key(i, j, s) for j, s in zip(loop, sides)]
        cs = [co(i, j, s if s else 1) for j, s in zip(loop, sides)]
        rp = parts[part]
        vs = [rp.v(k, c) for k, c in zip(ks, cs)]
        f = rp.bm.faces.new(vs)
        f.normal_update()
        if f.normal.dot(out) < 0:
            f.normal_flip()
        f.material_index = rp.mats.index("CarPaint")
        bmesh.ops.triangulate(rp.bm, faces=[f], quad_method="BEAUTY", ngon_method="BEAUTY")
    return parts


def arch_cutters():
    tmp = coll("Car_Root")
    cut = {}
    for tag, ax, r in (("F", AX_F, R_F), ("R", AX_R, R_R)):
        for side in (1, -1):
            b = CarBuilder("ML_Cut_%s%d" % (tag, side))
            b.cyl(r + 0.04, r + 0.04, 0.98, loc=(side * 1.01, ax - HL, r), rot=(0, 90, 0),
                  mat="Plastic_Black", seg=48)
            me = bpy.data.meshes.new(b.name)
            b.bm.to_mesh(me)
            b.bm.free()
            me.materials.append(get_mat("Plastic_Black"))
            o = bpy.data.objects.new(b.name, me)
            tmp.objects.link(o)
            o.hide_render = True
            cut[(tag, side)] = o
    return cut


def bake_part(raw, name, cutters, thick=0.012):
    me = bpy.data.meshes.new(name + "_raw")
    raw.bm.to_mesh(me)
    raw.bm.free()
    for m in raw.mats:
        me.materials.append(get_mat(m))
    ob = bpy.data.objects.new("ML_Cut_tmp_" + name, me)
    coll("Car_Root").objects.link(ob)
    sol = ob.modifiers.new("Solidify", "SOLIDIFY")
    sol.thickness = thick
    sol.offset = -1.0
    sol.use_rim = True
    sol.use_even_offset = True
    for c in cutters:
        bo = ob.modifiers.new("Arch", "BOOLEAN")
        bo.operation = "DIFFERENCE"
        bo.solver = "EXACT"
        bo.object = c
        if hasattr(bo, "material_mode"):
            bo.material_mode = "TRANSFER"
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    out = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    bpy.data.objects.remove(ob, do_unlink=True)
    bpy.data.meshes.remove(me)
    return out


# =============================================================================
#  ASSEMBLY
# =============================================================================
def build_car():
    clear_car()
    root = empty("CAR_Root", (0, 0, 0))
    parts = build_shell()
    cut = arch_cutters()
    cutmap = {
        "Body": [cut[k] for k in cut], "RearBumper": [cut[("R", 1)], cut[("R", -1)]],
        "Fender_F_L": [cut[("F", 1)]], "Fender_F_R": [cut[("F", -1)]],
        "SideSkirt_L": [cut[("F", 1)]], "SideSkirt_R": [cut[("F", -1)]],
    }
    baked = {n: bake_part(p, n, cutmap.get(n, []), 0.006 if n.startswith("Glass") else 0.012)
             for n, p in parts.items()}
    for o in cut.values():
        bpy.data.objects.remove(o, do_unlink=True)
    objs = {}

    # ---- body: shell + wheel-well liners + side intakes -----------------------
    b = CarBuilder("CAR_Body")
    merge_mesh(b, baked["Body"])
    for ax, r in ((AX_F, R_F), (AX_R, R_R)):
        pts = arc_band_pts(r + 0.045, r + 0.06, -10, 190, 24, ax - HL, r)
        for side in (1, -1):
            b.prism_x(pts, 0.48, loc=(side * 0.72, 0, 0), mat="Plastic_Black")
    for side in (1, -1):
        b.decal(lambda u, v: (3.0 + 0.42 * u, (4.0 + 1.1 * u) * (1 - v) + 5.6 * v),
                6, 3, side, 0.0005, 0.004, "Plastic_Black")
        b.decal(lambda u, v: (2.97 + 0.48 * u, 5.6 + 0.3 * v), 6, 1, side, 0.0005, 0.016,
                "Carbon")
    objs["Body"] = finalize(b, "CAR_Body", "Body", (0, 0, 0), root)

    # ---- simple panels ----------------------------------------------------------
    def panel(key, name, collection, pivot=(0, 0, 0), parent=None, extras=None):
        b = CarBuilder(name)
        merge_mesh(b, baked[key])
        if extras:
            extras(b)
        o = finalize(b, name, collection, pivot, parent or root)
        objs[key] = o
        return o

    def front_extras(b):
        y = -HL - 0.015
        m = T((0, y, 0), (90, 0, 0))
        b.prism(rounded_rect_pts(0.60, 0.12, 0.03, 0, 0.26), 0.03, matrix=m, mat="Grille")
        for s in (1, -1):
            pts = [(0.36 * s, 0.20), (0.64 * s, 0.20), (0.62 * s, 0.40), (0.40 * s, 0.34)]
            b.prism(pts if s > 0 else pts[::-1], 0.03, matrix=m, mat="Grille")
        b.prism([(-0.66, 0.172), (0.66, 0.172), (0.66, 0.19), (-0.66, 0.19)], 0.03, matrix=m,
                mat="Plastic_Black")

    def rear_extras(b):
        m = T((0, HL + 0.015, 0), (90, 0, 0))
        b.prism(rounded_rect_pts(0.72, 0.15, 0.03, 0, 0.545), 0.03, matrix=m, mat="Grille")
    panel("FrontBumper", "CAR_FrontBumper", "Bumpers", extras=front_extras)
    panel("RearBumper", "CAR_RearBumper", "Bumpers", extras=rear_extras)
    for S in ("L", "R"):
        panel("Fender_F_" + S, "CAR_Fender_F_" + S, "Exterior")
        panel("SideSkirt_" + S, "CAR_SideSkirt_" + S, "Exterior")
    hood_piv = (0, 1.84 - HL, pchip(ZHOOD, 1.84))

    def hood_extras(b):
        for side in (1, -1):
            b.decal(lambda u, v: (0.72 + 0.30 * u, 8.55 + 1.45 * v), 6, 4, side, 0.0005, 0.005,
                    "Plastic_Black")
    panel("Hood", "CAR_Hood", "Hood", hood_piv, extras=hood_extras)
    ec_piv = (0, 3.30 - HL, surf(3.30, 10, 1).z)

    def cover_extras(b):
        for k in range(5):
            s0 = 3.45 + k * 0.11
            for side in (1, -1):
                b.decal(lambda u, v, s0=s0: (s0 + 0.05 * u, 8.35 + 1.65 * v), 2, 4, side,
                        0.0005, 0.006, "Plastic_Black")
    panel("EngineCover", "CAR_EngineCover", "Exterior", ec_piv, extras=cover_extras)
    panel("Glass_Windshield", "CAR_Glass_Windshield", "Glass")
    panel("Glass_Rear", "CAR_Glass_Rear", "Glass")

    # ---- doors (scissor hinge at the front), side glass, mirrors, door cards -----
    for S, side in (("L", 1), ("R", -1)):
        hinge = surf(1.96, 6.3, side)
        door = panel("Door_" + S, "CAR_Door_" + S, "Doors", hinge)
        door["hinge_axis"] = "X (scissor, opens upward)"
        g = CarBuilder("CAR_Glass_Side_" + S)
        merge_mesh(g, baked["Glass_Side_" + S])
        finalize(g, "CAR_Glass_Side_" + S, "Glass", hinge, door)
        dp = CarBuilder("CAR_DoorPanel_" + S)
        dp.decal(lambda u, v: (2.0 + 0.9 * u, 3.3 + 3.3 * v), 8, 6, side, -0.05, 0.022, "Leather")
        dp.decal(lambda u, v: (2.25 + 0.45 * u, 5.0 + 0.5 * v), 4, 2, side, -0.03, 0.01, "Carbon")
        finalize(dp, "CAR_DoorPanel_" + S, "Interior", hinge, door)
        base = surf(2.12, 6.85, side)
        mb = CarBuilder("CAR_Mirror_" + S)
        pod = base + Vector((side * 0.15, 0.02, 0.08))
        mb.cyl_between(base, pod - Vector((side * 0.06, 0, 0)), 0.014, mat="Plastic_Gloss", seg=12)
        mb.box((0.17, 0.10, 0.08), loc=pod, rot=(0, 0, -8 * side), mat="Plastic_Gloss",
               bevel=0.03, seg=3)
        mb.box((0.145, 0.006, 0.062), loc=pod + Vector((0, 0.051, 0)), rot=(0, 0, -8 * side),
               mat="Chrome")
        finalize(mb, "CAR_Mirror_" + S, "Mirrors", base, door)

    # ---- lights -------------------------------------------------------------------
    for S, side in (("L", 1), ("R", -1)):
        hb = CarBuilder("CAR_Headlight_" + S)
        hb.decal(lambda u, v: (0.04 + 0.50 * u, 4.95 + 1.65 * u + 1.05 * v * (1 - 0.55 * u)),
                 10, 2, side, 0.0005, 0.008, "Plastic_Gloss")
        hb.decal(lambda u, v: (0.08 + 0.42 * u, 5.15 + 1.62 * u + 0.22 * v), 8, 1, side,
                 0.0085, 0.004, "LED_Head")
        hb.decal(lambda u, v: (0.055 + 0.05 * u, 5.10 + 0.08 * u + 0.45 * v), 2, 2, side,
                 0.0085, 0.003, "Light_Turn_" + S)
        m = T((0, -HL - 0.015, 0), (90, 0, 0))
        pts = [(0.44 * side, 0.40), (0.66 * side, 0.43), (0.67 * side, 0.45), (0.46 * side, 0.445)]
        hb.prism(pts if side > 0 else pts[::-1], 0.03, matrix=m, mat="Plastic_Gloss")
        pts = [(0.47 * side, 0.415), (0.64 * side, 0.435), (0.645 * side, 0.442), (0.475 * side, 0.425)]
        hb.prism(pts if side > 0 else pts[::-1], 0.036, matrix=m, mat="LED_Head")
        finalize(hb, "CAR_Headlight_" + S, "Headlights", surf(0.2, 6.0, side), root)

        tb = CarBuilder("CAR_Taillight_" + S)
        m = T((0, HL + 0.015, 0), (90, 0, 0))
        segs = [(0.42, 0.52, "Light_Reverse"), (0.52, 0.76, "Light_Brake"),
                (0.76, 0.84, "Light_Tail"), (0.84, 0.90, "Light_Turn_" + S)]
        for x0, x1, mt in segs:
            x0, x1 = x0 + 0.002, x1 - 0.002
            z0a, z0b = 0.665 + (x0 - 0.42) * 0.11, 0.70 + (x0 - 0.42) * 0.04
            z1a, z1b = 0.665 + (x1 - 0.42) * 0.11, 0.70 + (x1 - 0.42) * 0.04
            pts = [(x0 * side, z0a), (x1 * side, z1a), (x1 * side, z1b), (x0 * side, z0b)]
            tb.prism(pts if side > 0 else pts[::-1], 0.03, matrix=m, mat=mt)
        tb.decal(lambda u, v: (4.40 + 0.19 * u, 5.05 + 0.35 * v), 4, 2, side, 0.0005, 0.006,
                 "Light_Tail")
        finalize(tb, "CAR_Taillight_" + S, "Taillights", (0.7 * side, HL, 0.7), root)

    # ---- splitter, diffuser, exhaust, spoiler ---------------------------------------
    sb = CarBuilder("CAR_Splitter")
    sb.prism([(-0.66, -2.36), (0.66, -2.36), (0.90, -2.05), (0.92, -1.80), (-0.92, -1.80),
              (-0.90, -2.05)], 0.014, loc=(0, 0, 0.088), mat="Carbon")
    finalize(sb, "CAR_Splitter", "Bumpers", (0, -2.0, 0.088), root)

    db = CarBuilder("CAR_Diffuser")
    zbot = lambda y: 0.08 + (y - 1.75) / 0.67 * 0.11
    db.prism_x([(1.75, 0.095), (2.42, 0.205), (2.42, 0.19), (1.75, 0.08)], 1.5, mat="Carbon")
    for x in (-0.6, -0.3, 0.0, 0.3, 0.6):
        db.prism_x([(1.95, zbot(1.95)), (2.42, zbot(2.42)), (2.42, 0.10)], 0.012, loc=(x, 0, 0),
                   mat="Carbon")
    finalize(db, "CAR_Diffuser", "Bumpers", (0, 2.1, 0.15), root)

    eb = CarBuilder("CAR_Exhaust")
    for x in (-0.21, -0.08, 0.08, 0.21):
        m = T((x, HL, 0.33), (-90, 0, 0))
        eb.ring([(0.040, 0.0), (0.047, 0.0), (0.051, 0.10), (0.047, 0.12), (0.041, 0.12)],
                seg=24, matrix=m, mat="Chrome")
        eb.cyl(0.0405, 0.0405, 0.01, matrix=m @ T((0, 0, 0.03)), mat="Plastic_Black", seg=24)
    finalize(eb, "CAR_Exhaust", "Exhaust", (0, HL, 0.33), root)

    yw, zw = 4.18 - HL, 1.20
    wb = CarBuilder("CAR_Spoiler")
    a = math.radians(-8)
    foil = [(-0.18, 0.0), (-0.12, 0.022), (0.0, 0.03), (0.12, 0.022), (0.18, 0.006), (0.18, -0.004),
            (0.0, -0.008), (-0.12, -0.006)]
    foil = [(yw + y * math.cos(a) - z * math.sin(a), zw + y * math.sin(a) + z * math.cos(a)) for y, z in foil]
    wb.prism_x(foil, 1.86, mat="Carbon")
    for s in (1, -1):
        wb.prism_x([(yw - 0.24, zw - 0.10), (yw + 0.22, zw - 0.08), (yw + 0.22, zw + 0.10),
                    (yw - 0.20, zw + 0.07)], 0.012, loc=(s * 0.936, 0, 0), mat="Carbon")
    sp = finalize(wb, "CAR_Spoiler", "Spoiler", (0, yw, zw), root)
    mbd = CarBuilder("CAR_SpoilerMount")
    for s in (1, -1):
        jf0, jf1 = jf_for_x(4.04, 0.40), jf_for_x(4.24, 0.40)
        z0, z1 = surf(4.04, jf0, 1).z, surf(4.24, jf1, 1).z
        mbd.prism_x([(4.04 - HL, z0), (4.24 - HL, z1), (yw + 0.06, zw - 0.012), (yw - 0.05, zw - 0.006)],
                    0.02, loc=(s * 0.40, 0, 0), mat="Carbon")
    finalize(mbd, "CAR_SpoilerMount", "Spoiler", (0, yw, 1.0), root)

    # ---- wheels ---------------------------------------------------------------------
    for tag, ax, R, Wt, Rr, wx in (("F", AX_F, R_F, TW_F, RIM_F, WX_F), ("R", AX_R, R_R, TW_R, RIM_R, WX_R)):
        for S, side in (("L", 1), ("R", -1)):
            build_corner(tag + S, Vector((side * wx, ax - HL, R)), R, Wt, Rr, side, root)

    build_interior(root)
    for o in bpy.data.objects:
        if o.name.startswith("CAR_") and o.type == "MESH":
            o["car_part"] = True
    add_drivers(root)
    return root


def build_corner(tag, c, R, Wt, Rr, side, root):
    rot = Matrix.Rotation(math.radians(90 * side), 4, "Y")   # local Z (outer face) -> +/-X
    hub = empty("CAR_Hub_" + tag, c, root, "Wheel_" + tag)
    tb = CarBuilder("CAR_Tire_" + tag)
    w = Wt / 2
    prof = [(Rr + 0.003, -w), (R - 0.035, -w - 0.006), (R - 0.012, -w + 0.004), (R, -w + 0.025),
            (R, -0.075), (R - 0.008, -0.07), (R - 0.008, -0.05), (R, -0.045),
            (R, 0.045), (R - 0.008, 0.05), (R - 0.008, 0.07), (R, 0.075),
            (R, w - 0.025), (R - 0.012, w - 0.004), (R - 0.035, w + 0.006), (Rr + 0.003, w)]
    tb.ring(prof, seg=64, matrix=Matrix.Translation(c) @ rot, mat="Rubber")
    rb = CarBuilder("CAR_Wheel_" + tag)
    wr = w - 0.01
    rb.ring([(Rr - 0.018, -wr), (Rr + 0.014, -wr), (Rr + 0.014, -wr + 0.012), (Rr, -wr + 0.02),
             (Rr, wr - 0.02), (Rr + 0.014, wr - 0.012), (Rr + 0.014, wr), (Rr - 0.03, wr),
             (Rr - 0.03, wr - 0.025), (Rr - 0.018, wr - 0.04)], seg=48,
            matrix=Matrix.Translation(c) @ rot, mat="RimBlack")
    M = Matrix.Translation(c) @ rot
    zo, zi = wr - 0.022, wr - 0.075
    for k in range(5):
        for d in (-1, 1):
            a = math.radians(k * 72 + d * 8)
            ca, sa = math.cos(a), math.sin(a)
            px, py = -sa, ca
            r0, r1, w0, w1 = 0.075, Rr - 0.012, 0.018, 0.012
            pts = []
            for (r, ww, z) in ((r0, w0, zi), (r1, w1, zo)):
                pts.append((r * ca - px * ww, r * sa - py * ww, z))
                pts.append((r * ca + px * ww, r * sa + py * ww, z))
            v8 = [pts[0], pts[2], pts[3], pts[1]]
            v8 = v8 + [(x, y, z + 0.028) for x, y, z in v8]
            rb.quadbox([tuple(M @ Vector(p)) for p in v8], "RimBlack")
    rb.cyl(0.085, 0.085, 0.05, matrix=M @ T((0, 0, zi)), mat="RimBlack", seg=32)
    rb.cyl(0.036, 0.036, 0.012, matrix=M @ T((0, 0, zi + 0.031)), mat="Metal", seg=24)
    for k in range(5):
        a = math.radians(36 + k * 72)
        rb.cyl(0.011, 0.011, 0.016, matrix=M @ T((0.058 * math.cos(a), 0.058 * math.sin(a), zi + 0.031)),
               mat="Chrome", seg=12)
    wheel = finalize(rb, "CAR_Wheel_" + tag, "Wheel_" + tag, c, hub)
    finalize(tb, "CAR_Tire_" + tag, "Wheel_" + tag, c, wheel)
    zd = wr - 0.17
    disc = CarBuilder("CAR_BrakeDisc_" + tag)
    rd = 0.19 if tag[0] == "F" else 0.175
    disc.ring([(0.10, zd - 0.016), (rd, zd - 0.016), (rd, zd + 0.016), (0.10, zd + 0.016)], seg=48,
              matrix=M, mat="BrakeDisc")
    disc.ring([(0.06, zd + 0.016), (0.10, zd + 0.016), (0.10, zi - 0.025), (0.06, zi - 0.025)],
              seg=32, matrix=M, mat="Metal_Dark")
    finalize(disc, "CAR_BrakeDisc_" + tag, "Brakes", c, wheel)
    cal = CarBuilder("CAR_Caliper_" + tag)
    a0, a1 = (105, 165) if side > 0 else (15, 75)
    cal.prism(arc_band_pts(rd + 0.004, rd + 0.05, a0, a1, 10), 0.09, matrix=M @ T((0, 0, zd)),
              mat="Caliper")
    finalize(cal, "CAR_Caliper_" + tag, "Brakes", c, hub)


def build_interior(root):
    ib = CarBuilder("CAR_Interior")
    ib.box((1.56, 1.43, 0.06), loc=(0, 0.235, 0.16), mat="Plastic_Black")
    ib.box((1.50, 0.05, 0.66), loc=(0, 0.985, 0.52), mat="Plastic_Black")
    ib.box((0.20, 0.75, 0.20), loc=(0, 0.28, 0.29), mat="Carbon", bevel=0.02)
    ib.box((0.88, 1.15, 0.26), loc=(0, -1.35, 0.50), mat="Plastic_Black")        # frunk liner
    ib.box((0.60, 0.55, 0.28), loc=(0, 1.40, 0.38), mat="Metal_Dark", bevel=0.02)  # engine block
    for s in (1, -1):
        ib.box((0.22, 0.55, 0.16), loc=(s * 0.17, 1.40, 0.56), rot=(0, s * 30, 0), mat="Metal_Dark",
               bevel=0.015)
    ib.box((0.36, 0.50, 0.08), loc=(0, 1.40, 0.70), mat="Carbon", bevel=0.02)
    finalize(ib, "CAR_Interior", "Interior", (0, 0.2, 0.2), root)

    dash = CarBuilder("CAR_Dashboard")
    dash.box((1.24, 0.30, 0.10), loc=(0, -0.28, 0.69), rot=(-10, 0, 0), mat="Leather", bevel=0.03, seg=2)
    dash.box((1.16, 0.20, 0.22), loc=(0, -0.30, 0.53), mat="Plastic_Black", bevel=0.02)
    dash.box((0.30, 0.12, 0.08), loc=(0.37, -0.16, 0.75), rot=(-15, 0, 0), mat="Carbon", bevel=0.02)
    dash.box((0.26, 0.02, 0.15), loc=(0, -0.15, 0.68), rot=(-20, 0, 0), mat="Plastic_Gloss", bevel=0.005)
    finalize(dash, "CAR_Dashboard", "Interior", (0, -0.28, 0.6), root)

    for S, x in (("L", 0.37), ("R", -0.37)):
        st = CarBuilder("CAR_Seat_" + S)
        st.box((0.46, 0.46, 0.10), loc=(x, 0.55, 0.25), mat="Leather", bevel=0.03, seg=2)
        st.box((0.46, 0.10, 0.62), loc=(x, 0.80, 0.56), rot=(-16, 0, 0), mat="Leather", bevel=0.04, seg=2)
        for d in (1, -1):
            st.box((0.07, 0.11, 0.52), loc=(x + d * 0.215, 0.76, 0.57), rot=(-16, 0, 0), mat="Leather",
                   bevel=0.03, seg=2)
            st.box((0.07, 0.42, 0.07), loc=(x + d * 0.215, 0.55, 0.32), mat="Leather", bevel=0.025, seg=2)
        st.box((0.20, 0.03, 0.10), loc=(x, 0.84, 0.80), rot=(-16, 0, 0), mat="Carbon", bevel=0.01)
        finalize(st, "CAR_Seat_" + S, "Interior", (x, 0.6, 0.2), root)

    piv = empty("CAR_SteeringPivot", (0.37, -0.02, 0.66), root, "Interior", rot=(20, 0, 0))
    sw = CarBuilder("CAR_SteeringWheel")
    sw.torus(0.175, 0.018, rot=(90, 0, 0), mat="Leather", seg=40, ring=10)
    sw.cyl(0.05, 0.05, 0.06, loc=(0, -0.03, 0), rot=(90, 0, 0), mat="Carbon", seg=24)
    for a in (0, 180, 270):
        sw.box((0.15, 0.02, 0.035), loc=(0.09 * math.cos(math.radians(a)), 0, 0.09 * math.sin(math.radians(a))),
               rot=(0, -a, 0), mat="Carbon", bevel=0.008)
    sw.box((0.012, 0.008, 0.03), loc=(0, -0.002, 0.18), mat="Caliper")
    PIVOTS["CAR_SteeringWheel_local"] = Vector()
    me_b = sw
    o = finalize(me_b, "CAR_SteeringWheel", "Interior", (0, 0, 0), None)
    o.parent = piv
    o.location = (0, 0, 0)


# =============================================================================
#  ANIMATION CONTROLS (Blender drivers on CAR_Root custom properties)
# =============================================================================
CONTROLS = dict(steer=(0.0, -35.0, 35.0), wheel_spin=(0.0, -36000.0, 36000.0),
                suspension=(0.0, -0.08, 0.08), door_L=(0.0, 0.0, 1.0), door_R=(0.0, 0.0, 1.0),
                hood=(0.0, 0.0, 1.0), engine_cover=(0.0, 0.0, 1.0), spoiler=(0.0, 0.0, 1.0),
                headlights=(1.0, 0.0, 1.0), brake=(0.0, 0.0, 1.0), turn_L=(0.0, 0.0, 1.0),
                turn_R=(0.0, 0.0, 1.0), reverse=(0.0, 0.0, 1.0))


def add_drivers(root):
    for k, (v, lo, hi) in CONTROLS.items():
        root[k] = v
        try:
            root.id_properties_ui(k).update(min=lo, max=hi)
        except Exception:
            pass

    def drv(owner, path, index, expr, prop):
        fc = owner.driver_add(path, index) if index is not None else owner.driver_add(path)
        d = fc.driver
        d.type = "SCRIPTED"
        var = d.variables.new()
        var.name = "v"
        var.type = "SINGLE_PROP"
        var.targets[0].id_type = "OBJECT"
        var.targets[0].id = root
        var.targets[0].data_path = '["%s"]' % prop
        d.expression = expr
    D = 0.0174533
    for tag in ("FL", "FR", "RL", "RR"):
        hub = bpy.data.objects["CAR_Hub_" + tag]
        if tag[0] == "F":
            drv(hub, "rotation_euler", 2, "v*%f" % D, "steer")
        drv(hub, "location", 2, "%.5f+v" % hub.location.z, "suspension")
        drv(bpy.data.objects["CAR_Wheel_" + tag], "rotation_euler", 0, "v*%f" % D, "wheel_spin")
    for S in ("L", "R"):
        drv(bpy.data.objects["CAR_Door_" + S], "rotation_euler", 0, "v*1.309", "door_" + S)
    drv(bpy.data.objects["CAR_Hood"], "rotation_euler", 0, "-v*0.96", "hood")
    drv(bpy.data.objects["CAR_EngineCover"], "rotation_euler", 0, "v*0.90", "engine_cover")
    sp = bpy.data.objects["CAR_Spoiler"]
    drv(sp, "location", 2, "%.5f+v*0.12" % sp.location.z, "spoiler")
    drv(sp, "rotation_euler", 0, "-v*0.26", "spoiler")
    drv(bpy.data.objects["CAR_SteeringWheel"], "rotation_euler", 1, "v*%f" % (D * 12), "steer")
    for mat, prop, scale in (("LED_Head", "headlights", 4.0), ("Light_Tail", "headlights", 1.5),
                             ("Light_Brake", "brake", 20.0), ("Light_Turn_L", "turn_L", 12.0),
                             ("Light_Turn_R", "turn_R", 12.0), ("Light_Reverse", "reverse", 8.0)):
        m = bpy.data.materials.get("MAT_" + mat)
        if not m:
            continue
        sock = m.node_tree.nodes["Principled BSDF"].inputs["Emission Strength"]
        fc = sock.driver_add("default_value")
        d = fc.driver
        d.type = "SCRIPTED"
        var = d.variables.new()
        var.name = "v"
        var.type = "SINGLE_PROP"
        var.targets[0].id_type = "OBJECT"
        var.targets[0].id = root
        var.targets[0].data_path = '["%s"]' % prop
        d.expression = "v*%.2f" % scale


# =============================================================================
#  LODs  (LOD0 = hierarchy above; LOD1-3 = merged + decimated)
# =============================================================================
WHEEL_PARTS = ("CAR_Wheel_", "CAR_Tire_", "CAR_BrakeDisc_")
INTERIOR = ("CAR_Interior", "CAR_Dashboard", "CAR_Seat_", "CAR_SteeringWheel", "CAR_DoorPanel_")


def _lod0_meshes():
    return [o for o in bpy.data.objects if o.type == "MESH" and o.get("car_part") and not o.name.startswith("CAR_LOD")]


def merge_world(objs, name, pivot, remap=None):
    b = CarBuilder(name)
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    for o in objs:
        me = bpy.data.meshes.new_from_object(o.evaluated_get(dg))
        me.transform(o.matrix_world)
        if remap:
            for i, m in enumerate(me.materials):
                k = m.name[4:] if m else ""
                if k in remap:
                    me.materials[i] = get_mat(remap[k])
        merge_mesh(b, me)
        bpy.data.meshes.remove(me)
    return b


def decimate_obj(obj, ratio):
    if ratio >= 0.999:
        return obj
    md = obj.modifiers.new("Decimate", "DECIMATE")
    md.ratio = ratio
    md.use_collapse_triangulate = True
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(obj.evaluated_get(dg))
    old = obj.data
    obj.modifiers.clear()
    obj.data = me
    bpy.data.meshes.remove(old)
    return obj


def build_lods(spec=None):
    spec = spec or {1: 0.5, 2: 0.22, 3: 0.08}
    for o in list(bpy.data.objects):
        if o.name.startswith("CAR_LOD"):
            bpy.data.objects.remove(o, do_unlink=True)
    src = _lod0_meshes()
    wheels = [o for o in src if o.name.startswith(WHEEL_PARTS)]
    calipers = [o for o in src if o.name.startswith("CAR_Caliper_")]
    interior = [o for o in src if o.name.startswith(INTERIOR)]
    body = [o for o in src if o not in wheels and o not in calipers and o not in interior]
    out = {}
    for lod, ratio in spec.items():
        cname = "Car_LOD%d" % lod
        c = bpy.data.collections.get(cname) or bpy.data.collections.new(cname)
        if c.name not in bpy.context.scene.collection.children:
            bpy.context.scene.collection.children.link(c)
        root = bpy.data.objects.new("CAR_LOD%d_Root" % lod, None)
        c.objects.link(root)
        PIVOTS[root.name] = Vector()
        remap = {"Glass": "Glass_Dark"} if lod >= 2 else None
        parts = list(body) + (interior if lod == 1 else []) + (calipers if lod >= 2 else [])
        if lod == 3:
            parts += wheels
        bb = merge_world(parts, "CAR_LOD%d_Body" % lod, (0, 0, 0), remap)
        objs = [decimate_obj(finalize(bb, "CAR_LOD%d_Body" % lod, cname, (0, 0, 0), root, uv=False), ratio)]
        if lod < 3:
            for tag in ("FL", "FR", "RL", "RR"):
                ws = [o for o in wheels if o.name.endswith("_" + tag)]
                if lod == 1:
                    cal = [o for o in calipers if o.name.endswith(tag)]
                    cb = merge_world(cal, "CAR_LOD1_Caliper_" + tag, None)
                    hub = bpy.data.objects["CAR_Hub_" + tag].matrix_world.translation.copy()
                    objs.append(finalize(cb, "CAR_LOD1_Caliper_" + tag, cname, hub, root, uv=False))
                hub = bpy.data.objects["CAR_Hub_" + tag].matrix_world.translation.copy()
                wb = merge_world(ws, "CAR_LOD%d_Wheel_%s" % (lod, tag), None, remap)
                objs.append(decimate_obj(finalize(wb, "CAR_LOD%d_Wheel_%s" % (lod, tag), cname, hub,
                                                  root, uv=False), max(ratio, 0.3)))
        out[lod] = (root, objs)
        lc = _find_lc(bpy.context.view_layer.layer_collection, cname)
        if lc:
            lc.exclude = True
    return out


def _find_lc(lc, name):
    if lc.name == name:
        return lc
    for ch in lc.children:
        r = _find_lc(ch, name)
        if r:
            return r
    return None


# =============================================================================
#  VALIDATION REPORT
# =============================================================================
def tri_count(o):
    return sum(len(p.vertices) - 2 for p in o.data.polygons)


def validate(objs):
    rep = []
    for o in objs:
        bm = bmesh.new()
        bm.from_mesh(o.data)
        nm = sum(1 for e in bm.edges if not e.is_manifold)
        loose = sum(1 for v in bm.verts if not v.link_faces)
        bm.free()
        rot_ok = all(abs(a) < 1e-6 for a in o.rotation_euler) or bool(o.animation_data)
        scl_ok = all(abs(s - 1) < 1e-6 for s in o.scale)
        rep.append(dict(name=o.name, tris=tri_count(o), non_manifold_edges=nm, loose_verts=loose,
                        materials=len(o.data.materials), uv=len(o.data.uv_layers) > 0,
                        rot_applied=rot_ok, scale_applied=scl_ok))
    return rep


# =============================================================================
#  PREVIEW RENDERS (studio scene, not part of the asset)
# =============================================================================
def render_previews(out_dir, samples=48, quick=False, only=None):
    sc = bpy.data.scenes.get("CAR_Studio") or bpy.data.scenes.new("CAR_Studio")
    for o in list(sc.collection.objects):
        sc.collection.objects.unlink(o)
    for ch in list(sc.collection.children):
        sc.collection.children.unlink(ch)
    sc.collection.children.link(bpy.data.collections["Car_Root"])
    w = bpy.data.worlds.get("CAR_Gray") or bpy.data.worlds.new("CAR_Gray")
    w.use_nodes = True
    w.node_tree.nodes["Background"].inputs[0].default_value = (0.28, 0.285, 0.29, 1)
    w.node_tree.nodes["Background"].inputs[1].default_value = 1.0
    sc.world = w
    tmp = []
    fb = CarBuilder("PREVIEW_Floor")
    fb.box((60, 60, 0.02), loc=(0, 0, -0.01), mat="Plastic_Black")
    me = bpy.data.meshes.new("PREVIEW_Floor")
    fb.bm.to_mesh(me)
    fb.bm.free()
    fm = bpy.data.materials.get("PREVIEW_FloorMat") or bpy.data.materials.new("PREVIEW_FloorMat")
    fm.use_nodes = True
    fm.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (0.23, 0.235, 0.24, 1)
    fm.node_tree.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.6
    me.materials.append(fm)
    floor = bpy.data.objects.new("PREVIEW_Floor", me)
    sc.collection.objects.link(floor)
    tmp.append(floor)
    sun = bpy.data.objects.new("PREVIEW_Sun", bpy.data.lights.new("PREVIEW_Sun", "SUN"))
    sun.data.energy, sun.data.angle = 3.0, math.radians(6)
    sun.rotation_euler = [math.radians(a) for a in (48, 0, 140)]
    top = bpy.data.objects.new("PREVIEW_Soft", bpy.data.lights.new("PREVIEW_Soft", "AREA"))
    top.data.energy, top.data.size = 2500, 8.0
    top.location = (0, 0, 6.0)
    cam = bpy.data.objects.new("PREVIEW_Cam", bpy.data.cameras.new("PREVIEW_Cam"))
    for o in (sun, top, cam):
        sc.collection.objects.link(o)
        tmp.append(o)
    sc.camera = cam
    sc.render.engine = "CYCLES"
    sc.cycles.samples = 16 if quick else samples
    sc.cycles.use_denoising = True
    sc.cycles.device = "CPU"
    sc.render.film_transparent = False
    vts = [e.identifier for e in sc.view_settings.bl_rna.properties["view_transform"].enum_items]
    sc.view_settings.view_transform = "AgX" if "AgX" in vts else "Filmic"
    sc.render.image_settings.file_format = "PNG"
    root = bpy.data.objects["CAR_Root"]
    shots = [("hero_front34", (5.6, -6.4, 1.7), (0, -0.2, 0.5), 50, {}),
             ("hero_rear34", (-5.4, 6.6, 2.0), (0, 0.3, 0.5), 50, {})]
    if not quick:
        shots += [("anim_open", (5.8, -5.6, 2.6), (0, 0.0, 0.7), 45,
                   dict(door_L=1.0, hood=1.0, engine_cover=1.0, spoiler=1.0, brake=1.0, turn_L=1.0,
                        steer=-25.0)),
                  ("ortho_front", None, "front", 0, {}), ("ortho_side", None, "side", 0, {}),
                  ("ortho_rear", None, "rear", 0, {}), ("ortho_top", None, "top", 0, {})]
    paths = []
    if only:
        shots = [sh for sh in shots if sh[0] in only]
    for name, loc, tgt, lens, ctl in shots:
        for k, v in ctl.items():
            root[k] = v
        root.update_tag()          # ID-property edits need an explicit depsgraph tag
        bpy.context.view_layer.update()
        if loc:
            cam.data.type = "PERSP"
            cam.data.lens = lens
            cam.location = loc
            cam.rotation_euler = (Vector(tgt) - Vector(loc)).to_track_quat("-Z", "Y").to_euler()
            sc.render.resolution_x, sc.render.resolution_y = (1280, 720) if quick else (1920, 1080)
        else:
            cam.data.type = "ORTHO"
            sc.render.resolution_x, sc.render.resolution_y = 1200, 600
            if tgt == "front":
                cam.rotation_euler, cam.location, cam.data.ortho_scale = (math.radians(90), 0, 0), (0, -12, 0.6), 2.5
            elif tgt == "rear":
                cam.rotation_euler, cam.location, cam.data.ortho_scale = (math.radians(90), 0, math.pi), (0, 12, 0.6), 2.5
            elif tgt == "side":
                cam.rotation_euler, cam.location, cam.data.ortho_scale = (math.radians(90), 0, math.radians(90)), (12, 0, 0.6), 5.0
            else:
                cam.rotation_euler, cam.location, cam.data.ortho_scale = (0, 0, math.radians(90)), (0, 0, 12), 5.0
        p = os.path.join(out_dir, "Previews", name + ".png")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        sc.render.filepath = p
        with bpy.context.temp_override(scene=sc):
            bpy.ops.render.render(write_still=True, scene=sc.name)
        paths.append(p)
        for k in ctl:
            root[k] = CONTROLS[k][0]
        root.update_tag()
    for o in tmp:
        bpy.data.objects.remove(o, do_unlink=True)
    sc.collection.children.unlink(bpy.data.collections["Car_Root"])
    return paths


# =============================================================================
#  EXPORT
# =============================================================================
def _select_tree(root):
    vl = bpy.context.view_layer
    for o in vl.objects:
        o.select_set(False)
    stack = [root]
    while stack:
        o = stack.pop()
        if o.name in vl.objects:
            o.select_set(True)
        stack += list(o.children)
    vl.objects.active = root


def export_all(out_dir, lods):
    import json
    paths = []
    jobs = [("CAR_Supercar_LOD0", bpy.data.objects["CAR_Root"], None)]
    for lod, (root, objs) in sorted(lods.items()):
        jobs.append(("CAR_Supercar_LOD%d" % lod, root, "Car_LOD%d" % lod))
    for fname, root, cname in jobs:
        lc = _find_lc(bpy.context.view_layer.layer_collection, cname) if cname else None
        if lc:
            lc.exclude = False
        bpy.context.view_layer.update()
        _select_tree(root)
        p = os.path.join(out_dir, fname + ".fbx")
        bpy.ops.export_scene.fbx(filepath=p, use_selection=True, object_types={"EMPTY", "MESH"},
                                 apply_unit_scale=True, apply_scale_options="FBX_SCALE_ALL",
                                 axis_forward="-Z", axis_up="Y", bake_space_transform=True,
                                 mesh_smooth_type="OFF", use_mesh_modifiers=True,
                                 use_custom_props=True, bake_anim=False, path_mode="RELATIVE")
        paths.append(p)
        if lc:
            lc.exclude = True
    return paths


def report(out_dir, lods):
    import json
    lod0 = _lod0_meshes()
    rep = {"asset": "CAR_Supercar", "length_m": L, "wheelbase_m": AX_R - AX_F,
           "lods": {"LOD0": sum(tri_count(o) for o in lod0)}, "objects": validate(lod0)}
    for lod, (root, objs) in lods.items():
        rep["lods"]["LOD%d" % lod] = sum(tri_count(o) for o in objs)
    rep["materials"] = sorted(m.name for m in bpy.data.materials if m.name.startswith("MAT_") and m.users)
    rep["controls"] = {k: dict(default=v[0], min=v[1], max=v[2]) for k, v in CONTROLS.items()}
    with open(os.path.join(out_dir, "car_report.json"), "w") as f:
        json.dump(rep, f, indent=2)
    return rep


# =============================================================================
#  UI + CLI
# =============================================================================
class CAR_OT_build(bpy.types.Operator):
    bl_idname = "supercar.build"
    bl_label = "Build Supercar"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        out = bpy.path.abspath("//Supercar_Export") if bpy.data.filepath else os.path.join(os.path.expanduser("~"), "Supercar_Export")
        make_textures(os.path.join(out, "Textures"))
        build_car()
        build_lods()
        self.report({"INFO"}, "Supercar built")
        return {"FINISHED"}


class CAR_OT_export(bpy.types.Operator):
    bl_idname = "supercar.export"
    bl_label = "Export FBX (LOD0-3)"

    def execute(self, context):
        out = bpy.path.abspath("//Supercar_Export") if bpy.data.filepath else os.path.join(os.path.expanduser("~"), "Supercar_Export")
        lods = {}
        for lod in (1, 2, 3):
            r = bpy.data.objects.get("CAR_LOD%d_Root" % lod)
            if r:
                lods[lod] = (r, [c for c in r.children])
        export_all(out, lods)
        report(out, lods)
        self.report({"INFO"}, "Exported to " + out)
        return {"FINISHED"}


class CAR_PT_panel(bpy.types.Panel):
    bl_label = "Supercar Asset"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Supercar"

    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator("supercar.build", icon="AUTO")
        col.operator("supercar.export", icon="EXPORT")
        root = bpy.data.objects.get("CAR_Root")
        if root:
            col.separator()
            col.label(text="Animation test controls")
            for k in CONTROLS:
                col.prop(root, '["%s"]' % k, text=k)


CLASSES = (CAR_OT_build, CAR_OT_export, CAR_PT_panel)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)


def _cli(argv):
    import argparse
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.getcwd(), "Supercar_Export"))
    ap.add_argument("--render", action="store_true")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--export", action="store_true")
    ap.add_argument("--samples", type=int, default=48)
    ap.add_argument("--save", default="")
    a = ap.parse_args(argv)
    out = os.path.abspath(a.out)
    for o in [o for o in bpy.data.objects if o.name in ("Cube", "Light", "Camera")]:
        bpy.data.objects.remove(o, do_unlink=True)
    make_textures(os.path.join(out, "Textures"))
    build_car()
    lods = build_lods()
    rep = report(out, lods)
    print("LOD tris:", rep["lods"])
    bad = [r for r in rep["objects"] if r["non_manifold_edges"]]
    print("objects:", len(rep["objects"]), "with non-manifold edges:", [(r["name"], r["non_manifold_edges"]) for r in bad])
    if a.export:
        print("FBX:", export_all(out, lods))
    if a.save:
        bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(a.save), relative_remap=True)
    if a.render:
        print("Renders:", render_previews(out, a.samples, a.quick))


if __name__ == "__main__":
    try:
        register()
    except ValueError:
        unregister()
        register()
    if "--" in sys.argv:
        _cli(sys.argv[sys.argv.index("--") + 1:])
