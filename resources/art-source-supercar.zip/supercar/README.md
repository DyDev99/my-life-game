# Supercar — game-ready Blender vehicle asset (v1.0)

An original mid-engine supercar (inspired by Italian/American supercars, no real badges or exact body) generated procedurally in Blender and exported for Unity / Unreal.

## Files

| File | What it is |
| --- | --- |
| `supercar_kit.py` | Blender generator + sidebar panel (rebuild, tweak, re-export) |
| `Supercar.blend` | The finished asset, organised, with LODs and test controls |
| `CAR_Supercar_LOD0.fbx` … `LOD3.fbx` | Game exports (Unity: -Z forward, Y up, transforms baked) |
| `Textures/` | Carbon fibre, grille and tyre-tread maps (1024², base colour + normal) |
| `Unity/SupercarRig.cs` | Runtime driver for wheels, steering, suspension, doors, hood, engine cover, spoiler, lights |
| `car_report.json` | Per-object triangles, materials, UVs, transform and manifold checks |
| `Previews/` | Studio renders (hero shots, open-state shot, ortho views) |

## Specs

- Length 4.60 m, width ≈ 2.0 m, height ≈ 1.15 m, wheelbase 2.68 m. 1 unit = 1 m.
- Origin of `CAR_Root` at ground level, centre of the car. Front faces −Y in Blender (+Z in Unity).
- Triangles: **LOD0 ≈ 34k · LOD1 ≈ 17k · LOD2 ≈ 8k · LOD3 ≈ 2.9k**.
- 21 PBR materials (`MAT_*`): car paint with clear coat, carbon fibre, glass, dark LOD glass, rubber, gloss-black rims, metal, dark metal, chrome, matte and gloss plastic, grille, leather, brake disc, caliper, and six light materials (LED head, tail, brake, turn L, turn R, reverse).

## Hierarchy (LOD0)

```
CAR_Root
├── CAR_Body                 (shell, wheel-well liners, side intakes, carbon roof)
├── CAR_FrontBumper / CAR_RearBumper / CAR_Splitter / CAR_Diffuser
├── CAR_Hood                 (pivot: rear edge)
├── CAR_EngineCover          (pivot: front edge)
├── CAR_Fender_F_L/R, CAR_SideSkirt_L/R
├── CAR_Door_L/R             (pivot: front hinge, scissor opening around X)
│   ├── CAR_Glass_Side_L/R
│   ├── CAR_Mirror_L/R
│   └── CAR_DoorPanel_L/R
├── CAR_Glass_Windshield, CAR_Glass_Rear
├── CAR_Headlight_L/R, CAR_Taillight_L/R
├── CAR_Spoiler (pivot at wing)  +  CAR_SpoilerMount
├── CAR_Exhaust
├── CAR_Hub_FL/FR/RL/RR      (empties: steering + suspension pivot)
│   ├── CAR_Wheel_xx         (rim, spins about X)
│   │   ├── CAR_Tire_xx
│   │   └── CAR_BrakeDisc_xx
│   └── CAR_Caliper_xx       (steers, does not spin)
├── CAR_Interior (tub, firewall, console, frunk liner, engine), CAR_Dashboard
├── CAR_Seat_L/R
└── CAR_SteeringPivot → CAR_SteeringWheel (spins about its column)
```

Blender collections mirror the requested layout (Body, Exterior › Hood/Doors/Bumpers/Spoiler/Mirrors, Glass, Lights › Headlights/Taillights, Wheels › Wheel_FL…RR, Brakes, Exhaust, Interior). Materials live in the `MAT_*` datablocks (Blender has no "Materials" collection). LOD1–3 are in `Car_LOD1/2/3` collections (excluded from the view layer by default).

## Animation

**In Blender:** select `CAR_Root`, open the **Supercar** sidebar tab and drag the controls: `steer`, `wheel_spin`, `suspension`, `door_L/R`, `hood`, `engine_cover`, `spoiler`, `headlights`, `brake`, `turn_L/R`, `reverse`. Drivers move the parts and light emission, so you can keyframe the root properties for cinematics.

**In Unity:** drivers don't export. Add `SupercarRig.cs` to the model root and set `speedKmh`, `steerAngle`, door/hood values and light booleans from your vehicle controller. Hook physics through `WheelCollider`s placed at each `CAR_Hub_xx`. If a part rotates the wrong way after import, flip the sign of that axis in the inspector.

**LODs:** add a `LODGroup` to an empty parent and assign LOD0–LOD3 prefabs. LOD1–2 keep separate wheel objects (pivot at wheel centre) so wheels still spin and steer; LOD3 is a single mesh for distant traffic. LOD2–3 use opaque dark glass and drop the interior.

## Unity import

1. Copy the FBX files and `Textures/` into the same folder.
2. On each FBX: Model › Scale Factor 1, "Bake Axis Conversion" on; Materials › Extract Materials.
3. **Glass:** set the extracted `MAT_Glass` to Transparent (URP Lit: Surface Type = Transparent, alpha ≈ 0.6).
4. **Car paint:** URP Lit has no clear-coat layer. Use smoothness ≈ 0.8, or HDRP Lit with Coat Mask = 1.
5. **URP:** convert materials (Edit › Rendering › Materials › Convert…) if they appear pink.

## Quality notes (honest)

- **Validation:** 48 of 49 LOD0 meshes are closed manifold solids. `CAR_Body` has 2 non-manifold edges where the wheel-arch boolean meets a panel seam; they don't affect rendering.
- **What it is:** a mid-detail, game-ready vehicle: about 34k triangles, a separated hierarchy, real pivots and working controls.
- **What it isn't:**
  - The body is a lofted surface. It has no hand-modelled surface detail such as panel-gap insets, badges or vents with depth (the intakes are surface overlays).
  - It has no baked normal/AO maps. AAA hero cars are typically 150–400k triangles with a hand-modelled body and baked maps.
  - It uses per-part materials, not a single texture atlas. UV0 (Smart UV) is ready for a 2K/4K paint or bake pass.
- **Upgrade path to AAA:** use this model as the blockout. Remodel or subdivide the body panels by hand, bake high→low normals and AO onto UV0, and add decals (badges, livery).
