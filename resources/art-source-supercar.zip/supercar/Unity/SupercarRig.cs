// Drives the exported supercar hierarchy (CAR_Supercar_LOD0.fbx):
// wheel spin, steering, suspension, scissor doors, hood, engine cover,
// active spoiler and all lights (head, tail, brake, turn signals, reverse).
// Add to the root of the imported model. Transforms are found by name.
// Rotations are applied relative to the imported pose; if a part turns the
// wrong way in your project, flip its axis sign below.
using UnityEngine;

public class SupercarRig : MonoBehaviour
{
    [Header("Driving input")]
    public float speedKmh = 0f;
    [Range(-35f, 35f)] public float steerAngle = 0f;
    [Range(-0.08f, 0.08f)] public float suspension = 0f;

    [Header("Openings (0 = closed, 1 = open)")]
    [Range(0, 1)] public float doorLeft, doorRight, hood, engineCover, spoiler;

    [Header("Lights")]
    public bool headlights = true, brake, reverse, turnLeft, turnRight, hazards;
    public float blinkHz = 1.5f;

    [Header("Axes (Unity local space)")]
    public Vector3 spinAxis = Vector3.right;
    public Vector3 steerAxis = Vector3.up;
    public Vector3 hingeAxis = Vector3.right;
    public float wheelRadius = 0.345f;

    Transform[] hubs = new Transform[4], wheels = new Transform[4];
    Transform doorL, doorR, hoodT, coverT, spoilerT, steeringWheel;
    Quaternion[] hubRot = new Quaternion[4], wheelRot = new Quaternion[4];
    Vector3[] hubPos = new Vector3[4];
    Quaternion doorLRot, doorRRot, hoodRot, coverRot, spoilerRot, steerWheelRot;
    Vector3 spoilerPos;
    float spin;
    readonly MaterialPropertyBlock mpb = new MaterialPropertyBlock();
    Renderer[] renderers;

    static readonly string[] Tags = { "FL", "FR", "RL", "RR" };

    void Awake()
    {
        for (int i = 0; i < 4; i++)
        {
            hubs[i] = Find("CAR_Hub_" + Tags[i]);
            wheels[i] = Find("CAR_Wheel_" + Tags[i]);
            if (hubs[i]) { hubRot[i] = hubs[i].localRotation; hubPos[i] = hubs[i].localPosition; }
            if (wheels[i]) wheelRot[i] = wheels[i].localRotation;
        }
        doorL = Find("CAR_Door_L"); doorR = Find("CAR_Door_R");
        hoodT = Find("CAR_Hood"); coverT = Find("CAR_EngineCover");
        spoilerT = Find("CAR_Spoiler"); steeringWheel = Find("CAR_SteeringWheel");
        if (doorL) doorLRot = doorL.localRotation;
        if (doorR) doorRRot = doorR.localRotation;
        if (hoodT) hoodRot = hoodT.localRotation;
        if (coverT) coverRot = coverT.localRotation;
        if (spoilerT) { spoilerRot = spoilerT.localRotation; spoilerPos = spoilerT.localPosition; }
        if (steeringWheel) steerWheelRot = steeringWheel.localRotation;
        renderers = GetComponentsInChildren<Renderer>();
    }

    Transform Find(string n)
    {
        foreach (var t in GetComponentsInChildren<Transform>(true))
            if (t.name == n) return t;
        return null;
    }

    void Update()
    {
        spin += (speedKmh / 3.6f) / Mathf.Max(wheelRadius, 0.01f) * Mathf.Rad2Deg * Time.deltaTime;
        spin %= 360f;
        for (int i = 0; i < 4; i++)
        {
            if (hubs[i])
            {
                float steer = i < 2 ? steerAngle : 0f;
                hubs[i].localRotation = hubRot[i] * Quaternion.AngleAxis(steer, steerAxis);
                hubs[i].localPosition = hubPos[i] + Vector3.up * suspension;
            }
            if (wheels[i]) wheels[i].localRotation = wheelRot[i] * Quaternion.AngleAxis(spin, spinAxis);
        }
        if (steeringWheel) steeringWheel.localRotation = steerWheelRot * Quaternion.AngleAxis(steerAngle * 12f, Vector3.forward);
        if (doorL) doorL.localRotation = doorLRot * Quaternion.AngleAxis(-75f * doorLeft, hingeAxis);
        if (doorR) doorR.localRotation = doorRRot * Quaternion.AngleAxis(-75f * doorRight, hingeAxis);
        if (hoodT) hoodT.localRotation = hoodRot * Quaternion.AngleAxis(55f * hood, hingeAxis);
        if (coverT) coverT.localRotation = coverRot * Quaternion.AngleAxis(-52f * engineCover, hingeAxis);
        if (spoilerT)
        {
            spoilerT.localRotation = spoilerRot * Quaternion.AngleAxis(15f * spoiler, hingeAxis);
            spoilerT.localPosition = spoilerPos + Vector3.up * 0.12f * spoiler;
        }
        UpdateLights();
    }

    void UpdateLights()
    {
        bool blinkOn = Mathf.Repeat(Time.time * blinkHz, 1f) < 0.5f;
        bool tl = (turnLeft || hazards) && blinkOn, tr = (turnRight || hazards) && blinkOn;
        foreach (var r in renderers)
        {
            var mats = r.sharedMaterials;
            for (int m = 0; m < mats.Length; m++)
            {
                if (mats[m] == null) continue;
                string n = mats[m].name;
                float e = -1f; Color c = Color.white;
                if (n.Contains("LED_Head")) { e = headlights ? 4f : 0f; c = new Color(0.95f, 0.97f, 1f); }
                else if (n.Contains("Light_Tail")) { e = headlights ? 1.5f : 0f; c = Color.red; }
                else if (n.Contains("Light_Brake")) { e = brake ? 6f : 0f; c = Color.red; }
                else if (n.Contains("Light_Turn_L")) { e = tl ? 6f : 0f; c = new Color(1f, 0.55f, 0f); }
                else if (n.Contains("Light_Turn_R")) { e = tr ? 6f : 0f; c = new Color(1f, 0.55f, 0f); }
                else if (n.Contains("Light_Reverse")) { e = reverse ? 4f : 0f; c = Color.white; }
                if (e < 0f) continue;
                if (!mats[m].IsKeywordEnabled("_EMISSION")) mats[m].EnableKeyword("_EMISSION");
                r.GetPropertyBlock(mpb, m);
                mpb.SetColor("_EmissionColor", c * e);
                r.SetPropertyBlock(mpb, m);
            }
        }
    }
}
