# Khmer Boxer — Blender Game Asset

Built in Blender 5.0.1 entirely through Python scripts (included), from the supplied concept sheet.
Units: 1 BU = 1 m. Character height 1.72 m (1.74 m to top of hair). Rest pose: T-pose, facing −Y (Unity +Z).

## Folder layout

| Path | Contents |
|---|---|
| `Boxer_Character.blend` | Main project (3.8 MB). Collections: `Boxer_Character/` → `Character`, `Rig`, `Animation`, `LOD` (LOD0/1/2), `Export`, `Preview` |
| `Export/` | `Boxer_Character_Unity.fbx` (LOD0 + 11 animations), `Boxer_LOD0.fbx`, `Boxer_LOD1.fbx`, `Boxer_LOD2.fbx` (embedded textures) |
| `Textures/` | Per material: `BaseColor`, `Normal` (OpenGL, tangent space), `Roughness`, `AO`, `MetallicSmoothness` (Unity: R = metallic, A = smoothness). `Mobile_1024/` = half-res set (2048 → 1024) |
| `Preview/` | Cycles renders: turnaround, poses (T / neutral / guard / punch), headshot, LOD comparison |
| `Source/Boxer_HighPoly_BakeSource.blend` | High-poly sculpts + procedural source shaders used for baking (only needed to re-bake) |
| `scripts/` | The full pipeline (see "Rebuilding") |

## Assets in the main file

**Meshes** (`Character`): `Boxer_Body`, `Boxer_Head` (incl. eyes), `Boxer_Hair`, `Boxer_Headband` (knot + ribbon tails), `Boxer_Gloves_L/R`, `Boxer_Shorts`, `Boxer_Boot_L/R` (incl. metal eyelets). Body and head share a crack-free neck seam.

**Materials** (Principled BSDF, image textures linked directly so FBX carries them): `MAT_Skin` (body + head share one 2048 atlas; the face gets ~3× texel density), `MAT_Eyes`, `MAT_Hair`, `MAT_Headband`, `MAT_BoxingGloves`, `MAT_Shorts` (2048, "KHMER" waistband label, Angkor Wat emblems, white side stripes), `MAT_Boots`, `MAT_MetalDetails`.

**Rig** (`Boxer_Armature`, 55 bones): `root, pelvis, spine_01, spine_02, chest, neck, head, eye_L/R, clavicle_L/R, upper_arm, lower_arm, hand, thumb/index/middle/ring/pinky_01–03, thigh, calf, foot, toe` (L/R). Max 4 influences per vertex.

## Triangle budgets

| Level | Triangles | Brief target | Notes |
|---|---|---|---|
| LOD0 | 44,279 | 25–45k | Skin hidden under shorts/boots removed; hands kept for the finger rig |
| LOD1 | 18,854 | 12–20k | Also removes hands (inside gloves) and eyelets; head decimated least |
| LOD2 | 8,908 | 5–10k | Same, stronger decimation |

The skin under the shorts and boots is removed in all LODs, so the exported character can't be shown without this outfit. The un-cut `Boxer_Body` in the `Character` collection is the master if you ever need it.

## Animations (30 fps, in place, no root motion)

| Clip | Frames | Loop |
|---|---|---|
| Boxer_Idle | 1–61 | ✓ |
| Boxer_Walk | 1–33 | ✓ |
| Boxer_Run | 1–21 | ✓ |
| Boxer_Jab | 1–20 | |
| Boxer_Cross | 1–24 | |
| Boxer_Hook | 1–26 | |
| Boxer_Guard | 1–40 | ✓ |
| Boxer_Dodge | 1–24 | |
| Boxer_Crouch | 1–40 | ✓ (crouched guard idle) |
| Boxer_Victory | 1–60 | |
| Boxer_Defeat | 1–60 | (ends kneeling/slumped) |

## Unity import (I couldn't run Unity here; these are the recommended settings)

1. Drop `Export/` and `Textures/` into the project.
2. **Model tab:** Scale Factor 1, Convert Units on.
3. **Rig tab:** Animation Type **Humanoid**, Avatar "Create From This Model". The rest pose is a T-pose, so auto-mapping should succeed. Expected mapping:

   | Unity Humanoid slot | Bone |
   |---|---|
   | Hips | `pelvis` |
   | Spine | `spine_01` |
   | Chest | `spine_02` |
   | UpperChest | `chest` |
   | Shoulder | `clavicle_*` |
   | UpperLeg / LowerLeg | `thigh` / `calf` |
   | Toes | `toe` |
   | Eyes | `eye_*` |

   Verify the mapping in the Avatar configurator.
4. **Animation tab:** tick **Loop Time** on Idle, Walk, Run, Guard, Crouch.
5. **Materials:** extract materials. Then, for URP Lit:
   - Base Map = BaseColor.
   - Normal Map = `_Normal` (set texture type "Normal map").
   - Metallic Map = `_MetallicSmoothness` with Smoothness Source = Metallic Alpha.
   - Occlusion = `_AO`.
   - On `MAT_MetalDetails`, set Metallic to 1.
6. **LODs:** add a **LOD Group** with `Boxer_LOD0/1/2` (all use the same skeleton). Alternatively, use `Boxer_Character_Unity.fbx` as LOD0 and the others as LOD1/2.

## Quality-control checklist

| Item | Status |
|---|---|
| Resembles the concept | ✓ silhouette, colors, outfit, Khmer details. Face is a clean stylized approximation — see limitations |
| Correct proportions | ✓ 1.72 m, ~7.5 heads, lean athletic build |
| Clean topology | ✓ QuadriFlow quad meshes; triangles only at seams/zippers; n-gons triangulated for export |
| Clean UVs | ✓ no overlaps within a material; L/R gloves and boots intentionally share (mirrored) UVs |
| Materials assigned / no missing textures | ✓ verified by script |
| Normals | ✓ outward-oriented (verified by ray test); baked normal maps verified |
| Rig / weights / boxing poses | ✓ tested: guard, jab, cross, hook, crouch, arms raised, kneel. ⚠ Extreme kicks not tested (no kick clip requested) |
| LOD0/1/2 + Unity FBX | ✓ re-imported into an empty scene: hierarchy, 55 bones, skinning, scale, materials, 11 takes |
| Naming / collections / transforms / origin | ✓ no auto-named objects, all transforms applied, origin at the feet |

## Known limitations (honest)

- **Face.** The face is procedurally sculpted, not hand-sculpted. It reads as a young Khmer boxer at gameplay distance (strong brows, focused eyes, red headband), but it is softer and rounder than the painted concept.
  - Best upgrade: a 1–2 hour hand-sculpt pass on the face, then re-bake with `scripts/s4b_bake.py`.
  - No facial blend shapes yet (dialogue lip-sync would need them).
- **Hair.** The hair is chunky sculpted clumps rather than cards. It is game-friendly at 4.6k tris, but has no strand transparency.
- **Animations.** These are key-pose prototypes (3–7 keys each) meant for blocking and gameplay testing, not final mocap-quality motion. There is no jump clip; the rig supports jumping.
- **Texture edit outside the bake.** The hair textures were polished after baking (softer normals, matte roughness) by `scripts/texfix_hair.py`, so re-baking the hair should be followed by that script.

## Rebuilding (scripts run in order)

`anatomy.py` → `s1_retopo.py` → `gear.py` → `s3_gear.py` → `art.py` → `s4a_uv.py` → `s4b_bake.py` (needs the high-poly from `Source/` appended back into a `_HighPoly` collection) → `texfix_hair.py` → `s5_rig.py` → `s6_anim.py` → `s7_lod_export.py` → `s9_preview.py`.

Support modules: `sdf.py` (signed-distance sculpting), `bx.py`, `retopo.py`, `fixes.py`, `anim.py` (pose library). Requires Blender 5.x (or `bpy` 5.0 under Python 3.11) plus numpy, scikit-image, scipy and Pillow.
