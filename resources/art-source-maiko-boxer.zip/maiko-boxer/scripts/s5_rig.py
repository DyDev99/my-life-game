"""Stage 5: humanoid armature (Unity-humanoid compatible names) + skin weights."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
from mathutils import Vector, kdtree
import bx, anatomy as A

bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
O = bpy.data.objects; sc = bpy.context.scene
RIG = bx.coll('Rig')
if 'Boxer_Armature' in O:
    bpy.data.objects.remove(O['Boxer_Armature'])
for o in bpy.data.collections['Character'].objects:
    o.modifiers.clear(); o.vertex_groups.clear(); o.parent = None

J = {k: Vector(v) for k, v in A.J.items()}
M = lambda v: Vector((-v.x, v.y, v.z))

arm_data = bpy.data.armatures.new('Boxer_Armature')
arm = bpy.data.objects.new('Boxer_Armature', arm_data); RIG.objects.link(arm)
arm_data.display_type = 'OCTAHEDRAL'; arm.show_in_front = True
bx.set_active(arm)
bpy.ops.object.mode_set(mode='EDIT')
EB = arm_data.edit_bones


def bone(name, h, t, parent=None, roll_to=(0, -1, 0), connect=False):
    b = EB.new(name); b.head = h; b.tail = t
    if parent:
        b.parent = EB[parent]; b.use_connect = connect
    b.align_roll(Vector(roll_to))
    return b


bone('root', (0, 0, 0), (0, 0, 0.12))
bone('pelvis', J['pelvis'], J['spine_01'], 'root')
bone('spine_01', J['spine_01'], J['spine_02'], 'pelvis', connect=True)
bone('spine_02', J['spine_02'], J['chest'], 'spine_01', connect=True)
bone('chest', J['chest'], J['neck'], 'spine_02', connect=True)
bone('neck', J['neck'], J['head'], 'chest', connect=True)
bone('head', J['head'], J['head_end'], 'neck', connect=True)
for side, f in (('L', lambda v: v), ('R', M)):
    s = '_' + side
    eye = f(J['eye']); bone('eye' + s, eye, eye + Vector((0, -0.03, 0)), 'head', roll_to=(0, 0, 1))
    bone('clavicle' + s, f(J['clavicle']), f(J['shoulder']), 'chest', roll_to=(0, 0, 1))
    bone('upper_arm' + s, f(J['shoulder']), f(J['elbow']), 'clavicle' + s, connect=True, roll_to=(0, 0, 1))
    bone('lower_arm' + s, f(J['elbow']), f(J['wrist']), 'upper_arm' + s, connect=True, roll_to=(0, 0, 1))
    bone('hand' + s, f(J['wrist']), f(J['knuckle']), 'lower_arm' + s, connect=True, roll_to=(0, 0, 1))
    th = [f(Vector(p)) for p in A.THUMB]
    for i in range(3):
        bone(f'thumb_0{i + 1}{s}', th[i], th[i + 1], 'hand' + s if i == 0 else f'thumb_0{i}{s}', connect=i > 0, roll_to=(0, 0, 1))
    for fn in ('index', 'middle', 'ring', 'pinky'):
        pts, _ = A.finger_points(fn); pts = [f(Vector(p)) for p in pts]
        for i in range(3):
            bone(f'{fn}_0{i + 1}{s}', pts[i], pts[i + 1], 'hand' + s if i == 0 else f'{fn}_0{i}{s}', connect=i > 0, roll_to=(0, 0, 1))
    bone('thigh' + s, f(J['hip']), f(J['knee']), 'pelvis')
    bone('calf' + s, f(J['knee']), f(J['ankle']), 'thigh' + s, connect=True)
    bone('foot' + s, f(J['ankle']), f(J['ball']), 'calf' + s, connect=True, roll_to=(0, 0, 1))
    bone('toe' + s, f(J['ball']), f(J['toe_end']), 'foot' + s, connect=True, roll_to=(0, 0, 1))
NON_DEFORM = {'root'}
for b in EB:
    b.use_deform = b.name not in NON_DEFORM
bpy.ops.object.mode_set(mode='OBJECT')
print('bones', len(arm_data.bones))

# ------------------------------------------------------------------ skin: body & head (heat), then fix-ups
body, head = O['Boxer_Body'], O['Boxer_Head']


def auto_weights(ob):
    for o in bpy.context.view_layer.objects: o.select_set(False)
    ob.select_set(True); arm.select_set(True); bpy.context.view_layer.objects.active = arm
    with bpy.context.temp_override(active_object=arm, object=arm, selected_objects=[ob, arm],
                                   selected_editable_objects=[ob, arm]):
        bpy.ops.object.parent_set(type='ARMATURE_AUTO')
    print(ob.name, 'groups', len(ob.vertex_groups))

auto_weights(body)
auto_weights(head)


def weights_of(ob):
    W = [dict() for _ in ob.data.vertices]; names = {g.index: g.name for g in ob.vertex_groups}
    for v in ob.data.vertices:
        for g in v.groups:
            if g.weight > 1e-4: W[v.index][names[g.group]] = g.weight
    return W


def set_weights(ob, W):
    ob.vertex_groups.clear(); groups = {}
    for i, w in enumerate(W):
        tot = sum(w.values()) or 1.0
        for n, x in w.items():
            if n not in groups: groups[n] = ob.vertex_groups.new(name=n)
            groups[n].add([i], x / tot, 'REPLACE')


def limit(w, n=4):
    top = dict(sorted(w.items(), key=lambda kv: -kv[1])[:n]); s = sum(top.values()) or 1
    return {k: v / s for k, v in top.items() if v / s > 0.01}


BW = weights_of(body)
kd = kdtree.KDTree(len(body.data.vertices))
for v in body.data.vertices: kd.insert(v.co, v.index)
kd.balance()

# head: border verts copy body weights exactly; eyes -> eye bones; rest keeps heat weights limited to head/neck chain
HW = weights_of(head); eye = [bool(a.value) for a in head.data.attributes['is_eye'].data]
eye_v = {vi for p in head.data.polygons if eye[p.index] for vi in p.vertices}
for v in head.data.vertices:
    if v.index in eye_v:
        HW[v.index] = {('eye_L' if v.co.x > 0 else 'eye_R'): 1.0}; continue
    co, idx, d = kd.find(v.co)
    if d < 1e-5:
        HW[v.index] = dict(BW[idx]); continue
    # neck part of the head mesh: fade from the seam's body weights to 100% head by jaw height
    t = min(1.0, max(0.0, (v.co.z - 1.493) / 0.07)); t = t * t * (3 - 2 * t)
    w = {k: x * (1 - t) for k, x in BW[idx].items()}
    w['head'] = w.get('head', 0) + t
    HW[v.index] = w
set_weights(head, [limit(w) for w in HW])
set_weights(body, [limit(w) for w in BW])


# ------------------------------------------------------------------ clothing
def transfer(ob, smooth=0, rigid_fn=None):
    """Nearest-surface weights from the body (barycentric), optional per-vertex override."""
    from mathutils.bvhtree import BVHTree
    dg = bpy.context.evaluated_depsgraph_get(); bvh = BVHTree.FromObject(body, dg)
    W = []
    for v in ob.data.vertices:
        if rigid_fn and (r := rigid_fn(v.co)) is not None:
            W.append(r); continue
        loc, n, fi, d = bvh.find_nearest(v.co)
        poly = body.data.polygons[fi]; vs = [body.data.vertices[i].co for i in poly.vertices]
        ws = [1 / ((loc - c).length + 1e-5) for c in vs]; acc = {}
        for vi, wv in zip(poly.vertices, ws):
            for k, x in BW[vi].items(): acc[k] = acc.get(k, 0) + x * wv
        W.append(limit(acc))
    set_weights(ob, W)
    for _ in range(smooth):
        with bpy.context.temp_override(object=ob, active_object=ob):
            for g in ob.vertex_groups:
                pass
    return W

transfer(O['Boxer_Shorts'])
transfer(O['Boxer_Boot_L']); transfer(O['Boxer_Boot_R'])


def glove_fn(side):
    def f(co):
        x = abs(co.x); t = min(1, max(0, (x - 0.685) / 0.06))
        return {f'hand_{side}': t, f'lower_arm_{side}': 1 - t} if t < 1 else {f'hand_{side}': 1.0}
    return f
transfer(O['Boxer_Gloves_L'], rigid_fn=glove_fn('L')); transfer(O['Boxer_Gloves_R'], rigid_fn=glove_fn('R'))
for n in ('Boxer_Hair', 'Boxer_Headband'):
    set_weights(O[n], [{'head': 1.0}] * len(O[n].data.vertices))

for o in bpy.data.collections['Character'].objects:
    for m in [m for m in o.modifiers if m.type == 'ARMATURE']:
        o.modifiers.remove(m)
    m = o.modifiers.new('Armature', 'ARMATURE'); m.object = arm; m.use_deform_preserve_volume = False
    o.parent = arm; o.matrix_parent_inverse = arm.matrix_world.inverted()
    used = {g.name for g in o.vertex_groups}
    print(f'{o.name:16s} groups {len(used):3d}  max influences {max((len(v.groups) for v in o.data.vertices), default=0)}')
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)
