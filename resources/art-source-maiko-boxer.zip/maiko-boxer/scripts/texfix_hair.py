"""Hair texture polish: soften strand-groove normals (specular zebra), less gloss, warmer dark brown."""
import numpy as np, os, sys
from PIL import Image, ImageFilter
T = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'Textures')
def rw(name, fn):
    p = os.path.join(T, name); im = np.asarray(Image.open(p).convert('RGB')).astype(np.float32) / 255
    out = np.clip(fn(im), 0, 1); Image.fromarray((out * 255 + .5).astype(np.uint8)).save(p); return out
def soften_normal(n):
    v = n * 2 - 1; flat = np.array([0, 0, 1.0])
    used = n.sum(-1) > 0.05
    v = np.where(used[..., None], v * 0.35 + flat * 0.65, v)
    v /= np.linalg.norm(v, axis=-1, keepdims=True) + 1e-6
    return np.where(used[..., None], v * 0.5 + 0.5, n)
rw('T_Boxer_Hair_Normal.png', soften_normal)
r = rw('T_Boxer_Hair_Roughness.png', lambda x: 0.66 + 0.22 * x)
rw('T_Boxer_Hair_BaseColor.png', lambda c: c * np.array([1.12, 1.0, 0.92]))
ms = np.zeros(r.shape[:2] + (4,), np.uint8); ms[..., 3] = ((1 - r[..., 0]) * 255).astype(np.uint8)
Image.fromarray(ms, 'RGBA').save(os.path.join(T, 'T_Boxer_Hair_MetallicSmoothness.png'))
for n in ('Normal', 'Roughness', 'BaseColor', 'MetallicSmoothness'):
    im = Image.open(os.path.join(T, f'T_Boxer_Hair_{n}.png')); im.resize((512, 512), Image.LANCZOS).save(os.path.join(T, 'Mobile_1024', f'T_Boxer_Hair_{n}.png'))
print('hair textures polished')
