"""Shared Blender helpers for the Khmer Boxer pipeline."""
import bpy, bmesh, math, os
import numpy as np
from mathutils import Vector, Matrix

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(ROOT, 'work')
BLEND = os.path.join(ROOT, 'Boxer_Character.blend')


def coll(name, parent=None):
    c = bpy.data.collections.get(name)
    if c is None:
        c = bpy.data.collections.new(name)
        (parent or bpy.context.scene.collection).children.link(c)
    return c


def link(obj, c):
    for uc in list(obj.users_collection):
        uc.objects.unlink(obj)
    c.objects.link(obj)
    return obj


def mesh_from_np(name, v, f, c=None):
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(v)); me.vertices.foreach_set('co', np.asarray(v, np.float32).ravel())
    nf = len(f); f = np.asarray(f, np.int32)
    me.loops.add(nf * f.shape[1]); me.loops.foreach_set('vertex_index', f.ravel())
    me.polygons.add(nf)
    me.polygons.foreach_set('loop_start', np.arange(0, nf * f.shape[1], f.shape[1], dtype=np.int32))
    me.update(); me.validate()
    ob = bpy.data.objects.new(name, me)
    (c or bpy.context.scene.collection).objects.link(ob)
    return ob


def load_npz(name, path, c=None):
    d = np.load(path)
    return mesh_from_np(name, d['v'], d['f'], c)


def set_active(ob, select_only=True):
    if select_only:
        for o in bpy.context.view_layer.objects:
            o.select_set(False)
    ob.select_set(True); bpy.context.view_layer.objects.active = ob


def shade_smooth(ob):
    ob.data.polygons.foreach_set('use_smooth', [True] * len(ob.data.polygons))
    ob.data.update()


def tri_count(ob):
    return sum(len(p.vertices) - 2 for p in ob.data.polygons)


def quadriflow(ob, faces, seed=0):
    # QuadriFlow's pre-check rejects 'zero length' edges with an absolute threshold, so work at 10x scale
    set_active(ob)
    ob.data.transform(Matrix.Scale(10, 4))
    with bpy.context.temp_override(object=ob, active_object=ob, selected_objects=[ob]):
        r = bpy.ops.object.quadriflow_remesh(target_faces=faces, use_mesh_symmetry=False,
                                              use_preserve_sharp=False, use_preserve_boundary=False,
                                              smooth_normals=False, seed=seed)
    ob.data.transform(Matrix.Scale(0.1, 4))
    return r


def apply_modifiers(ob):
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg), preserve_all_data_layers=True, depsgraph=dg)
    old = ob.data; ob.modifiers.clear(); ob.data = me; me.name = old.name
    if old.users == 0:
        bpy.data.meshes.remove(old)


# ------------------------------------------------------------ inspection renders (Workbench)
def inspect_render(path, objs=None, views=('front', 'side', 'back', 'q34'), res=420, target=(0, 0, 0.88),
                   dist=3.4, ortho=1.9, lens_ortho=True, color='MATERIAL', cavity=True):
    sc = bpy.context.scene
    sc.render.engine = 'BLENDER_WORKBENCH'
    sh = sc.display.shading
    sh.light = 'STUDIO'; sh.color_type = color; sh.show_cavity = cavity
    sh.cavity_type = 'BOTH'; sh.show_shadows = False; sh.show_specular_highlight = True
    sc.render.resolution_x = res; sc.render.resolution_y = int(res * 1.25)
    sc.render.film_transparent = False
    sc.display.shading.background_type = 'VIEWPORT' if False else sh.background_type
    hidden = []
    if objs is not None:
        names = {o.name for o in objs}
        for o in sc.objects:
            if o.type in ('MESH', 'CURVE') and o.name not in names and not o.hide_render:
                o.hide_render = True; hidden.append(o)
    cam = bpy.data.objects.get('_InspectCam') or bpy.data.objects.new('_InspectCam', bpy.data.cameras.new('_InspectCam'))
    if cam.name not in sc.collection.objects:
        sc.collection.objects.link(cam)
    cam.data.type = 'ORTHO' if lens_ortho else 'PERSP'; cam.data.ortho_scale = ortho
    sc.camera = cam
    dirs = {'front': (0, -1, 0), 'back': (0, 1, 0), 'side': (1, 0, 0), 'left': (-1, 0, 0),
            'q34': (0.7, -0.7, 0.12), 'q34b': (-0.7, 0.7, 0.12), 'top': (0, -0.01, 1)}
    t = Vector(target); outs = []
    for v in views:
        d = Vector(dirs[v]).normalized()
        cam.location = t + d * dist
        cam.rotation_euler = (t - cam.location).to_track_quat('-Z', 'Y').to_euler()
        p = path.replace('.png', f'_{v}.png'); sc.render.filepath = p
        bpy.ops.render.render(write_still=True); outs.append(p)
    for o in hidden:
        o.hide_render = False
    bpy.data.objects.remove(cam)
    return outs


def montage(paths, out, cols=None):
    from PIL import Image
    ims = [Image.open(p) for p in paths]; cols = cols or len(ims)
    w, h = ims[0].size; rows = (len(ims) + cols - 1) // cols
    M = Image.new('RGB', (w * cols, h * rows), (40, 40, 40))
    for i, im in enumerate(ims):
        M.paste(im.convert('RGB'), ((i % cols) * w, (i // cols) * h))
    M.save(out)
    for p in paths:
        os.remove(p)
    return out
