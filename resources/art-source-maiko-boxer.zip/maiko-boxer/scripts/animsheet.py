import sys, os; sys.path.insert(0, os.path.dirname(__file__))
import bpy, bx
from PIL import Image, ImageDraw
bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
sc = bpy.context.scene; arm = bpy.data.objects['Boxer_Armature']; CH = list(bpy.data.collections['Character'].objects)
for o in CH:
    o.color = (0.75, 0.55, 0.42, 1) if ('Body' in o.name or 'Head' in o.name) else ((0.1, 0.08, 0.06, 1) if 'Hair' in o.name else (0.8, 0.1, 0.1, 1))
names = os.environ.get('CLIPS', '').split(',') if os.environ.get('CLIPS') else [a.name for a in bpy.data.actions if a.name.startswith('Boxer_')]
rows = []
for n in names:
    act = bpy.data.actions[n]; arm.animation_data.action = act
    s, e = int(act.frame_start), int(act.frame_end); frames = [s + round((e - s) * t) for t in (0, 0.3, 0.55, 0.8)]
    ims = []
    for f in frames:
        sc.frame_set(f)
        p = bx.inspect_render(f'{bx.WORK}/as_{n}_{f}.png', objs=CH, views=(os.environ.get('VIEW', 'q34'),), res=170, color='OBJECT', ortho=2.0)[0]
        ims.append(Image.open(p)); os.remove(p)
    row = Image.new('RGB', (170 * 4 + 120, ims[0].height), (35, 35, 35)); d = ImageDraw.Draw(row)
    d.text((5, 10), n.replace('Boxer_', ''), fill=(255, 255, 255))
    for i, im in enumerate(ims): row.paste(im, (120 + i * 170, 0))
    rows.append(row)
cols = 2; W = rows[0].width; H = rows[0].height; R = (len(rows) + 1) // cols
sheet = Image.new('RGB', (W * cols, H * R), (20, 20, 20))
for i, r in enumerate(rows): sheet.paste(r, ((i % cols) * W, (i // cols) * H))
sheet.save(f'{bx.WORK}/animsheet.png')
