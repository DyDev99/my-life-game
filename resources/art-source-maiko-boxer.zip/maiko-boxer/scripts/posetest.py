import sys, os; sys.path.insert(0, os.path.dirname(__file__))
import bpy, bx, anim
bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
arm = bpy.data.objects['Boxer_Armature']; CH = list(bpy.data.collections['Character'].objects)
cols = {'Body': (0.75, 0.55, 0.42, 1), 'Head': (0.75, 0.55, 0.42, 1), 'Hair': (0.1, 0.08, 0.06, 1)}
for o in CH:
    o.color = next((c for k, c in cols.items() if k in o.name), (0.8, 0.1, 0.1, 1))
poses = [(n, getattr(anim, n)) for n in os.environ.get('POSES', 'GUARD,JAB,CROUCH,RAISE').split(',')]
view = os.environ.get('VIEW', 'q34')
outs = []
for name, P in poses:
    anim.apply(arm, P); bpy.context.view_layer.update()
    p = bx.inspect_render(f'{bx.WORK}/pt_{name}.png', objs=CH, views=(view,), res=340, color='OBJECT', ortho=2.0)
    outs += p
bx.montage(outs, f'{bx.WORK}/posetest.png')
