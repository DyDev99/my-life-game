import sys, os; sys.path.insert(0, os.path.dirname(__file__))
import bpy, bx
bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
hp = bpy.data.collections['_HighPoly']
src = os.path.join(bx.ROOT, 'Source', 'Boxer_HighPoly_BakeSource.blend')
blocks = {hp} | set(hp.objects) | {o.data for o in hp.objects} | {m for o in hp.objects for m in o.data.materials if m}
bpy.data.libraries.write(src, blocks, compress=True, fake_user=True)
for o in list(hp.objects):
    me = o.data; bpy.data.objects.remove(o); bpy.data.meshes.remove(me)
bpy.data.collections.remove(hp)
for m in [m for m in bpy.data.materials if m.name.startswith('SRC_')]: bpy.data.materials.remove(m)
bpy.data.orphans_purge(do_recursive=True)
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND, compress=True)
print('main', round(os.path.getsize(bx.BLEND)/1e6,1), 'MB  source', round(os.path.getsize(src)/1e6,1), 'MB')
print('collections:', [(c.name, [ch.name for ch in c.children]) for c in bpy.data.collections if c.name=='Boxer_Character'])
