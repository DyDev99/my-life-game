"""Stage 6: prototype animation clips (in place, 30 fps)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import bpy
import bx, anim as A
from anim import GUARD, JAB, override, mirror

bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
sc = bpy.context.scene; sc.render.fps = 30
arm = bpy.data.objects['Boxer_Armature']
arm.animation_data_create()
for a in list(bpy.data.actions):
    if a.name.startswith('Boxer_'): bpy.data.actions.remove(a)

X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)


def P(base, **ch):
    return override(base, {k: v for k, v in ch.items()})


def clip(name, keys, sym=True, loop=False):
    act = bpy.data.actions.new(name); act.use_fake_user = True
    arm.animation_data.action = act
    for f, pose in keys:
        A.apply(arm, pose, frame=f, sym=sym)
    act.use_frame_range = True; act.frame_start = keys[0][0]; act.frame_end = keys[-1][0]
    act.use_cyclic = loop
    print(f'{name:14s} frames {keys[0][0]}-{keys[-1][0]}  keys {len(keys)}')
    return act


# ---- poses
G = GUARD
G_UP = override(G, {'pelvis': {'rot': [(Z, -12)], 'loc': (0, 0, -0.035)}, 'chest': [(X, 2), (Z, 2)]})
G_DN = override(G, {'pelvis': {'rot': [(Z, -12)], 'loc': (0, 0, -0.055)}, 'chest': [(X, 6), (Z, 2)]})

# idle (guard, breathing + light bounce) - loop
clip('Boxer_Idle', [(1, G_UP), (16, G_DN), (31, G_UP), (46, G_DN), (61, G_UP)], loop=True)

# walk: relaxed, alternating (left-forward contact pose authored, right mirrored)
W_CONTACT = {
    'pelvis': {'rot': [(Z, 4)], 'loc': (0, 0, -0.018)}, 'spine_02': [(Z, -4)], 'chest': [(Z, -4)],
    'thigh_L': [(X, -26)], 'calf_L': [(X, 6)], 'foot_L': [(X, 14)],
    'thigh_R': [(X, 18)], 'calf_R': [(X, 18)], 'foot_R': [(X, -14)],
    'upper_arm_L': [(Y, 74), (Z, 14)], 'lower_arm_L': [(Z, -20)],
    'upper_arm_R': [((0, -1, 0), 72), ((0, 0, -1), -22)], 'lower_arm_R': [((0, 0, -1), -30)],
    'head': [(X, -2)],
}
W_PASS = {
    'pelvis': {'rot': [], 'loc': (0, 0, 0.008)},
    'thigh_L': [(X, 6)], 'calf_L': [(X, 6)], 'foot_L': [(X, -4)],
    'thigh_R': [(X, -14)], 'calf_R': [(X, 58)], 'foot_R': [(X, 12)],
    'upper_arm_L': [(Y, 74), (Z, -4)], 'lower_arm_L': [(Z, -16)],
    'upper_arm_R': [((0, -1, 0), 74), ((0, 0, -1), -4)], 'lower_arm_R': [((0, 0, -1), -16)],
}
clip('Boxer_Walk', [(1, W_CONTACT), (9, W_PASS), (17, mirror(W_CONTACT)), (25, mirror(W_PASS)), (33, W_CONTACT)],
     sym=False, loop=True)

# run: forward lean, bigger strides, bent arms
R_CONTACT = {
    'pelvis': {'rot': [(Z, 6), (X, 8)], 'loc': (0, 0, -0.04)}, 'spine_01': [(X, 6)], 'chest': [(Z, -8), (X, 2)],
    'head': [(X, -10)],
    'thigh_L': [(X, -48)], 'calf_L': [(X, 22)], 'foot_L': [(X, 8)],
    'thigh_R': [(X, 22)], 'calf_R': [(X, 50)], 'foot_R': [(X, -24)],
    'upper_arm_L': [(Y, 66), (Z, 28)], 'lower_arm_L': [(Z, -80)],
    'upper_arm_R': [((0, -1, 0), 64), ((0, 0, -1), -50)], 'lower_arm_R': [((0, 0, -1), -95)],
}
R_FLY = {
    'pelvis': {'rot': [(X, 8)], 'loc': (0, 0, 0.02)}, 'spine_01': [(X, 6)], 'head': [(X, -10)],
    'thigh_L': [(X, -10)], 'calf_L': [(X, 30)], 'thigh_R': [(X, -30)], 'calf_R': [(X, 105)], 'foot_R': [(X, 10)],
    'upper_arm_L': [(Y, 66), (Z, -10)], 'lower_arm_L': [(Z, -85)],
    'upper_arm_R': [((0, -1, 0), 66), ((0, 0, -1), -10)], 'lower_arm_R': [((0, 0, -1), -85)],
}
clip('Boxer_Run', [(1, R_CONTACT), (6, R_FLY), (11, mirror(R_CONTACT)), (16, mirror(R_FLY)), (21, R_CONTACT)],
     sym=False, loop=True)

# jab (lead/left)
clip('Boxer_Jab', [(1, G), (5, override(JAB, {'lower_arm_L': [(Z, -40)], 'upper_arm_L': [(Y, 20), (Z, -66)]})),
                   (7, JAB), (9, JAB), (15, override(JAB, {'upper_arm_L': [(Y, 50), (Z, -60)], 'lower_arm_L': [(Z, -100)]})),
                   (20, G)], sym=True)

# cross (rear/right): hip & shoulder drive, right arm straight
CROSS = override(G, {
    'pelvis': {'rot': [(Z, 10)], 'loc': (0, -0.03, -0.05)}, 'spine_02': [(X, 5), (Z, 10)], 'chest': [(X, 6), (Z, 16)],
    'clavicle_R': [((0, 0, -1), -16)],
    'upper_arm_R': [((0, -1, 0), -6), ((0, 0, -1), -62)], 'lower_arm_R': [((0, 0, -1), -6)],
    'foot_R': [(X, -24), (Z, 4)], 'calf_R': [(X, 20)], 'thigh_R': [(X, 14), (Y, 0)],
})
clip('Boxer_Cross', [(1, G), (6, override(CROSS, {'lower_arm_R': [((0, 0, -1), -60)], 'upper_arm_R': [((0, -1, 0), 30), ((0, 0, -1), -60)]})),
                     (9, CROSS), (11, CROSS), (19, override(G, {'chest': [(X, 4), (Z, 8)]})), (24, G)], sym=True)

# hook (lead/left): horizontal bent arm, big torso rotation
HOOK = override(G, {
    'pelvis': {'rot': [(Z, -26)], 'loc': (0, 0, -0.055)}, 'spine_02': [(Z, -10)], 'chest': [(X, 4), (Z, -16)],
    'upper_arm_L': [(Y, 8), (Z, -30)], 'lower_arm_L': [(Z, -100)], 'hand_L': [(X, 60)],
    'thigh_L': [(X, -20), (Z, 12)], 'foot_L': [(Z, 30)],
})
WIND = override(G, {'pelvis': {'rot': [(Z, -2)], 'loc': (0, 0, -0.05)}, 'chest': [(X, 4), (Z, 10)],
                    'upper_arm_L': [(Y, 40), (Z, -30)], 'lower_arm_L': [(Z, -100)]})
clip('Boxer_Hook', [(1, G), (7, WIND), (12, HOOK), (15, HOOK), (22, override(G, {'chest': [(X, 4), (Z, -6)]})), (26, G)], sym=True)

# guard / block: tight high guard, chin tucked, small bob - loop
BLOCK = override(G, {
    'upper_arm_L': [(Y, 58), (Z, -40)], 'lower_arm_L': [(Z, -142)], 'hand_L': [(X, -18)],
    'upper_arm_R': [((0, -1, 0), 58), ((0, 0, -1), -40)], 'lower_arm_R': [((0, 0, -1), -142)], 'hand_R': [(X, -18)],
    'head': [(X, 16), (Z, 4)], 'neck': [(X, 6)], 'chest': [(X, 10), (Z, 0)],
    'pelvis': {'rot': [(Z, -10)], 'loc': (0, 0, -0.06)},
})
BLOCK2 = override(BLOCK, {'pelvis': {'rot': [(Z, -10)], 'loc': (0, 0, -0.075)}})
clip('Boxer_Guard', [(1, BLOCK), (20, BLOCK2), (40, BLOCK)], sym=True, loop=True)

# dodge (slip right + duck), return
SLIP = override(G, {
    'pelvis': {'rot': [(Z, -16), (Y, 6)], 'loc': (-0.05, 0, -0.13)},
    'spine_01': [(X, 10), (Y, -8)], 'spine_02': [(X, 8), (Y, -8)], 'chest': [(X, 8), (Y, -6)], 'head': [(X, 6), (Y, -4)],
    'thigh_L': [(X, -40), (Y, 4)], 'calf_L': [(X, 52)], 'foot_L': [(X, -12), (Z, 18)],
    'thigh_R': [(X, -10), (Y, -12)], 'calf_R': [(X, 50)], 'foot_R': [(X, -36), (Z, 18)],
})
clip('Boxer_Dodge', [(1, G), (7, SLIP), (13, SLIP), (24, G)], sym=True)

# crouch (crouched guard idle) - loop
C1 = A.CROUCH; C2 = override(A.CROUCH, {'pelvis': {'rot': [(X, 10)], 'loc': (0, 0.06, -0.34)}, 'chest': [(X, 9)]})
clip('Boxer_Crouch', [(1, C1), (20, C2), (40, C1)], sym=True, loop=True)

# victory: raise both arms, pump twice
V_UP = A.RAISE
V_PUMP = override(A.RAISE, {'upper_arm_L': [(Y, -42), (Z, -10)], 'lower_arm_L': [(Z, -70)], 'head': [(X, -18)],
                            'pelvis': {'rot': [], 'loc': (0, 0, -0.02)}})
NEU = A.NEUTRAL
clip('Boxer_Victory', [(1, NEU), (14, V_UP), (22, V_PUMP), (30, V_UP), (38, V_PUMP), (46, V_UP), (60, V_UP)], sym=True)

# defeat: stagger back, drop to the knees, slump
STAG = {
    'pelvis': {'rot': [(X, -6)], 'loc': (0, 0.04, -0.03)}, 'spine_02': [(X, -10)], 'chest': [(X, -8)],
    'head': [(X, -25), (Z, 12)], 'neck': [(X, -10)],
    'upper_arm_L': [(Y, 60), (Z, 20)], 'lower_arm_L': [(Z, -40)],
    'thigh_L': [(X, -12)], 'calf_L': [(X, 14)], 'thigh_R': [(X, 6)], 'calf_R': [(X, 10)],
}
KNEEL = {
    'pelvis': {'rot': [(X, 6)], 'loc': (0, 0.10, -0.43)}, 'spine_01': [(X, 14)], 'spine_02': [(X, 12)], 'chest': [(X, 10)],
    'head': [(X, 30)], 'neck': [(X, 12)],
    'upper_arm_L': [(Y, 80), (Z, -6)], 'lower_arm_L': [(Z, -12)], 'clavicle_L': [(Y, 8)],
    'thigh_L': [(X, -6)], 'calf_L': [(X, 96)], 'foot_L': [(X, 40)], 'toe_L': [(X, -30)],
}
SLUMP = override(KNEEL, {'spine_01': [(X, 22)], 'spine_02': [(X, 18)], 'chest': [(X, 14)], 'head': [(X, 40)],
                         'pelvis': {'rot': [(X, 10)], 'loc': (0, 0.12, -0.45)}})
clip('Boxer_Defeat', [(1, G), (10, STAG), (24, override(KNEEL, {'pelvis': {'rot': [(X, 6)], 'loc': (0, 0.10, -0.30)}})),
                      (32, KNEEL), (46, SLUMP), (60, SLUMP)], sym=True)

# reset to rest; leave no action assigned on the armature (actions kept via fake user)
arm.animation_data.action = None
for pb in arm.pose.bones:
    pb.rotation_quaternion = (1, 0, 0, 0); pb.location = (0, 0, 0)
sc.frame_start, sc.frame_end = 1, 60
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)
