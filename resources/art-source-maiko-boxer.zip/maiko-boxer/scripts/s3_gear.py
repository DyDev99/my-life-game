"""Stage 3: gear high-poly -> game meshes: gloves, shorts, boots (+eyelets), headband (+tails), hair."""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
from scipy.ndimage import map_coordinates
import bx, gear as G
from retopo import remesh, cut

bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
HP = bpy.data.collections['_HighPoly']; CH = bpy.data.collections['Character']
bpy.context.view_layer.layer_collection.children['_HighPoly'].exclude = False

for n in ('Boxer_Gloves_L', 'Boxer_Gloves_R', 'Boxer_Shorts', 'Boxer_Boot_L', 'Boxer_Boot_R',
          'Boxer_Headband', 'Boxer_Hair') + tuple(o.name for o in HP.objects if o.name.startswith('HP_') and
                                                    o.name not in ('HP_Body', 'HP_Head', 'HP_Hand_L', 'HP_Hand_R')):
    if n in bpy.data.objects:
        bpy.data.objects.remove(bpy.data.objects[n])


def load_hp(name, mirror=False):
    d = np.load(f'{bx.WORK}/hp_{name}.npz'); v = d['v'].copy(); f = d['f']
    if mirror:
        v[:, 0] *= -1; f = f[:, ::-1]
    ob = bx.mesh_from_np(f"HP_{name.capitalize()}{'_R' if mirror else ('_L' if name in ('glove', 'boot') else '')}", v, f, HP)
    bx.shade_smooth(ob); return ob


def project(ob, target):
    m = ob.modifiers.new('sw', 'SHRINKWRAP'); m.target = target; m.wrap_method = 'NEAREST_SURFACEPOINT'
    bx.apply_modifiers(ob)


def mirrored_copy(ob, name):
    me = ob.data.copy(); me.name = name
    me.transform(Matrix.Scale(-1, 4, (1, 0, 0))); me.flip_normals()
    o = bpy.data.objects.new(name, me); CH.objects.link(o); return o


def finish(ob, name):
    ob.name = ob.data.name = name; bx.link(ob, CH); bx.shade_smooth(ob); return ob


# ------------------------------------------------------------------ gloves
hp_gl = load_hp('glove'); hp_gr = load_hp('glove', mirror=True)
gl = remesh('LP_Glove', hp_gl, 1150, [], voxel=0.0016); project(gl, hp_gl)
gl = finish(gl, 'Boxer_Gloves_L'); gr = mirrored_copy(gl, 'Boxer_Gloves_R'); bx.shade_smooth(gr)

# ------------------------------------------------------------------ boots + metal eyelets
hp_bl = load_hp('boot'); hp_br = load_hp('boot', mirror=True)
bl = remesh('LP_Boot', hp_bl, 1400, [], voxel=0.0018); project(bl, hp_bl)
bvh = BVHTree.FromObject(hp_bl, bpy.context.evaluated_depsgraph_get())
bm = bmesh.new(); bm.from_mesh(bl.data)
mat_index_metal = 1
for p in np.load(f'{bx.WORK}/lace_points.npy'):
    loc, nrm, _, _ = bvh.find_nearest(Vector(p))
    rot = nrm.to_track_quat('Z', 'Y').to_matrix().to_4x4()
    r = bmesh.ops.create_circle(bm, cap_ends=False, segments=6, radius=0.0036)
    ring_o = r['verts']
    r2 = bmesh.ops.create_circle(bm, cap_ends=False, segments=6, radius=0.0019)
    ring_i = r2['verts']
    for vv in ring_o + ring_i:
        vv.co = Matrix.Translation(loc + nrm * 0.0012) @ rot @ vv.co
    for vv in ring_i:
        vv.co -= nrm * 0.0008
    for k in range(6):                                   # flat washer: 6 quads
        f = bm.faces.new((ring_o[k], ring_o[(k + 1) % 6], ring_i[(k + 1) % 6], ring_i[k]))
        f.material_index = mat_index_metal
        if f.normal.dot(nrm) < 0:
            f.normal_flip()
bm.to_mesh(bl.data); bm.free()
bl = finish(bl, 'Boxer_Boot_L'); br = mirrored_copy(bl, 'Boxer_Boot_R'); bx.shade_smooth(br)

# ------------------------------------------------------------------ shorts: open waist + hems, inward hem lip
hp_sh = load_hp('shorts')
sh = remesh('LP_Shorts', hp_sh, 1900, [], voxel=0.003); project(sh, hp_sh)
bm = bmesh.new(); bm.from_mesh(sh.data)
cut(bm, (0, 0, G.SHORTS_TOP - 0.004), (0, 0, 1), False)
cut(bm, (0, 0, G.SHORTS_HEM + 0.005), (0, 0, 1), True)
for side in (1, -1):    # lip: extrude open borders inward
    pass
border = [e for e in bm.edges if e.is_boundary]
ext = bmesh.ops.extrude_edge_only(bm, edges=border)
newv = [v for v in ext['geom'] if isinstance(v, bmesh.types.BMVert)]
for v in newv:
    top = v.co.z > 0.9
    if top:
        c = Vector((0, 0.004, v.co.z)); v.co.z -= 0.012
    else:
        c = Vector((0.11 if v.co.x > 0 else -0.11, -0.004, v.co.z)); v.co.z += 0.016
    d = (c - v.co); d.z = 0; v.co += d.normalized() * 0.006
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
bm.to_mesh(sh.data); bm.free()
sh = finish(sh, 'Boxer_Shorts')

# ------------------------------------------------------------------ headband + ribbon tails
hp_hb = load_hp('headband')
hb = remesh('LP_Headband', hp_hb, 760, [], voxel=0.0012)
if len(hb.data.polygons) > 20000:          # QuadriFlow fallback for the thin shell
    m = hb.modifiers.new('d', 'DECIMATE'); m.ratio = 1400 / len(hb.data.polygons); bx.apply_modifiers(hb)
project(hb, hp_hb)
bm = bmesh.new(); bm.from_mesh(hb.data)
from mathutils import geometry
tail_normals = {}
for k, path in enumerate(G.build_tails()):
    pts = [Vector(p) for p in path]
    # Catmull-Rom resample to 10 sections
    samples = []
    for i in range(len(pts) - 1):
        p0, p1, p2, p3 = pts[max(i - 1, 0)], pts[i], pts[i + 1], pts[min(i + 2, len(pts) - 1)]
        for s in np.linspace(0, 1, 4, endpoint=(i == len(pts) - 2)):
            samples.append(0.5 * ((2 * p1) + (-p0 + p2) * s + (2 * p0 - 5 * p1 + 4 * p2 - p3) * s * s +
                                  (-p0 + 3 * p1 - 3 * p2 + p3) * s ** 3))
    rows = []
    for i, c in enumerate(samples):
        tgt = (samples[min(i + 1, len(samples) - 1)] - samples[max(i - 1, 0)]).normalized()
        side = tgt.cross(Vector((0.3 if k == 0 else -0.2, 1, 0))).normalized()
        twist = math.radians(25 * math.sin(i * 0.6 + k))
        side = Matrix.Rotation(twist, 3, tgt) @ side
        nrm = side.cross(tgt).normalized()
        w = 0.0125 - 0.003 * i / len(samples)
        rows.append([bm.verts.new(c + side * w * a + nrm * 0.0013 * b) for a, b in
                     ((-1, 1), (1, 1), (1, -1), (-1, -1))])
        for vv, nn in zip(rows[-1], (nrm, nrm, -nrm, -nrm)):
            tail_normals[vv] = nn
    for i in range(len(rows) - 1):
        for j in range(4):
            bm.faces.new((rows[i][j], rows[i][(j + 1) % 4], rows[i + 1][(j + 1) % 4], rows[i + 1][j]))
    bm.faces.new(rows[-1][::-1])
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
# ribbon faces shade flat across their width (fabric), smooth along their length
tn_idx = {}
bm.verts.index_update()
for vv, nn in tail_normals.items():
    tn_idx[vv.index] = nn
tail_faces = {f.index for f in bm.faces if all(v.index in tn_idx for v in f.verts)}
bm.to_mesh(hb.data); bm.free()
me = hb.data; bx.shade_smooth(hb)
cn = [None] * len(me.loops)
for poly in me.polygons:
    for li in poly.loop_indices:
        vi = me.loops[li].vertex_index
        if poly.index in tail_faces:
            n0 = tn_idx[vi]
            cn[li] = n0 if n0.dot(poly.normal) > 0.5 else poly.normal.copy()
        else:
            cn[li] = me.corner_normals[li].vector.copy()
me.normals_split_custom_set(cn)
hb = finish(hb, 'Boxer_Headband')

# ------------------------------------------------------------------ hair: remove faces buried in the skull
hp_hr = load_hp('hair')
hr = remesh('LP_Hair', hp_hr, 3300, [], voxel=0.0014); project(hr, hp_hr)
H = np.load(f'{bx.WORK}/head_sdf.npz'); hd = H['d'].astype(np.float32); lo = H['lo']; res = float(H['res'])
bm = bmesh.new(); bm.from_mesh(hr.data)
cent = np.array([f.calc_center_median()[:] for f in bm.faces])
dval = map_coordinates(hd, ((cent - lo) / res).T, order=1, cval=1.0)
buried = [f for f, dv in zip(bm.faces, dval) if dv < -0.0025]
bmesh.ops.delete(bm, geom=buried, context='FACES')
bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context='VERTS')
print('hair: removed', len(buried), 'buried faces')
bm.to_mesh(hr.data); bm.free()
hr = finish(hr, 'Boxer_Hair')

for o in HP.objects:
    o.hide_render = True
bpy.context.view_layer.layer_collection.children['_HighPoly'].exclude = True
tot = 0
for o in CH.objects:
    t = bx.tri_count(o); tot += t; print(f'{o.name:18s} {t:6d} tris')
print('TOTAL', tot)
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)

# inspection: object colours
cols = {'Boxer_Body': (0.75, 0.55, 0.42, 1), 'Boxer_Head': (0.75, 0.55, 0.42, 1), 'Boxer_Hair': (0.08, 0.06, 0.05, 1),
        'Boxer_Headband': (0.75, 0.05, 0.05, 1), 'Boxer_Shorts': (0.75, 0.06, 0.06, 1),
        'Boxer_Gloves_L': (0.8, 0.05, 0.05, 1), 'Boxer_Gloves_R': (0.8, 0.05, 0.05, 1),
        'Boxer_Boot_L': (0.85, 0.1, 0.1, 1), 'Boxer_Boot_R': (0.85, 0.1, 0.1, 1)}
for n, c in cols.items():
    bpy.data.objects[n].color = c
p = bx.inspect_render(f'{bx.WORK}/s3.png', objs=list(CH.objects), views=('front', 'side', 'back', 'q34'), res=380, color='OBJECT')
bx.montage(p, f'{bx.WORK}/insp_s3.png')
p = bx.inspect_render(f'{bx.WORK}/s3h.png', objs=list(CH.objects), views=('front', 'q34', 'side', 'back'), res=360,
                      target=(0, 0, 1.62), ortho=0.36, color='OBJECT')
bx.montage(p, f'{bx.WORK}/insp_s3_head.png')
p = bx.inspect_render(f'{bx.WORK}/s3d.png', objs=list(CH.objects), views=('q34', 'side'), res=360,
                      target=(0.3, 0, 0.75), ortho=1.0, color='OBJECT')
bx.montage(p, f'{bx.WORK}/insp_s3_detail.png')
