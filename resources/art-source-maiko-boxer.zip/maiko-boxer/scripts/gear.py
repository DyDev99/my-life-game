"""Stage 3 high-poly gear sculpts. Left-side pieces at +X; right side mirrored in Blender."""
import numpy as np, sys, time
from sdf import Field, ellipsoid, sphere, cone, rbox, plane, smin, smax
import anatomy as A

rng = np.random.default_rng(7)


def zgrid(F):
    return (F.lo[2] + F.res * np.arange(F.n[2]))[None, None, :]


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)


# ---------------------------------------------------------------- glove (left)
def build_glove(res=0.0014):
    F = Field((0.66, -0.12, 1.30), (0.96, 0.10, 1.52), res)
    a = F.add
    a(ellipsoid((0.840, 0.000, 1.402), (0.074, 0.058, 0.066)))                                   # fist body
    a(ellipsoid((0.858, 0.000, 1.440), (0.050, 0.050, 0.030)), 0.025)                            # knuckle padding
    a(ellipsoid((0.885, 0.000, 1.390), (0.040, 0.050, 0.050)), 0.03)                             # striking face
    a(ellipsoid((0.805, -0.060, 1.392), (0.036, 0.022, 0.030), rot=(0, 0, -25)), 0.012)         # thumb pad
    a(cone((0.680, 0, 1.425), (0.775, 0, 1.418), 0.045, 0.051), 0.02)                            # cuff / wrist section
    F.sub(cone((0.650, 0, 1.425), (0.695, 0, 1.425), 0.034, 0.034), 0.004)                       # cuff opening lip
    F.sub(ellipsoid((0.835, -0.040, 1.420), (0.030, 0.006, 0.020), rot=(0, 0, -20)), 0.006)      # thumb crease
    for x in (0.712, 0.752):                                                                     # strap ridges
        a(cone((x, 0, 1.425), (x + 0.004, 0, 1.425), 0.0505, 0.0505), 0.003)
    F.clip(plane((1, 0, 0), 0.67))
    return F


# ---------------------------------------------------------------- boot (left)
LACE_Z = np.linspace(0.075, 0.245, 8)


def lace_points():
    """Eyelet positions (left boot): pairs either side of the tongue, up the instep and shaft."""
    pts = []
    for i, z in enumerate(LACE_Z):
        y = -0.088 + (z - 0.075) * 0.33 if z < 0.13 else -0.07 + (z - 0.13) * 0.12
        y = min(y, -0.045)
        for s in (-1, 1):
            pts.append((0.103 + s * 0.016, y, z))
    return np.array(pts)


def build_boot(res=0.0015):
    F = Field((0.02, -0.22, -0.002), (0.19, 0.11, 0.30), res)
    a = F.add
    a(cone((0.100, 0.026, 0.07), (0.100, 0.020, 0.275), 0.050, 0.053))                          # shaft
    a(sphere((0.100, 0.040, 0.050), 0.046), 0.02)                                                # heel
    a(ellipsoid((0.103, -0.045, 0.052), (0.054, 0.125, 0.046)), 0.025)                           # vamp
    a(ellipsoid((0.108, -0.135, 0.036), (0.050, 0.058, 0.033)), 0.02)                            # toe box
    a(ellipsoid((0.103, -0.060, 0.120), (0.034, 0.050, 0.060), rot=(-35, 0, 0)), 0.03)           # instep/tongue
    a(rbox((0.104, -0.048, 0.011), (0.056, 0.132, 0.011), 0.008), 0.004)                         # sole
    a(cone((0.100, 0.020, 0.262), (0.100, 0.020, 0.290), 0.054, 0.052), 0.004)                   # top collar (sock rim)
    F.sub(cone((0.100, 0.020, 0.270), (0.100, 0.020, 0.32), 0.042, 0.042), 0.004)                # leg opening
    # laces (criss-cross) - captured in the normal map
    P = lace_points()
    for i in range(len(LACE_Z) - 1):
        L0, R0, L1, R1 = P[2 * i], P[2 * i + 1], P[2 * i + 2], P[2 * i + 3]
        off = np.array([0, -0.004, 0])
        a(cone(L0 + off, R1 + off, 0.0022, 0.0022), 0.0015)
        a(cone(R0 + off, L1 + off, 0.0022, 0.0022), 0.0015)
    F.clip(plane((0, 0, 1), 0.0))
    return F


# ---------------------------------------------------------------- shorts (fit to the body sculpt)
SHORTS_TOP, SHORTS_HEM, BAND_LO = 1.040, 0.625, 0.982


def build_shorts(res=0.0025):
    F = A.build_body(res, lo=(-0.25, -0.18, 0.58), hi=(0.25, 0.18, 1.09))
    z = zgrid(F)
    F.d = F.d - 0.013 - 0.006 * smoothstep(BAND_LO - 0.004, BAND_LO + 0.004, z)                # cloth offset + waistband
    F.add(cone((0.100, 0.0, 0.86), (0.118, -0.006, 0.62), 0.090, 0.102), 0.045, sym=True)        # loose flared legs
    F.add(ellipsoid((0, -0.010, 0.86), (0.07, 0.10, 0.06)), 0.04)                                 # crotch drape
    # gentle vertical folds on the legs
    F.displace(lambda P: 0.0016 * np.sin(np.arctan2(P[:, 1], np.abs(P[:, 0]) - 0.11) * 7)
               * smoothstep(0.86, 0.66, P[:, 2]))
    F.clip(plane((0, 0, -1), -SHORTS_TOP)); F.clip(plane((0, 0, 1), SHORTS_HEM))
    return F


# ---------------------------------------------------------------- head-based pieces
def hairline(P):
    th = np.arctan2(P[..., 0], -P[..., 1])
    return 1.555 + 0.116 * (0.5 * (1 + np.cos(th))) ** 0.6       # front 1.671 (under the band), nape 1.555


BAND_Z0, BAND_H = 1.664, 0.013


def band_zc(P):
    return BAND_Z0 + 0.02 * P[..., 1]


def build_hair(res=0.0014):
    H = A.build_head(res)
    P = H._pts(np.zeros(3, int), H.n)
    hl = hairline(P); h = P[..., 2] - hl
    off = -0.003 + 0.021 * smoothstep(0.0, 0.014, h)      # ~2 cm volume, dips under skin at the hairline
    head_d = H.d.copy()
    cap = smax(head_d - off, (hl - 0.012) - P[..., 2], 0.0).astype(np.float32)
    H.d = cap.copy()
    gz, gy, gx = np.gradient(cap, res)[::-1]
    surf = np.nonzero((np.abs(cap) < res) & (h > 0.004) & (gz > -0.6))
    idx = rng.permutation(len(surf[0])); roots = []
    for k in idx:
        p = H.lo + res * np.array([surf[0][k], surf[1][k], surf[2][k]])
        if all(np.linalg.norm(p - q) > 0.0135 for q in roots):
            roots.append(p)
        if len(roots) >= 170:
            break
    crown = np.array([0.0, 0.030, 1.735]); used = 0
    for p in roots:
        i = tuple(((p - H.lo) / res).round().astype(int))
        n = np.array([gx[i], gy[i], gz[i]]); n /= np.linalg.norm(n) + 1e-9
        v = p - crown; t = v - n * (v @ n); t /= np.linalg.norm(t) + 1e-9
        zc = BAND_Z0 + 0.02 * p[1]
        front = p[1] < -0.045
        if front:      # bangs: fall forward/down over the band
            d = t * 0.35 + np.array([0, -0.45, -0.8]); L = rng.uniform(0.04, 0.06); r0 = rng.uniform(0.008, 0.011)
        elif p[2] > 1.70:   # crown: messy, kicks up/out
            d = t * 0.8 + n * 0.55 + np.array([0, 0, 0.05]); L = rng.uniform(0.035, 0.06); r0 = rng.uniform(0.009, 0.013)
        else:
            d = t * 0.8 + n * 0.35 + np.array([0, 0, -0.2]); L = rng.uniform(0.03, 0.05); r0 = rng.uniform(0.008, 0.011)
        d += rng.normal(0, 0.2, 3); d /= np.linalg.norm(d)
        base = p - n * 0.004
        p1 = base + d * L * 0.55
        d2 = d + np.array([0, 0, -0.45]) - n * 0.15; d2 /= np.linalg.norm(d2)
        p2 = p1 + d2 * L * 0.45
        if not front:
            if any(abs(q[2] - (BAND_Z0 + 0.02 * q[1])) < BAND_H + 0.008 for q in (p, p1, p2)):
                continue                                   # keep the band visible
            if p2[2] < hairline(p2[None])[0] - 0.015:
                continue
        else:
            p2[2] = max(p2[2], 1.652)                       # bangs stop above the brows
        H.add(cone(base, p1, r0, r0 * 0.62), 0.006)
        H.add(cone(p1, p2, r0 * 0.62, 0.0014), 0.003)
        used += 1
    H.displace(lambda Q: 0.0006 * np.sin(np.arctan2(Q[:, 0], -(Q[:, 1] - 0.02)) * 90))
    out = sys.argv[1]
    np.savez_compressed(f'{out}/head_sdf.npz', d=head_d.astype(np.float16), lo=H.lo, res=res)
    np.savez_compressed(f'{out}/cap_sdf.npz', d=np.minimum(head_d, cap).astype(np.float16), lo=H.lo, res=res)
    print('hair clumps', used)
    return H


def build_headband(res=0.0014):
    C = np.load(f'{sys.argv[1]}/cap_sdf.npz'); F = Field(C['lo'], C['lo'] + float(C['res']) * (np.array(C['d'].shape) - 1), float(C['res']))
    base = C['d'].astype(np.float32); F.n = np.array(base.shape); F.d = base.copy()
    P = F._pts(np.zeros(3, int), F.n)
    d = base - 0.0025
    shell = smax(d, -(d + 0.005), 0.0)
    slab = np.abs(P[..., 2] - band_zc(P)) - BAND_H
    F.d = smax(shell, slab, 0.0015).astype(np.float32)
    F.add(ellipsoid((0, 0.118, 1.666), (0.020, 0.013, 0.016)), 0.004)                            # knot
    return F


def build_tails():
    """Headband tails as ribbon centre-lines (built as meshes in Blender)."""
    return [np.array([(0.010, 0.126, 1.660), (0.034, 0.142, 1.628), (0.050, 0.158, 1.592), (0.058, 0.170, 1.556)]),
            np.array([(-0.004, 0.127, 1.656), (0.012, 0.152, 1.622), (0.020, 0.170, 1.590), (0.024, 0.182, 1.560)])]


if __name__ == '__main__':
    out = sys.argv[1]
    only = sys.argv[2:] or ['glove', 'boot', 'shorts', 'hair', 'headband']
    for name, fn in [(n, globals()['build_' + n]) for n in only]:
        t = time.time(); F = fn(); v, f = F.mesh()
        np.savez(f'{out}/hp_{name}.npz', v=v, f=f)
        print(name, len(v), 'verts', len(f), 'tris', f'{time.time() - t:.1f}s')
    np.save(f'{out}/lace_points.npy', lace_points())
