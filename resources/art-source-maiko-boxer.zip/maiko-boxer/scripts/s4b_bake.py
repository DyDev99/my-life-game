"""Stage 4b: procedural source shaders on the high-poly sculpts -> baked PBR textures on the game meshes.
Final materials use image textures only (Principled BSDF, directly linked -> FBX/Unity friendly)."""
import sys, os, math, time
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
import bx, gear as G

ONLY = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else None
bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
O = bpy.data.objects; sc = bpy.context.scene
TEX = os.path.join(bx.ROOT, 'Textures'); ART = os.path.join(bx.WORK, 'art')
bpy.context.view_layer.layer_collection.children['_HighPoly'].exclude = False
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.use_denoising = False
if sc.world is None:
    sc.world = bpy.data.worlds.new('World')
sc.world.light_settings.distance = 0.12


# ============================================================== node builder
class NB:
    def __init__(self, mat):
        mat.use_nodes = True; self.nt = mat.node_tree; self.nt.nodes.clear(); self.N = self.nt.nodes; self.L = self.nt.links
        self._geo = None

    def node(self, t, **kw):
        n = self.N.new(t)
        for k, v in kw.items():
            setattr(n, k, v)
        return n

    def s(self, x):
        if isinstance(x, (int, float)):
            n = self.node('ShaderNodeValue'); n.outputs[0].default_value = x; return n.outputs[0]
        if isinstance(x, tuple):
            n = self.node('ShaderNodeRGB'); n.outputs[0].default_value = (*x[:3], 1); return n.outputs[0]
        return x

    def link(self, a, sock):
        a = self.s(a)
        self.L.new(a, sock)

    def math(self, op, a, b=0.0, clamp=False):
        n = self.node('ShaderNodeMath', operation=op, use_clamp=clamp)
        for i, v in enumerate((a, b)):
            if isinstance(v, (int, float)):
                n.inputs[i].default_value = v
            else:
                self.L.new(v, n.inputs[i])
        return n.outputs[0]

    def add(self, a, b): return self.math('ADD', a, b)
    def mul(self, a, b, clamp=False): return self.math('MULTIPLY', a, b, clamp)
    def sub(self, a, b): return self.math('SUBTRACT', a, b)
    def absf(self, a): return self.math('ABSOLUTE', a)
    def mx(self, a, b): return self.math('MAXIMUM', a, b)
    def mn(self, a, b): return self.math('MINIMUM', a, b)

    def smooth(self, x, e0, e1):
        """0 at e0 -> 1 at e1 (smoothstep), e0 may exceed e1 for falling edges."""
        n = self.node('ShaderNodeMapRange', interpolation_type='SMOOTHSTEP', clamp=True)
        self.L.new(x, n.inputs['Value'])
        lo, hi = (e0, e1) if e0 < e1 else (e1, e0)
        n.inputs['From Min'].default_value = lo; n.inputs['From Max'].default_value = hi
        n.inputs['To Min'].default_value = 0.0 if e0 < e1 else 1.0
        n.inputs['To Max'].default_value = 1.0 if e0 < e1 else 0.0
        return n.outputs['Result']

    def band(self, x, a, b, soft=0.002):
        return self.mul(self.smooth(x, a - soft, a + soft), self.smooth(x, b + soft, b - soft))

    def geo(self):
        if self._geo is None:
            g = self.node('ShaderNodeNewGeometry')
            p = self.node('ShaderNodeSeparateXYZ'); self.L.new(g.outputs['Position'], p.inputs[0])
            n = self.node('ShaderNodeSeparateXYZ'); self.L.new(g.outputs['Normal'], n.inputs[0])
            self._geo = (g, p.outputs, n.outputs)
        return self._geo

    @property
    def x(self): return self.geo()[1][0]
    @property
    def y(self): return self.geo()[1][1]
    @property
    def z(self): return self.geo()[1][2]
    @property
    def nx(self): return self.geo()[2][0]
    @property
    def ny(self): return self.geo()[2][1]
    @property
    def nz(self): return self.geo()[2][2]

    def mix(self, fac, a, b):
        n = self.node('ShaderNodeMix', data_type='RGBA', clamp_factor=True)
        for sock, v in ((n.inputs['Factor'], fac),):
            if isinstance(v, (int, float)): sock.default_value = v
            else: self.L.new(v, sock)
        for idx, v in ((6, a), (7, b)):
            if isinstance(v, tuple): n.inputs[idx].default_value = (*v[:3], 1)
            else: self.L.new(v, n.inputs[idx])
        return n.outputs[2]

    def mixf(self, fac, a, b):
        return self.add(a if not isinstance(a, (int, float)) else self.s(a),
                        self.mul(fac, self.sub(b, a) if not isinstance(b, (int, float)) or not isinstance(a, (int, float)) else (b - a)))

    def proj(self, img, u_axis, v_axis, cu, cv, size_u, size_v):
        """Planar decal: u = (u_axis - cu)/size_u + .5 . Returns (color, alpha)."""
        u = self.add(self.math('DIVIDE', self.sub(u_axis, cu), size_u), 0.5)
        v = self.add(self.math('DIVIDE', self.sub(v_axis, cv), size_v), 0.5)
        c = self.node('ShaderNodeCombineXYZ'); self.L.new(u, c.inputs[0]); self.L.new(v, c.inputs[1])
        t = self.node('ShaderNodeTexImage', extension='CLIP', interpolation='Cubic')
        t.image = bpy.data.images.load(os.path.join(ART, img), check_existing=True)
        self.L.new(c.outputs[0], t.inputs['Vector'])
        return t.outputs['Color'], t.outputs['Alpha']

    def noise(self, scale, detail=3.0, rough=0.5):
        n = self.node('ShaderNodeTexNoise'); n.inputs['Scale'].default_value = scale
        n.inputs['Detail'].default_value = detail; n.inputs['Roughness'].default_value = rough
        return n.outputs['Fac']

    def voronoi(self, scale):
        n = self.node('ShaderNodeTexVoronoi'); n.inputs['Scale'].default_value = scale; return n.outputs['Distance']

    def wave(self, scale, axis='X', bands=True, distortion=0.0):
        n = self.node('ShaderNodeTexWave', wave_type='BANDS', bands_direction=axis)
        n.inputs['Scale'].default_value = scale; n.inputs['Distortion'].default_value = distortion
        return n.outputs['Fac']

    def bump(self, h, strength, dist):
        b = self.node('ShaderNodeBump'); b.inputs['Strength'].default_value = strength
        b.inputs['Distance'].default_value = dist; self.L.new(h, b.inputs['Height']); return b.outputs['Normal']

    def attr(self, name):
        a = self.node('ShaderNodeAttribute', attribute_name=name); return a.outputs['Fac']

    def out(self, base, rough, normal=None, metallic=0.0):
        p = self.node('ShaderNodeBsdfPrincipled'); o = self.node('ShaderNodeOutputMaterial')
        self.L.new(p.outputs[0], o.inputs['Surface'])
        for name, v in (('Base Color', base), ('Roughness', rough), ('Metallic', metallic)):
            if isinstance(v, tuple): p.inputs[name].default_value = (*v[:3], 1)
            elif isinstance(v, (int, float)): p.inputs[name].default_value = v
            else: self.L.new(v, p.inputs[name])
        if normal is not None:
            self.L.new(normal, p.inputs['Normal'])
        return p


def lin(r, g, b):          # sRGB 0-255 -> linear
    f = lambda c: (c / 255) / 12.92 if c / 255 <= 0.04045 else ((c / 255 + 0.055) / 1.055) ** 2.4
    return (f(r), f(g), f(b))


SKIN, SKIN_D, SKIN_W = lin(158, 100, 68), lin(132, 80, 54), lin(172, 112, 78)
RED, RED_D = lin(196, 28, 32), lin(150, 16, 22)
WHITE, BLACK = lin(236, 234, 228), lin(18, 18, 20)
HAIR, HAIR_L = lin(22, 16, 13), lin(52, 36, 27)


# ============================================================== source shaders (on high-poly)
def src_skin(mat):
    b = NB(mat)
    n1 = b.noise(14, 4); n2 = b.noise(160, 2)
    col = b.mix(n1, SKIN_D, SKIN_W)
    col = b.mix(b.mul(n2, 0.25), col, SKIN_D)
    # areolae (subtle)
    for s in (1, -1):
        d = b.math('LENGTH', 0) if False else None
    ax = b.sub(b.absf(b.x), 0.090); az = b.sub(b.z, 1.302)
    dist = b.math('SQRT', b.add(b.mul(ax, ax), b.mul(az, az)))
    areo = b.mul(b.smooth(dist, 0.011, 0.007), b.smooth(b.y, -0.03, -0.05))
    col = b.mix(b.mul(areo, 0.65), col, lin(120, 70, 52))
    # face paint (brows, lash line, lips): front projection, front-facing only
    pc, pa = b.proj('face_paint.png', b.x, b.z, 0.0, 1.6, 0.2, 0.2)
    pa = b.mul(b.mul(pa, 1.0), b.smooth(b.y, -0.035, -0.06))
    col = b.mix(pa, col, pc)
    rough = b.add(0.50, b.mul(b.noise(40, 2), 0.12))
    rough = b.mixf(b.mul(pa, 0.6), rough, 0.42)
    nrm = b.bump(b.add(b.mul(b.noise(900, 2), 0.6), b.mul(b.voronoi(1400), 0.4)), 0.12, 0.0004)
    b.out(col, rough, nrm)


def src_hair(mat):
    b = NB(mat)
    streak = b.noise(55, 6, 0.65)
    col = b.mix(b.smooth(streak, 0.35, 0.75), HAIR, HAIR_L)
    b.out(col, b.add(0.40, b.mul(streak, 0.12)), b.bump(b.noise(420, 3), 0.25, 0.0005))


def src_headband(mat):
    b = NB(mat)
    weave = b.mul(b.wave(1800, 'X'), b.wave(1800, 'Z'))
    col = b.mix(b.mul(b.noise(30, 3), 0.5), RED, RED_D)
    b.out(col, b.add(0.80, b.mul(weave, 0.1)), b.bump(weave, 0.25, 0.0003))


def src_glove(mat):
    b = NB(mat)
    leather = b.noise(25, 3)
    col = b.mix(b.mul(leather, 0.45), RED, RED_D)
    strap = b.band(b.x, 0.705, 0.762, 0.0015)
    trim = b.mx(b.band(b.x, 0.698, 0.705, 0.001), b.band(b.x, 0.762, 0.769, 0.001))
    col = b.mix(strap, col, BLACK); col = b.mix(trim, col, WHITE)
    # emblem on the back of the hand (top), towers pointing to the knuckles
    ec, ea = b.proj('angkor.png', b.y, b.x, 0.0, 0.842, -0.06, 0.06)
    ea = b.mul(ea, b.smooth(b.nz, 0.45, 0.75))
    col = b.mix(ea, col, WHITE)
    # palm seam stitch line (underside, along the glove)
    stitch = b.mul(b.band(b.y, -0.0012, 0.0012, 0.0005), b.mul(b.smooth(b.nz, -0.5, -0.8), b.smooth(b.wave(900, 'X'), 0.4, 0.6)))
    rough = b.add(0.30, b.mul(leather, 0.10)); rough = b.mixf(strap, rough, 0.55)
    grain = b.add(b.mul(b.voronoi(700), 0.7), b.mul(stitch, -1.0))
    b.out(col, rough, b.bump(grain, 0.15, 0.0004))


def src_shorts(mat):
    b = NB(mat)
    folds = b.noise(18, 3)
    col = b.mix(b.mul(folds, 0.5), RED, RED_D)
    band = b.smooth(b.z, G.BAND_LO - 0.0015, G.BAND_LO + 0.0015)
    hem = b.smooth(b.z, G.SHORTS_HEM + 0.020, G.SHORTS_HEM + 0.016)
    stripe = b.mul(b.mul(b.band(b.y, -0.016, 0.022, 0.002), b.smooth(b.absf(b.x), 0.10, 0.12)), b.sub(1.0, band))
    col = b.mix(stripe, col, WHITE)
    col = b.mix(b.mul(hem, b.sub(1.0, stripe)), col, RED_D)
    col = b.mix(band, col, lin(232, 230, 226))
    lc, la = b.proj('khmer_label.png', b.x, b.z, 0.0, (G.BAND_LO + G.SHORTS_TOP) / 2 - 0.001, 0.108, 0.036)
    la = b.mul(la, b.smooth(b.y, -0.02, -0.06)); col = b.mix(la, col, lc)
    for sx in (1, -1):
        ec, ea = b.proj('angkor.png', b.x, b.z, sx * 0.128, 0.705, 0.080, 0.080)
        ea = b.mul(b.mul(ea, b.smooth(b.y, -0.02, -0.06)), b.smooth(b.mul(b.x, sx), 0.02, 0.05))
        col = b.mix(b.mul(ea, 0.95), col, WHITE)
    rib = b.mul(b.wave(500, 'X'), band)
    rough = b.add(0.42, b.mul(folds, 0.10)); rough = b.mixf(b.mx(band, stripe), rough, 0.7)
    b.out(col, rough, b.bump(b.add(b.mul(b.noise(1200, 2), 0.3), rib), 0.2, 0.0004))


def src_boot(mat):
    b = NB(mat)
    leather = b.noise(30, 3)
    col = b.mix(b.mul(leather, 0.4), RED, RED_D)
    lace = b.attr('lace')
    sole = b.smooth(b.z, 0.0245, 0.0215)
    sock = b.smooth(b.z, 0.258, 0.262)
    side = b.smooth(b.absf(b.sub(b.x, 0.103)), 0.030, 0.036)
    swoosh = b.mul(b.mul(b.band(b.sub(b.z, b.mul(b.add(b.y, 0.02), 0.45)), 0.052, 0.072, 0.002),
                         b.band(b.y, -0.12, 0.05, 0.004)), side)
    col = b.mix(swoosh, col, WHITE)
    ec, ea = b.proj('angkor.png', b.y, b.z, 0.012, 0.165, -0.06, 0.06)
    ea = b.mul(ea, b.smooth(b.x, 0.135, 0.145)); col = b.mix(ea, col, WHITE)
    col = b.mix(lace, col, WHITE); col = b.mix(sole, col, lin(225, 222, 215)); col = b.mix(sock, col, WHITE)
    rough = b.add(0.34, b.mul(leather, 0.1)); rough = b.mixf(b.mx(sole, b.mx(sock, lace)), rough, 0.85)
    b.out(col, rough, b.bump(b.add(b.mul(b.voronoi(650), 0.6), b.mul(sole, b.wave(700, 'Y'))), 0.18, 0.0004))


# lace mask as a vertex attribute on the boot high-poly
hpb = O['HP_Boot_L']; P = np.load(f'{bx.WORK}/lace_points.npy')
segs = []
for i in range(len(G.LACE_Z) - 1):
    L0, R0, L1, R1 = P[2 * i], P[2 * i + 1], P[2 * i + 2], P[2 * i + 3]
    segs += [(L0, R1), (R0, L1)]
co = np.empty(len(hpb.data.vertices) * 3, np.float32); hpb.data.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
dmin = np.full(len(co), 1.0)
for a, c in segs:
    a = a + [0, -0.004, 0]; c = c + [0, -0.004, 0]; ba = c - a
    h = np.clip(((co - a) @ ba) / (ba @ ba), 0, 1); dmin = np.minimum(dmin, np.linalg.norm(co - a - h[:, None] * ba, axis=1))
lace = np.clip((0.0034 - dmin) / 0.0008, 0, 1).astype(np.float32)
at = hpb.data.attributes.get('lace') or hpb.data.attributes.new('lace', 'FLOAT', 'POINT'); at.data.foreach_set('value', lace)

# safety: make every high-poly face outward (signed volume) before baking
for o in bpy.data.collections['_HighPoly'].objects:
    me = o.data; co = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
    tri = np.array([p.vertices[:3] for p in me.polygons])
    vol = np.einsum('ij,ij->i', co[tri[:, 0]], np.cross(co[tri[:, 1]], co[tri[:, 2]])).sum()
    if vol < 0:
        me.flip_normals(); print('flipped', o.name)

SOURCES = {'skin': src_skin, 'hair': src_hair, 'headband': src_headband, 'glove': src_glove, 'shorts': src_shorts, 'boot': src_boot}
HPMAP = {'skin': ['HP_Body', 'HP_Hand_L', 'HP_Hand_R', 'HP_Head'], 'hair': ['HP_Hair'], 'headband': ['HP_Headband'],
         'glove': ['HP_Glove_L', 'HP_Glove_R'], 'shorts': ['HP_Shorts'], 'boot': ['HP_Boot_L', 'HP_Boot_R']}
for k, fn in SOURCES.items():
    m = bpy.data.materials.get(f'SRC_{k}') or bpy.data.materials.new(f'SRC_{k}')
    fn(m)
    for n in HPMAP[k]:
        O[n].data.materials.clear(); O[n].data.materials.append(m)


# ============================================================== final materials
def image(name, res, color=True, alpha=False):
    img = bpy.data.images.get(name)
    if img is None or tuple(img.size) != (res, res):
        if img: bpy.data.images.remove(img)
        img = bpy.data.images.new(name, res, res, alpha=alpha, float_buffer=False)
    img.colorspace_settings.name = 'sRGB' if color else 'Non-Color'
    img.filepath_raw = os.path.join(TEX, name + '.png'); img.file_format = 'PNG'
    return img


def final_mat(name, prefix, res, metallic=0.0):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True; nt = m.node_tree; nt.nodes.clear()
    p = nt.nodes.new('ShaderNodeBsdfPrincipled'); o = nt.nodes.new('ShaderNodeOutputMaterial')
    nt.links.new(p.outputs[0], o.inputs['Surface']); p.location = (300, 0); o.location = (600, 0)
    imgs = {k: image(f'{prefix}_{k}', res, k == 'BaseColor') for k in ('BaseColor', 'Roughness', 'Normal')}
    imgs['AO'] = image(f'{prefix}_AO', max(512, res // 2), False)
    tb = nt.nodes.new('ShaderNodeTexImage'); tb.image = imgs['BaseColor']; tb.location = (-400, 300)
    nt.links.new(tb.outputs[0], p.inputs['Base Color'])
    tr = nt.nodes.new('ShaderNodeTexImage'); tr.image = imgs['Roughness']; tr.location = (-400, 0)
    nt.links.new(tr.outputs[0], p.inputs['Roughness'])
    tn = nt.nodes.new('ShaderNodeTexImage'); tn.image = imgs['Normal']; tn.location = (-400, -300)
    nm = nt.nodes.new('ShaderNodeNormalMap'); nm.location = (0, -300)
    nt.links.new(tn.outputs[0], nm.inputs['Color'])          # Normal Map -> BSDF linked after baking
    ta = nt.nodes.new('ShaderNodeTexImage'); ta.image = imgs['AO']; ta.location = (-400, -600); ta.label = 'AO (export separately)'
    p.inputs['Metallic'].default_value = metallic
    m['tex_prefix'] = prefix
    return m, imgs


def plain_mat(name, base, rough, metallic=0.0, img=None):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True; nt = m.node_tree; nt.nodes.clear()
    p = nt.nodes.new('ShaderNodeBsdfPrincipled'); o = nt.nodes.new('ShaderNodeOutputMaterial')
    nt.links.new(p.outputs[0], o.inputs['Surface'])
    p.inputs['Base Color'].default_value = (*base, 1); p.inputs['Roughness'].default_value = rough
    p.inputs['Metallic'].default_value = metallic
    if img:
        t = nt.nodes.new('ShaderNodeTexImage'); t.image = img; nt.links.new(t.outputs[0], p.inputs['Base Color'])
    return m


MATS = {}
MATS['skin'] = final_mat('MAT_Skin', 'T_Boxer_Skin', 2048)
MATS['hair'] = final_mat('MAT_Hair', 'T_Boxer_Hair', 1024)
MATS['headband'] = final_mat('MAT_Headband', 'T_Boxer_Headband', 512)
MATS['glove'] = final_mat('MAT_BoxingGloves', 'T_Boxer_Gloves', 1024)
MATS['shorts'] = final_mat('MAT_Shorts', 'T_Boxer_Shorts', 2048)
MATS['boot'] = final_mat('MAT_Boots', 'T_Boxer_Boots', 1024)
eye_img = bpy.data.images.load(os.path.join(ART, 'eye.png'), check_existing=True)
eye_img.name = 'T_Boxer_Eyes_BaseColor'
mat_eyes = plain_mat('MAT_Eyes', (1, 1, 1), 0.08, img=eye_img)
mat_metal = plain_mat('MAT_MetalDetails', (0.80, 0.80, 0.82), 0.28, metallic=1.0)

# assign
def assign(ob, mats, idx_fn=None):
    ob.data.materials.clear()
    for m in mats:
        ob.data.materials.append(m)
    if idx_fn:
        ob.data.polygons.foreach_set('material_index', [idx_fn(p) for p in ob.data.polygons])

assign(O['Boxer_Body'], [MATS['skin'][0]], lambda p: 0)
eye_flags = [bool(a.value) for a in O['Boxer_Head'].data.attributes['is_eye'].data]   # copy BEFORE slots change
assign(O['Boxer_Head'], [MATS['skin'][0], mat_eyes], lambda p: 1 if eye_flags[p.index] else 0)
print('head faces: skin', eye_flags.count(False), 'eyes', eye_flags.count(True))
assign(O['Boxer_Hair'], [MATS['hair'][0]], lambda p: 0)
assign(O['Boxer_Headband'], [MATS['headband'][0]], lambda p: 0)
for n in ('Boxer_Gloves_L', 'Boxer_Gloves_R'):
    assign(O[n], [MATS['glove'][0]], lambda p: 0)
assign(O['Boxer_Shorts'], [MATS['shorts'][0]], lambda p: 0)
for n in ('Boxer_Boot_L', 'Boxer_Boot_R'):
    old = [p.material_index for p in O[n].data.polygons]
    assign(O[n], [MATS['boot'][0], mat_metal]); O[n].data.polygons.foreach_set('material_index', old)


# ============================================================== bake
trash = bpy.data.images.get('_bake_trash') or bpy.data.images.new('_bake_trash', 64, 64)


def set_targets(ob, img):
    for m in ob.data.materials:
        nt = m.node_tree; n = nt.nodes.get('_bake') or nt.nodes.new('ShaderNodeTexImage'); n.name = '_bake'
        n.image = img if m.get('tex_prefix') and img.name.startswith(m['tex_prefix']) else trash
        for x in nt.nodes: x.select = False
        n.select = True; nt.nodes.active = n


def uv_mask(ob, img):
    """Rasterise the UV triangles of faces whose material bakes into img (plus bake margin)."""
    from PIL import Image as PI, ImageDraw, ImageFilter
    W, H = img.size; im = PI.new('L', (W, H), 0); d = ImageDraw.Draw(im)
    me = ob.data; uv = me.uv_layers.active.data
    ok = {i for i, m in enumerate(me.materials) if m.get('tex_prefix') and img.name.startswith(m['tex_prefix'])}
    for p in me.polygons:
        if p.material_index in ok:
            d.polygon([(uv[i].uv.x * W, uv[i].uv.y * H) for i in p.loop_indices], fill=255)   # rows = v (bottom-up)
    im = im.filter(ImageFilter.MaxFilter(2 * (16 if W >= 2048 else 8) + 1))
    return np.asarray(im) > 127


def write_png(img):
    """Write the bake buffer ourselves (Image.save() proved unreliable for re-baked file images)."""
    from PIL import Image as PI
    W, H = img.size; px = np.array(img.pixels[:], np.float32).reshape(H, W, 4)[::-1, :, :3]
    path = bpy.path.abspath(img.filepath_raw or img.filepath)
    PI.fromarray((np.clip(px, 0, 1) * 255 + 0.5).astype(np.uint8)).save(path)
    return path


def bake(target, sources, kind, img, extrusion, clear=True, samples=1):
    if not clear:
        # Baking into an existing image without clearing re-encodes its pixels (inverts normal maps), so bake
        # into a cleared temp image and composite by coverage (alpha).
        tmp = bpy.data.images.new('_bake_tmp', img.size[0], img.size[1], alpha=True)
        tmp.colorspace_settings.name = img.colorspace_settings.name
        tmp.generated_color = (0, 0, 0, 0)
        tmp.name = img.name + '__tmp'
        bake(target, sources, kind, tmp, extrusion, clear=True, samples=samples)
        base = np.array(img.pixels[:], np.float32).reshape(-1, 4); t = np.array(tmp.pixels[:], np.float32).reshape(-1, 4)
        m = uv_mask(target, img).ravel(); base[m, :3] = t[m, :3]; base[:, 3] = 1.0
        img.pixels.foreach_set(base.ravel()); img.update()
        print(f'    composited {m.mean():.3f} of {img.name}')
        bpy.data.images.remove(tmp)
        return
    sc.cycles.samples = samples
    set_targets(target, img)
    for o in bpy.context.view_layer.objects: o.select_set(False)
    for s in sources: O[s].select_set(True)
    target.select_set(True); bpy.context.view_layer.objects.active = target
    bs = sc.render.bake
    bs.use_selected_to_active = bool(sources); bs.cage_extrusion = extrusion; bs.max_ray_distance = extrusion * 2.5
    bs.margin = 16 if img.size[0] >= 2048 else 8; bs.use_clear = clear; bs.margin_type = 'EXTEND'
    kw = dict(type=kind)
    if kind == 'DIFFUSE':
        bs.use_pass_direct = False; bs.use_pass_indirect = False; bs.use_pass_color = True
    if kind == 'NORMAL':
        bs.normal_space = 'TANGENT'
    t = time.time()
    with bpy.context.temp_override(active_object=target, object=target,
                                   selected_objects=[target] + [O[s] for s in sources]):
        bpy.ops.object.bake(**kw)
    px = np.array(img.pixels[:]).reshape(-1, 4)[::97, :3]
    print(f'  bake {kind:9s} {target.name:16s} -> {img.name} {img.size[0]}px {time.time() - t:.1f}s  mean {px.mean(0).round(3)}'
          f'  sel={[o.name for o in bpy.context.selected_objects]} s2a={bs.use_selected_to_active}')


# skin atlas: bake body+head in ONE pass via a temporary joined copy (multi-pass into one image is unreliable)
cb = bpy.data.objects.new('_BakeSkin', O['Boxer_Body'].data.copy()); sc.collection.objects.link(cb)
ch = bpy.data.objects.new('_BakeSkinHead', O['Boxer_Head'].data.copy()); sc.collection.objects.link(ch)
with bpy.context.temp_override(active_object=cb, selected_editable_objects=[cb, ch]):
    bpy.ops.object.join()
bake_skin = cb; tmpme = cb.data
print('bake skin object', len(tmpme.polygons), 'faces, uv layers', [l.name for l in tmpme.uv_layers], [m.name for m in tmpme.materials])
JOBS = [  # (key, target, sources, extrusion)
    ('skin', '_BakeSkin', ['HP_Body', 'HP_Hand_L', 'HP_Hand_R', 'HP_Head'], 0.006),
    ('hair', 'Boxer_Hair', ['HP_Hair'], 0.008),
    ('headband', 'Boxer_Headband', ['HP_Headband'], 0.004),
    ('glove', 'Boxer_Gloves_L', ['HP_Glove_L'], 0.006),
    ('shorts', 'Boxer_Shorts', ['HP_Shorts'], 0.008),
    ('boot', 'Boxer_Boot_L', ['HP_Boot_L'], 0.006),
]
char = [o for o in bpy.data.collections['Character'].objects]
for o in O:
    if o.type == 'MESH' and o not in char and not o.name.startswith('HP_'):
        o.hide_render = True
bake_skin.hide_render = False
done = set()
for key, tgt, srcs, ext in JOBS:
    if ONLY and key not in ONLY:
        continue
    m, imgs = MATS[key]; first = key not in done; done.add(key)
    for o in O:
        if o.name.startswith('HP_'): o.hide_render = o.name not in srcs
    for kind, k in (('DIFFUSE', 'BaseColor'), ('ROUGHNESS', 'Roughness'), ('NORMAL', 'Normal')):
        bake(O[tgt], srcs, kind, imgs[k], ext); print('    ->', write_png(imgs[k]))
    for o in O:
        if o.name.startswith('HP_'): o.hide_render = True
    if tgt == '_BakeSkin':
        O['Boxer_Body'].hide_render = O['Boxer_Head'].hide_render = True     # the joined copy occludes instead
    bake(O[tgt], [], 'AO', imgs['AO'], ext, samples=24); print('    ->', write_png(imgs['AO']))
    O['Boxer_Body'].hide_render = O['Boxer_Head'].hide_render = False
bpy.data.objects.remove(bake_skin); bpy.data.meshes.remove(tmpme)
import shutil
shutil.copy(os.path.join(ART, 'eye.png'), os.path.join(TEX, 'T_Boxer_Eyes_BaseColor.png'))
eye_img.filepath = os.path.join(TEX, 'T_Boxer_Eyes_BaseColor.png'); eye_img.reload()
# every final texture now references its PNG on disk (relative paths)
for img in bpy.data.images:
    if img.name.startswith('T_Boxer_'):
        path = os.path.join(TEX, img.name + '.png')
        if os.path.exists(path):
            img.source = 'FILE'; img.filepath = path; img.reload()
            img.colorspace_settings.name = 'sRGB' if img.name.endswith(('BaseColor',)) else 'Non-Color'

for key, (m, imgs) in MATS.items():
    nt = m.node_tree; nt.links.new(nt.nodes['Normal Map'].outputs[0], nt.nodes['Principled BSDF'].inputs['Normal'])
for m in bpy.data.materials:
    if m.node_tree and '_bake' in m.node_tree.nodes:
        m.node_tree.nodes.remove(m.node_tree.nodes['_bake'])
bpy.data.images.remove(trash)
for o in O:
    o.hide_render = o.name.startswith('HP_') or o.name.startswith('_')
bpy.context.view_layer.layer_collection.children['_HighPoly'].exclude = True
bpy.ops.file.make_paths_relative()
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)
print('saved')
