"""2D artwork used by the procedural source materials (projected decals) and the eye material."""
import os, sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = sys.argv[1]; os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(3)
FONT = '/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf'


# ---------------------------------------------------------------- face paint (front projection x[-0.1,0.1], z[1.5,1.7])
def face_paint(W=1024):
    im = Image.new('RGBA', (W, W), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    P = lambda x, z: ((x + 0.1) / 0.2 * W, (1 - (z - 1.5) / 0.2) * W)
    for s in (1, -1):
        # strong, slightly angled (determined) brows: thick inner end set low, arching up, tapering out
        top = [(0.011, 1.6405), (0.022, 1.6455), (0.034, 1.6475), (0.046, 1.6455), (0.053, 1.6420)]
        bot = [(0.054, 1.6400), (0.046, 1.6418), (0.034, 1.6425), (0.022, 1.6400), (0.011, 1.6345)]
        poly = [P(s * x, z) for x, z in top + bot]
        d.polygon(poly, fill=(14, 10, 8, 255))
        # hair strokes for texture along the brow
        for k in range(70):
            t = rng.uniform(0, 1); x = 0.011 + t * 0.042
            zc = np.interp(x, [0.011, 0.022, 0.034, 0.046, 0.053], [1.6375, 1.6428, 1.6450, 1.6437, 1.641])
            z = zc + rng.normal(0, 0.0018 * (1 - 0.5 * t))
            a = P(s * x, z); b = P(s * (x + 0.006), z + 0.0012 + rng.normal(0, 0.0005))
            d.line([a, b], fill=(10, 8, 6, 255), width=3)
        # upper lash line + soft lower lid shadow (follows the eye opening ellipse)
        cx, cz, rx, rz, tilt = 0.031, 1.614, 0.0150, 0.0074, math.radians(6)
        pts_u, pts_l = [], []
        for a in np.linspace(math.radians(195), math.radians(345), 24):
            ex, ez = rx * math.cos(a), -rz * math.sin(a)
            x = cx + ex * math.cos(tilt) - ez * math.sin(tilt); z = cz + ex * math.sin(tilt) + ez * math.cos(tilt)
            pts_u.append(P(s * x, z))
        for a in np.linspace(math.radians(20), math.radians(160), 18):
            ex, ez = rx * math.cos(a), -rz * math.sin(a)
            x = cx + ex * math.cos(tilt) - ez * math.sin(tilt); z = cz + ex * math.sin(tilt) + ez * math.cos(tilt)
            pts_l.append(P(s * x, z))
        d.line(pts_u, fill=(18, 12, 10, 240), width=9)
        d.line(pts_l, fill=(70, 40, 30, 110), width=5)
    # lips: muted warm brown-rose, darker mouth line
    lip = Image.new('RGBA', (W, W), (0, 0, 0, 0)); dl = ImageDraw.Draw(lip)
    for (x0, z0, x1, z1) in [(-0.0215, 1.5465, 0.0215, 1.5585), (-0.0190, 1.5345, 0.0190, 1.5470)]:
        a, b = P(x0, z1), P(x1, z0); dl.ellipse([a, b], fill=(125, 62, 52, 150))
    lip = lip.filter(ImageFilter.GaussianBlur(4))
    im = Image.alpha_composite(lip, im); d = ImageDraw.Draw(im)
    d.line([P(-0.020, 1.5468), P(0, 1.5462), P(0.020, 1.5468)], fill=(70, 32, 28, 200), width=4)
    im = im.filter(ImageFilter.GaussianBlur(0.7))
    im.save(f'{OUT}/face_paint.png')


# ---------------------------------------------------------------- Angkor Wat emblem (five towers, stepped base)
def angkor(W=1024):
    im = Image.new('RGBA', (W, W), (0, 0, 0, 0)); d = ImageDraw.Draw(im); C = (255, 255, 255, 255)
    def tower(cx, base_y, w, h):
        tiers = 6; y = base_y
        for i in range(tiers):
            tw = w * (1 - i / tiers * 0.82); th = h / tiers * (1.15 if i == 0 else 0.95)
            d.rounded_rectangle([cx - tw / 2, y - th, cx + tw / 2, y], radius=tw * 0.12, fill=C)
            y -= th * 0.82
        d.polygon([(cx - w * 0.08, y + 4), (cx, y - h * 0.16), (cx + w * 0.08, y + 4)], fill=C)
    base = W * 0.80
    for i, (w, h) in enumerate([(0.80, 0.045), (0.70, 0.045), (0.60, 0.045)]):     # stepped terraces
        y1 = base - i * h * W
        d.rectangle([W * (0.5 - w / 2), y1 - h * W, W * (0.5 + w / 2), y1], fill=C)
    top = base - 3 * 0.045 * W
    d.rectangle([W * 0.22, top - W * 0.06, W * 0.78, top], fill=C)                  # gallery
    for cx, w, h in [(0.27, 0.10, 0.20), (0.73, 0.10, 0.20), (0.385, 0.12, 0.27), (0.615, 0.12, 0.27), (0.5, 0.15, 0.36)]:
        tower(W * cx, top - W * 0.05, W * w, W * h)
    # cut-outs: gallery doors and terrace lines
    for cx in (0.30, 0.40, 0.5, 0.60, 0.70):
        d.rounded_rectangle([W * (cx - 0.018), top - W * 0.05, W * (cx + 0.018), top - W * 0.005], radius=8, fill=(0, 0, 0, 0))
    for i in range(1, 3):
        y = base - i * 0.045 * W
        d.line([(W * 0.2, y), (W * 0.8, y)], fill=(0, 0, 0, 0), width=5)
    d.rectangle([W * 0.46, base - W * 0.13, W * 0.54, base], fill=(0, 0, 0, 0))     # central stair
    im.save(f'{OUT}/angkor.png')


# ---------------------------------------------------------------- KHMER waistband label
def khmer_label(W=1200, H=400):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([6, 6, W - 6, H - 6], radius=26, fill=(14, 14, 16, 255), outline=(235, 235, 235, 255), width=14)
    f = ImageFont.truetype(FONT, 250)
    bb = d.textbbox((0, 0), 'KHMER', font=f); tw, th = bb[2] - bb[0], bb[3] - bb[1]
    d.text(((W - tw) / 2 - bb[0], (H - th) / 2 - bb[1]), 'KHMER', font=f, fill=(245, 245, 245, 255))
    im.save(f'{OUT}/khmer_label.png')


# ---------------------------------------------------------------- eye (sclera + iris), planar UV around the pupil
def eye(W=512):
    yy, xx = np.mgrid[0:W, 0:W] / (W - 1) - 0.5
    r = np.hypot(xx, yy); ang = np.arctan2(yy, xx)
    sclera = np.array([232, 224, 214], float)
    img = np.ones((W, W, 3)) * sclera
    img *= (1 - 0.18 * np.clip((r - 0.25) / 0.25, 0, 1))[..., None]                 # darker toward the corners
    vein = (np.sin(ang * 23) * np.sin(r * 90) > 0.93) & (r > 0.28)
    pass
    R = 0.205
    streak = 0.8 + 0.2 * np.sin(ang * 60 + 3 * np.sin(ang * 7))
    iris = np.array([62, 38, 24], float)[None, None, :] * streak[..., None] * (0.75 + 0.5 * np.clip(r / R, 0, 1))[..., None]
    m = r < R
    img[m] = iris[m]
    ring = (r > R * 0.86) & (r < R * 1.03); img[ring] *= 0.45                          # limbal ring
    img[r < R * 0.36] = [8, 6, 5]                                                       # pupil
    edge = np.clip((r - R) / 0.012, 0, 1)[..., None]
    img = img * (1 - 0) ; img = np.clip(img, 0, 255).astype(np.uint8)
    Image.fromarray(img).filter(ImageFilter.GaussianBlur(0.8)).save(f'{OUT}/eye.png')


face_paint(); angkor(); khmer_label(); eye()
# preview sheet
ims = [Image.open(f'{OUT}/{n}.png').convert('RGBA').resize((300, 300 if n != 'khmer_label' else 100)) for n in
       ('face_paint', 'angkor', 'khmer_label', 'eye')]
sheet = Image.new('RGBA', (1220, 310), (90, 90, 90, 255)); x = 5
for im in ims:
    sheet.alpha_composite(im, (x, 5)); x += 305
sheet.save(f'{OUT}/_preview.png')
