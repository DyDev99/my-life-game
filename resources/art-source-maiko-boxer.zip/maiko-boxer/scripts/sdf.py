"""Tiny signed-distance-field sculpting kit (numpy).
Conventions: Z up, character faces -Y, units = meters (1 BU = 1 m)."""
import numpy as np
from skimage import measure


def _clamp(x, a, b):
    return np.minimum(np.maximum(x, a), b)


def smin(a, b, k):
    if k <= 0:
        return np.minimum(a, b)
    h = _clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0)
    return b * (1 - h) + a * h - k * h * (1 - h)


def smax(a, b, k):
    return -smin(-a, -b, k)


def rot_matrix(rx=0, ry=0, rz=0):
    rx, ry, rz = np.radians([rx, ry, rz])
    cx, sx, cy, sy, cz, sz = np.cos(rx), np.sin(rx), np.cos(ry), np.sin(ry), np.cos(rz), np.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


class Prim:
    """fn(P[...,3]) -> distance, plus conservative bounding box."""
    def __init__(self, fn, lo, hi):
        self.fn, self.lo, self.hi = fn, np.array(lo, float), np.array(hi, float)


def ellipsoid(c, r, rot=(0, 0, 0)):
    c = np.array(c, float); r = np.array(r, float); R = rot_matrix(*rot)
    def fn(P):
        q = (P - c) @ R
        k0 = np.linalg.norm(q / r, axis=-1); k1 = np.linalg.norm(q / (r * r), axis=-1)
        return k0 * (k0 - 1.0) / np.maximum(k1, 1e-9)
    m = r.max()
    return Prim(fn, c - m, c + m)


def sphere(c, r):
    return ellipsoid(c, (r, r, r))


def cone(a, b, ra, rb):
    """Capsule with linearly varying radius."""
    a = np.array(a, float); b = np.array(b, float); ba = b - a; L2 = ba @ ba
    def fn(P):
        pa = P - a; h = _clamp((pa @ ba) / L2, 0, 1)
        return np.linalg.norm(pa - h[..., None] * ba, axis=-1) - (ra + (rb - ra) * h)
    m = max(ra, rb)
    return Prim(fn, np.minimum(a, b) - m, np.maximum(a, b) + m)


def chain(points, radii):
    return [cone(points[i], points[i + 1], radii[i], radii[i + 1]) for i in range(len(points) - 1)]


def rbox(c, half, rad, rot=(0, 0, 0)):
    c = np.array(c, float); half = np.array(half, float); R = rot_matrix(*rot)
    def fn(P):
        q = np.abs((P - c) @ R) - (half - rad)
        return np.linalg.norm(np.maximum(q, 0), axis=-1) + np.minimum(q.max(-1), 0) - rad
    m = np.linalg.norm(half)
    return Prim(fn, c - m, c + m)


def plane(n, d0):
    """Half-space n.p > d0 is inside (negative). Use with Field.inter for clipping."""
    n = np.array(n, float) / np.linalg.norm(n)
    return Prim(lambda P: d0 - P @ n, [-9] * 3, [9] * 3)


def mirror_x(p):
    def fn(P):
        Q = P.copy(); Q[..., 0] = -Q[..., 0]
        return p.fn(Q)
    lo, hi = p.lo.copy(), p.hi.copy(); lo[0], hi[0] = -p.hi[0], -p.lo[0]
    return Prim(fn, lo, hi)


class Field:
    def __init__(self, lo, hi, res):
        self.lo = np.array(lo, float); self.res = res
        self.n = np.ceil((np.array(hi) - self.lo) / res).astype(int) + 1
        self.d = np.full(tuple(self.n), 1.0, np.float32)
        print("field", self.n, f"{self.d.size / 1e6:.1f}M voxels")

    def _sl(self, lo, hi):
        i0 = np.clip(np.floor((lo - self.lo) / self.res).astype(int), 0, self.n)
        i1 = np.clip(np.ceil((hi - self.lo) / self.res).astype(int) + 1, 0, self.n)
        return tuple(slice(a, b) for a, b in zip(i0, i1)), i0, i1

    def _pts(self, i0, i1):
        ax = [self.lo[k] + self.res * np.arange(i0[k], i1[k]) for k in range(3)]
        X, Y, Z = np.meshgrid(*ax, indexing='ij')
        return np.stack([X, Y, Z], -1)

    def _apply(self, p, k, sym, op):
        for q in ([p, mirror_x(p)] if sym else [p]):
            m = max(1.6 * k, 0.05) + 4 * self.res
            sl, i0, i1 = self._sl(q.lo - m, q.hi + m)
            if any(b <= a for a, b in zip(i0, i1)):
                continue
            v = q.fn(self._pts(i0, i1)).astype(np.float32)
            self.d[sl] = smin(self.d[sl], v, k) if op == 'add' else smax(self.d[sl], -v, k)

    def add(self, p, k=0.0, sym=False):
        self._apply(p, k, sym, 'add')

    def sub(self, p, k=0.0, sym=False):
        self._apply(p, k, sym, 'sub')

    def clip(self, p, k=0.0):
        """Intersect whole field with primitive (e.g. clipping plane)."""
        P = self._pts(np.zeros(3, int), self.n)
        self.d = smax(self.d, p.fn(P).astype(np.float32), k)

    def displace(self, fn):
        """Bump detail: fn(P) -> offset added to distance (positive pushes inward)."""
        idx = np.nonzero(np.abs(self.d) < 4 * self.res)
        P = self.lo + self.res * np.stack(idx, -1)
        self.d[idx] += fn(P).astype(np.float32)

    def mesh(self):
        pad = np.pad(self.d, 1, constant_values=1.0)
        v, f, _, _ = measure.marching_cubes(pad, 0.0, spacing=(self.res,) * 3)
        v = v - self.res + self.lo
        a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
        if np.einsum('ij,ij->i', a, np.cross(b, c)).sum() < 0:      # orient outward (positive signed volume)
            f = f[:, ::-1]
        return v.astype(np.float32), f.astype(np.int32)
