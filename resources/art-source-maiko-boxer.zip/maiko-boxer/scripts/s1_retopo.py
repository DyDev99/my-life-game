"""Stage 1+2: high-poly sculpt -> quad game meshes (Boxer_Body, Boxer_Head incl. eyes)."""
import sys, os, math, time
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
from mathutils import Vector
import bx, anatomy as A

bpy.ops.wm.read_factory_settings(use_empty=True)
HP = bx.coll('_HighPoly')


from retopo import *


# ------------------------------------------------------------------ load high-poly
hp_body = bx.load_npz('HP_Body', f'{bx.WORK}/hp_body.npz', HP)
hp_head = bx.load_npz('HP_Head', f'{bx.WORK}/hp_head.npz', HP)
hp_hand_L = bx.load_npz('HP_Hand_L', f'{bx.WORK}/hp_hand.npz', HP)
d = np.load(f'{bx.WORK}/hp_hand.npz'); v = d['v'].copy(); v[:, 0] *= -1
hp_hand_R = bx.mesh_from_np('HP_Hand_R', v, d['f'][:, ::-1], HP)
for o in (hp_body, hp_head, hp_hand_L, hp_hand_R):
    bx.shade_smooth(o)

NECK_BODY, NECK_HEAD, WRIST_BODY, WRIST_HAND = 1.483, 1.493, 0.712, 0.722

# ------------------------------------------------------------------ remesh pieces
body = remesh('LP_Body', hp_body, 9200,
              [((0, 0, 1.515), (0, 0, 1), False), ((0.74, 0, 0), (1, 0, 0), False), ((-0.74, 0, 0), (-1, 0, 0), False)])
head = remesh('LP_Head', hp_head, 4300, [], voxel=0.0017)
hand = remesh('LP_Hand_L', hp_hand_L, 1000, [], voxel=0.0012)

# open the pieces on clean planes, inset from the caps
bm = bm_of(body)
neck_geom = [f for f in bm.faces if f.calc_center_median().z > 1.40 and abs(f.calc_center_median().x) < 0.16]
neck_geom = neck_geom + list({e for f in neck_geom for e in f.edges}) + list({v for f in neck_geom for v in f.verts})
bmesh.ops.bisect_plane(bm, geom=neck_geom, dist=1e-6, plane_co=(0, 0, NECK_BODY), plane_no=(0, 0, 1), clear_outer=True)
bmesh.ops.delete(bm, geom=[v for v in bm.verts if v.co.z > NECK_BODY + 1e-5 and abs(v.co.x) < 0.16], context='VERTS')
cut(bm, (WRIST_BODY, 0, 0), (1, 0, 0), False)
cut(bm, (-WRIST_BODY, 0, 0), (-1, 0, 0), False)
bmh = bm_of(head); cut(bmh, (0, 0, NECK_HEAD), (0, 0, 1), True)
face_region = [f for f in bmh.faces if f.calc_center_median().y < -0.03 and 1.495 < f.calc_center_median().z < 1.668]
fe = list({e for f in face_region for e in f.edges})
bmesh.ops.subdivide_edges(bmh, edges=fe, cuts=1, use_grid_fill=True, quad_corner_type='INNER_VERT')
print('face region faces subdivided:', len(face_region))
eye_region = [f for f in bmh.faces if (lambda c: c.y < -0.06 and 1.598 < c.z < 1.632 and 0.008 < abs(c.x) < 0.052)(f.calc_center_median())]
fe = list({e for f in eye_region for e in f.edges})
bmesh.ops.subdivide_edges(bmh, edges=fe, cuts=1, use_grid_fill=True, quad_corner_type='INNER_VERT')
print('eye region faces subdivided:', len(eye_region))
bmk = bm_of(hand); cut(bmk, (WRIST_HAND, 0, 0), (1, 0, 0), True)

# merge hands (L + mirrored R) into the body bmesh, then zip wrists
def append(dst, src, mirror=False):
    m = {}
    for vv in src.verts:
        co = vv.co.copy()
        if mirror:
            co.x = -co.x
        m[vv] = dst.verts.new(co)
    for f in src.faces:
        vs = [m[x] for x in f.verts]
        dst.faces.new(vs[::-1] if mirror else vs)
    return set(m.values())

hl = append(bm, bmk); hr = append(bm, bmk, mirror=True)
bm.verts.ensure_lookup_table()
loops = boundary_loops(bm)
print('border loops:', [(len(l), np.round(np.array([v.co[:] for v in l]).mean(0), 2).tolist()) for l in loops])
def pick(cond):
    return [l for l in loops if cond(np.array([v.co[:] for v in l]).mean(0))]
neck_b = pick(lambda c: c[2] > 1.4 and abs(c[0]) < 0.2)[0]
wl_b = [l for l in pick(lambda c: c[0] > 0.6) if l[0] not in hl][0]
wl_h = [l for l in pick(lambda c: c[0] > 0.6) if l[0] in hl][0]
wr_b = [l for l in pick(lambda c: c[0] < -0.6) if l[0] not in hr][0]
wr_h = [l for l in pick(lambda c: c[0] < -0.6) if l[0] in hr][0]
zipper(bm, wl_b, wl_h, 0); zipper(bm, wr_b, wr_h, 0)

# neck: copy head border into body and zip -> body owns the neck band, borders coincide exactly
head_loop = boundary_loops(bmh)[0]
copies = [bm.verts.new(v.co.copy()) for v in head_loop]
zipper(bm, neck_b, copies, 2)
bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
bmesh.ops.recalc_face_normals(bmh, faces=bmh.faces[:])

# light relax of the zipper bands to even out triangles
band = [v for v in bm.verts if (abs(v.co.z - (NECK_BODY + NECK_HEAD) / 2) < 0.02 and v.co.z < NECK_HEAD - 1e-5)
        or abs(abs(v.co.x) - (WRIST_BODY + WRIST_HAND) / 2) < 0.012]
bmesh.ops.smooth_vert(bm, verts=band, factor=0.4, use_axis_x=True, use_axis_y=True, use_axis_z=True)

for o, b in ((body, bm), (head, bmh)):
    b.to_mesh(o.data); b.free(); o.data.update()
bpy.data.objects.remove(hand)
bmk.free()

# ------------------------------------------------------------------ shrink back onto the sculpt (QuadriFlow drifts slightly)
def project(ob, target, exclude_z=None):
    vg = ob.vertex_groups.new(name='_proj')
    idx = [v.index for v in ob.data.vertices if not (exclude_z and exclude_z(v.co))]
    vg.add(idx, 1.0, 'REPLACE')
    m = ob.modifiers.new('sw', 'SHRINKWRAP'); m.target = target; m.wrap_method = 'NEAREST_SURFACEPOINT'
    m.vertex_group = '_proj'
    bx.apply_modifiers(ob); ob.vertex_groups.remove(ob.vertex_groups['_proj'])

project(body, hp_body, exclude_z=lambda c: c.z > NECK_BODY - 0.002 or abs(c.x) > WRIST_BODY - 0.002)
project(head, hp_head, exclude_z=lambda c: c.z < NECK_HEAD + 0.001)

# ------------------------------------------------------------------ eyes (front 60% of a sphere; back is hidden in the skull)
def eye(side):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=18, v_segments=12, radius=A.EYE_R)
    bmesh.ops.rotate(bm, verts=bm.verts, cent=(0, 0, 0), matrix=__import__('mathutils').Matrix.Rotation(math.radians(90), 3, 'X'))
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if v.co.y > A.EYE_R * 0.35], context='VERTS')
    bmesh.ops.translate(bm, verts=bm.verts, vec=(side * A.J['eye'][0], A.J['eye'][1], A.J['eye'][2]))
    return bm

for s in (1, -1):
    be = eye(s); m = {}
    for vv in be.verts:
        m[vv] = bmh_v = None
    me = bpy.data.meshes.new('tmp'); be.to_mesh(me); be.free()
    tmp = bpy.data.objects.new('tmp_eye', me); bpy.context.scene.collection.objects.link(tmp)
    tmp['eye_side'] = s
eyes = [o for o in bpy.data.objects if o.name.startswith('tmp_eye')]

# head gets two material slots later; mark eye faces via a face attribute after join
for o in eyes:
    a = o.data.attributes.new('is_eye', 'BOOLEAN', 'FACE'); a.data.foreach_set('value', [True] * len(o.data.polygons))
a = head.data.attributes.new('is_eye', 'BOOLEAN', 'FACE'); a.data.foreach_set('value', [False] * len(head.data.polygons))
bx.set_active(head)
for o in eyes:
    o.select_set(True)
with bpy.context.temp_override(active_object=head, selected_editable_objects=[head] + eyes):
    bpy.ops.object.join()

import fixes
print('eye verts opened', fixes.open_eyes(head))
body.name = body.data.name = 'Boxer_Body'
head.name = head.data.name = 'Boxer_Head'
for o in (body, head):
    bx.shade_smooth(o)
CH = bx.coll('Character')
bx.link(body, CH); bx.link(head, CH)
for o in (body, head):
    print(o.name, len(o.data.vertices), 'verts', bx.tri_count(o), 'tris',
          'ngons/tris:', sum(1 for p in o.data.polygons if len(p.vertices) != 4))
bpy.context.view_layer.layer_collection.children['_HighPoly'].exclude = True
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)

# inspection
bpy.context.view_layer.layer_collection.children['_HighPoly'].exclude = False
for o in HP.objects:
    o.hide_render = True
bpy.context.scene.display.shading.show_xray = False
p = bx.inspect_render(f'{bx.WORK}/s1.png', objs=[body, head], views=('front', 'side', 'back', 'q34'), res=380)
bx.montage(p, f'{bx.WORK}/insp_s1_body.png')
p = bx.inspect_render(f'{bx.WORK}/s1h.png', objs=[body, head], views=('front', 'q34', 'side'), res=380,
                      target=(0, -0.01, 1.6), ortho=0.30)
bx.montage(p, f'{bx.WORK}/insp_s1_head.png')
