"""Stage 9: Unity helper textures, final collection layout, preview scene (lights/cameras/floor/poses) + renders."""
import sys, os, math, glob
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
from mathutils import Vector
from PIL import Image, ImageDraw, ImageFont
import bx, anim as A

TEX = os.path.join(bx.ROOT, 'Textures'); PRE = os.path.join(bx.ROOT, 'Preview')
os.makedirs(os.path.join(TEX, 'Mobile_1024'), exist_ok=True); os.makedirs(PRE, exist_ok=True)

# ---------------------------------------------------------------- Unity helper maps + mobile set
for f in sorted(glob.glob(os.path.join(TEX, 'T_Boxer_*_Roughness.png'))):
    r = np.asarray(Image.open(f).convert('L'))
    ms = np.zeros(r.shape + (4,), np.uint8); ms[..., 3] = 255 - r          # R=metallic(0), A=smoothness
    Image.fromarray(ms, 'RGBA').save(f.replace('_Roughness', '_MetallicSmoothness'))
for f in sorted(glob.glob(os.path.join(TEX, 'T_Boxer_*.png'))):
    im = Image.open(f); s = max(256, min(1024, im.size[0] // 2))
    im.resize((s, s), Image.LANCZOS).save(os.path.join(TEX, 'Mobile_1024', os.path.basename(f)))
print('unity/mobile textures done')

bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
O = bpy.data.objects; sc = bpy.context.scene; arm = O['Boxer_Armature']

# ---------------------------------------------------------------- collection layout
top = bx.coll('Boxer_Character')
for n in ('Character', 'Rig', 'Animation', 'LOD', 'Export', 'Preview'):
    c = bx.coll(n)
    if c.name not in top.children:
        for p in [sc.collection] + list(bpy.data.collections):
            if c.name in p.children and p != top: p.children.unlink(c)
        top.children.link(c)
for o in [o for o in sc.collection.objects]:
    if o.name.startswith('_'): bpy.data.objects.remove(o)
# Animation collection: documentation empty listing the clips (actions themselves live in bpy.data.actions)
AN = bpy.data.collections['Animation']
doc = O.get('Boxer_Animation_Clips') or bpy.data.objects.new('Boxer_Animation_Clips', None)
if doc.name not in AN.objects: AN.objects.link(doc)
for a in bpy.data.actions:
    if a.name.startswith('Boxer_'): doc[a.name] = f'{int(a.frame_start)}-{int(a.frame_end)} @30fps'

# ---------------------------------------------------------------- preview scene
PV = bpy.data.collections['Preview']
for o in list(PV.objects): bpy.data.objects.remove(o)


def mat(name, col, rough):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name); m.use_nodes = True
    p = m.node_tree.nodes['Principled BSDF']; p.inputs['Base Color'].default_value = (*col, 1)
    p.inputs['Roughness'].default_value = rough; return m

# studio floor (large disc) - dark slate like the concept sheet; world provides the backdrop
bm = bmesh.new(); bmesh.ops.create_circle(bm, cap_ends=True, segments=64, radius=12.0)
me = bpy.data.meshes.new('Preview_Floor'); bm.to_mesh(me); bm.free()
floor = bpy.data.objects.new('Preview_Floor', me); PV.objects.link(floor)
me.materials.append(mat('MAT_Preview_Studio', (0.02, 0.022, 0.026), 0.6))


def light(name, loc, energy, size, color=(1, 1, 1)):
    l = bpy.data.objects.new(name, bpy.data.lights.new(name, 'AREA')); PV.objects.link(l)
    l.data.energy = energy; l.data.size = size; l.data.color = color; l.location = loc
    l.rotation_euler = (Vector((0, 0, 1.0)) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
light('Preview_Key', (-1.8, -2.4, 2.6), 260, 1.6, (1.0, 0.96, 0.9))
light('Preview_Fill', (2.2, -1.8, 1.3), 90, 2.0, (0.9, 0.95, 1.0))
light('Preview_Rim', (1.2, 2.2, 2.4), 320, 1.2)
light('Preview_RimL', (-1.4, 2.0, 1.8), 180, 1.0)
w = sc.world or bpy.data.worlds.new('World'); sc.world = w; w.use_nodes = True
w.node_tree.nodes['Background'].inputs[0].default_value = (0.045, 0.05, 0.062, 1)
w.node_tree.nodes['Background'].inputs[1].default_value = 0.6

CAMS = {'Cam_Front': ((0, -4.6, 1.0), (0, 0, 0.88), 50), 'Cam_Side': ((4.6, 0, 1.0), (0, 0, 0.88), 50),
        'Cam_Back': ((0, 4.6, 1.0), (0, 0, 0.88), 50), 'Cam_34': ((3.1, -3.4, 1.15), (0, 0, 0.88), 50),
        'Cam_Head': ((0.32, -0.62, 1.66), (0, 0, 1.6), 85), 'Cam_HeadFront': ((0, -0.75, 1.62), (0, 0, 1.6), 85)}
for n, (loc, tgt, lens) in CAMS.items():
    c = bpy.data.objects.new(n, bpy.data.cameras.new(n)); PV.objects.link(c)
    c.location = loc; c.data.lens = lens
    c.rotation_euler = (Vector(tgt) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()

# preview pose action: 1 T-pose, 2 neutral, 3 guard, 4 punch (+ timeline markers)
act = bpy.data.actions.get('Preview_Poses')
if act: bpy.data.actions.remove(act)
act = bpy.data.actions.new('Preview_Poses'); act.use_fake_user = True
arm.animation_data_create(); arm.animation_data.action = act
for f, (n, P) in enumerate([('T-Pose', {}), ('Neutral', A.NEUTRAL), ('Guard', A.GUARD), ('Punch', A.JAB)], start=1):
    A.apply(arm, P, frame=f)
    for fc_m in [m for m in sc.timeline_markers if m.frame == f]: sc.timeline_markers.remove(fc_m)
    sc.timeline_markers.new(n, frame=f)
for fc in []: pass
for layer in act.layers if hasattr(act, 'layers') else []:
    for strip in layer.strips:
        for cb in strip.channelbags:
            for fc in cb.fcurves:
                for k in fc.keyframe_points: k.interpolation = 'CONSTANT'
sc.frame_start, sc.frame_end = 1, 4

# show only the Character set (LOD sets hidden)
for c in bpy.data.collections['LOD'].children:
    for o in c.objects: o.hide_render = True; o.hide_viewport = True

# ---------------------------------------------------------------- renders
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = int(os.environ.get('SAMPLES', 28))
sc.cycles.use_denoising = True; sc.render.film_transparent = False
sc.view_settings.view_transform = 'AgX'; sc.view_settings.exposure = -0.2
try: sc.view_settings.look = 'AgX - Medium High Contrast'
except Exception: pass
FONT = '/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf'


def shot(cam, frame, path, rx=560, ry=760):
    sc.camera = O[cam]; sc.frame_set(frame); sc.render.resolution_x, sc.render.resolution_y = rx, ry
    sc.render.filepath = path; bpy.ops.render.render(write_still=True); return path


def sheet(items, out, title):
    ims = [(Image.open(p), lab) for p, lab in items]; w, h = ims[0][0].size
    S = Image.new('RGB', (w * len(ims), h + 70), (22, 24, 30)); d = ImageDraw.Draw(S)
    d.text((18, 14), title, font=ImageFont.truetype(FONT, 30), fill=(235, 235, 235))
    for i, (im, lab) in enumerate(ims):
        S.paste(im.convert('RGB'), (i * w, 70))
        d.text((i * w + 14, 70 + h - 40), lab, font=ImageFont.truetype(FONT, 22), fill=(230, 230, 230))
    S.save(out)
    for p, _ in items: os.remove(p)

tmp = os.path.join(bx.WORK, 'pv')
jobs = os.environ.get('JOBS', 'turn,poses,head,lod').split(',')
if 'turn' in jobs:
    sheet([(shot(c, 2, f'{tmp}_{c}.png'), l) for c, l in
           (('Cam_Front', 'FRONT'), ('Cam_Side', 'SIDE'), ('Cam_Back', 'BACK'), ('Cam_34', '3/4'))],
          os.path.join(PRE, 'Boxer_Turnaround.png'), 'KHMER BOXER  -  TURNAROUND (neutral pose)')
if 'poses' in jobs:
    sheet([(shot('Cam_34', f, f'{tmp}_p{f}.png'), l) for f, l in ((1, 'T-POSE'), (2, 'NEUTRAL'), (3, 'GUARD'), (4, 'PUNCH (JAB)'))],
          os.path.join(PRE, 'Boxer_Poses.png'), 'KHMER BOXER  -  POSES')
if 'head' in jobs:
    sheet([(shot(c, 2, f'{tmp}_{c}.png', 620, 620), l) for c, l in (('Cam_HeadFront', 'HEAD FRONT'), ('Cam_Head', 'HEAD 3/4'))],
          os.path.join(PRE, 'Boxer_Headshot.png'), 'KHMER BOXER  -  HEADSHOT')
if 'lod' in jobs:
    items = []
    CHO = list(bpy.data.collections['Character'].objects)
    for lod in (0, 1, 2):
        for o in CHO: o.hide_render = True
        for c in bpy.data.collections['LOD'].children:
            for o in c.objects: o.hide_render = (c.name != f'LOD{lod}')
        tris = sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in bpy.data.collections[f'LOD{lod}'].objects)
        items.append((shot('Cam_34', 2, f'{tmp}_lod{lod}.png'), f'LOD{lod}  {tris:,} tris'))
    for o in CHO: o.hide_render = False
    for c in bpy.data.collections['LOD'].children:
        for o in c.objects: o.hide_render = True
    sheet(items, os.path.join(PRE, 'Boxer_LODs.png'), 'KHMER BOXER  -  LOD COMPARISON')

arm.animation_data.action = None
for pb in arm.pose.bones:
    pb.rotation_quaternion = (1, 0, 0, 0); pb.location = (0, 0, 0)
for c in bpy.data.collections['LOD'].children:
    for o in c.objects: o.hide_viewport = False
sc.camera = O['Cam_34']; sc.frame_set(1)
bpy.ops.file.make_paths_relative()
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND, compress=True)
print('saved', f'{os.path.getsize(bx.BLEND) / 1e6:.1f} MB')
