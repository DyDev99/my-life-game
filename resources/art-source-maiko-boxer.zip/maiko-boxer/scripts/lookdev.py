"""Quick Cycles look-dev render of the game meshes with their baked materials."""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
import bpy
from mathutils import Vector
import bx
bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
O = bpy.data.objects; sc = bpy.context.scene
img = bpy.data.images.get('T_Boxer_Eyes_BaseColor')
print('eye image:', img and img.filepath, img and img.has_data)
if img and not os.path.exists(os.path.join(bx.ROOT, 'Textures', 'T_Boxer_Eyes_BaseColor.png')):
    img.filepath_raw = os.path.join(bx.ROOT, 'Textures', 'T_Boxer_Eyes_BaseColor.png'); img.file_format = 'PNG'; img.save()
    bpy.ops.wm.save_mainfile(); print('eye texture written')
sc.render.engine = 'CYCLES'; sc.cycles.samples = int(os.environ.get('SAMPLES', 24)); sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = int(os.environ.get('RX', 600)), int(os.environ.get('RY', 750))
w = sc.world; w.use_nodes = True; bg = w.node_tree.nodes['Background']; bg.inputs[0].default_value = (0.05, 0.055, 0.065, 1); bg.inputs[1].default_value = 1.0
def light(name, loc, energy, size=1.5):
    l = O.get(name) or bpy.data.objects.new(name, bpy.data.lights.new(name, 'AREA')); 
    if name not in sc.collection.objects: sc.collection.objects.link(l)
    l.data.energy = energy; l.data.size = size; l.location = loc
    l.rotation_euler = (Vector((0, 0, 1.1)) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
light('_Key', (-1.6, -2.2, 2.4), 450); light('_Fill', (2.0, -1.6, 1.4), 160); light('_Rim', (0.8, 2.4, 2.2), 380)
cam = bpy.data.objects.new('_LDCam', bpy.data.cameras.new('_LDCam')); sc.collection.objects.link(cam); sc.camera = cam
shots = os.environ.get('SHOTS', 'full_front,full_q34,head_front,head_q34').split(',')
spec = {'full_front': ((0, -4.2, 1.0), (0, 0, 0.9), 50), 'full_q34': ((2.9, -3.0, 1.2), (0, 0, 0.9), 50),
        'head_front': ((0, -0.75, 1.62), (0, 0, 1.6), 70), 'head_q34': ((0.5, -0.55, 1.65), (0, 0, 1.61), 70),
        'full_back': ((0, 4.2, 1.0), (0, 0, 0.9), 50), 'gear': ((1.4, -1.4, 0.7), (0.35, -0.05, 0.75), 50), 'eye_L': ((0.06, -0.25, 1.615), (0.031, -0.07, 1.614), 90), 'eye_R': ((-0.06, -0.25, 1.615), (-0.031, -0.07, 1.614), 90)}
out = []
for s in shots:
    loc, tgt, lens = spec[s]; cam.location = loc; cam.data.lens = lens
    cam.rotation_euler = (Vector(tgt) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    p = f'{bx.WORK}/ld_{s}.png'; sc.render.filepath = p; bpy.ops.render.render(write_still=True); out.append(p)
bx.montage(out, f'{bx.WORK}/lookdev.png')
