"""Retopology helpers (QuadriFlow pipeline, plane cuts, zipper)."""
import bpy, bmesh, time
import numpy as np
import bx


def bm_of(ob):
    bm = bmesh.new(); bm.from_mesh(ob.data); return bm


def cut(bm, co, no, keep_positive):
    """Bisect and remove one side. keep_positive keeps side along +no."""
    geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
    bmesh.ops.bisect_plane(bm, geom=geom, dist=1e-6, plane_co=co, plane_no=no,
                           clear_inner=keep_positive, clear_outer=not keep_positive)


def cap(bm):
    edges = [e for e in bm.edges if e.is_boundary]
    r = bmesh.ops.holes_fill(bm, edges=edges, sides=0)
    bmesh.ops.triangulate(bm, faces=r['faces'])


def decimate(ob, ratio):
    m = ob.modifiers.new('dec', 'DECIMATE'); m.ratio = ratio; bx.apply_modifiers(ob)


def remesh(name, src, faces, cuts_closed, seed=0, voxel=0.003):
    """Copy high-poly, cut+cap to a closed piece, decimate, QuadriFlow."""
    me = src.data.copy(); ob = bpy.data.objects.new(name, me); me = ob.data; bpy.context.scene.collection.objects.link(ob)
    bm = bm_of(ob)
    for co, no, keep in cuts_closed:
        cut(bm, co, no, keep)
    cap(bm); bm.to_mesh(me); bm.free()
    vx = ob.modifiers.new('vox', 'REMESH'); vx.mode = 'VOXEL'; vx.voxel_size = voxel; vx.use_smooth_shade = True
    bx.apply_modifiers(ob)
    decimate(ob, min(0.6, 150000 / len(ob.data.polygons)))   # also collapses voxel slivers
    bmc = bmesh.new(); bmc.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bmc, verts=bmc.verts, dist=0.00025)
    bmesh.ops.dissolve_degenerate(bmc, dist=0.00025, edges=bmc.edges)
    bmesh.ops.triangulate(bmc, faces=bmc.faces)
    bmesh.ops.delete(bmc, geom=[v for v in bmc.verts if not v.link_faces], context='VERTS')
    bmesh.ops.recalc_face_normals(bmc, faces=bmc.faces)
    bmc.to_mesh(ob.data); bmc.free()
    bmc = bmesh.new(); bmc.from_mesh(ob.data)
    print(name, 'input', len(bmc.faces), 'faces; non-manifold edges:', sum(1 for e in bmc.edges if not e.is_manifold),
          'verts:', sum(1 for v in bmc.verts if not v.is_manifold)); bmc.free()
    t = time.time()
    for s in (seed, seed + 1, seed + 2):
        r = bx.quadriflow(ob, faces, seed=s)
        if r == {'FINISHED'}:
            break
        print('quadriflow retry', name, r)
    print(f'{name}: {len(ob.data.polygons)} quads  {time.time() - t:.1f}s')
    return ob


def boundary_loops(bm):
    """Return list of ordered vertex loops along open borders."""
    bverts = {v for e in bm.edges if e.is_boundary for v in e.verts}
    loops, seen = [], set()
    for v0 in bverts:
        if v0 in seen:
            continue
        loop = [v0]; seen.add(v0); cur = v0; prev = None
        while True:
            nxt = [e.other_vert(cur) for e in cur.link_edges if e.is_boundary and e.other_vert(cur) is not prev]
            nxt = [n for n in nxt if n not in seen] or [n for n in nxt if n is v0]
            if not nxt or nxt[0] is v0:
                break
            prev, cur = cur, nxt[0]; loop.append(cur); seen.add(cur)
        loops.append(loop)
    return loops


def _orient(loop, axis):
    co = np.array([v.co[:] for v in loop]); c = co.mean(0)
    u, w = [k for k in range(3) if k != axis]
    area = np.sum((co[:, u] - c[u]) * np.roll(co[:, w] - c[w], -1) - np.roll(co[:, u] - c[u], -1) * (co[:, w] - c[w]))
    return loop if area > 0 else loop[::-1]


def _arclen(loop):
    co = np.array([v.co[:] for v in loop]); seg = np.linalg.norm(np.roll(co, -1, 0) - co, axis=1)
    t = np.concatenate([[0], np.cumsum(seg)]); return t / t[-1]


def zipper(bm, loopA, loopB, axis):
    """Triangle strip between two ordered closed loops of any vertex counts (arc-length merge)."""
    A_ = _orient(list(loopA), axis); B_ = _orient(list(loopB), axis)
    cb = np.array([v.co[:] for v in B_])
    j0 = int(np.argmin(np.linalg.norm(cb - np.array(A_[0].co[:]), axis=1)))
    B_ = B_[j0:] + B_[:j0]
    tA, tB = _arclen(A_), _arclen(B_); na, nb = len(A_), len(B_); i = j = 0; faces = []
    while i < na or j < nb:
        a0, a1 = A_[i % na], A_[(i + 1) % na]; b0, b1 = B_[j % nb], B_[(j + 1) % nb]
        if j >= nb or (i < na and tA[i + 1] <= tB[j + 1]):
            tri = (a0, a1, b0); i += 1
        else:
            tri = (a0, b1, b0); j += 1
        faces.append(bm.faces.new(tri))
    return faces


def fix_winding(bm, faces):
    """Make zipper faces agree with neighbours (recalc consistent normals)."""
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])


