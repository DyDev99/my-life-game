"""Pose/animation library. Rotations are authored as (armature-space axis, degrees) relative to the rest pose
for the LEFT side; right side is mirrored automatically (axis (x,y,z) -> (x,-y,-z)).
Character faces -Y. Left arm points +X. Signs (left arm): +Y = arm down, -Z = arm forward.
Lower arm flex forward: -Z. Spine lean forward: +X. Thigh forward: -X. Knee bend: +X."""
import math
from mathutils import Quaternion, Vector, Matrix


def _q(pb, axis, deg):
    ax = pb.bone.matrix_local.to_3x3().inverted() @ Vector(axis)
    return Quaternion(ax.normalized(), math.radians(deg))


def mirror_name(n):
    return n[:-2] + '_R' if n.endswith('_L') else (n[:-2] + '_L' if n.endswith('_R') else n)


def expand(pose, sym=True):
    """pose: {bone: [(axis, deg), ...] | {'rot': [...], 'loc': (x,y,z)}} -> full dict incl. mirrored side."""
    out = {}
    for b, spec in pose.items():
        if isinstance(spec, list): spec = {'rot': spec}
        out[b] = spec
        if sym and b.endswith('_L') and mirror_name(b) not in pose:
            out[mirror_name(b)] = {'rot': [((a[0], -a[1], -a[2]), d) for a, d in spec.get('rot', [])],
                                   'loc': spec.get('loc')}
    return out


def apply(arm, pose, frame=None, sym=True, reset=True):
    P = expand(pose, sym)
    for pb in arm.pose.bones:
        pb.rotation_mode = 'QUATERNION'
        if reset:
            pb.rotation_quaternion = (1, 0, 0, 0); pb.location = (0, 0, 0)
        if pb.name in P:
            q = Quaternion()
            for axis, deg in P[pb.name].get('rot', []):
                q = _q(pb, axis, deg) @ q
            pb.rotation_quaternion = q
            if P[pb.name].get('loc'):
                pb.location = pb.bone.matrix_local.to_3x3().inverted() @ Vector(P[pb.name]['loc'])
        if frame is not None:
            pb.keyframe_insert('rotation_quaternion', frame=frame, group=pb.name)
            if pb.name in ('root', 'pelvis'):
                pb.keyframe_insert('location', frame=frame, group=pb.name)


def merge(*poses):
    out = {}
    for p in poses:
        for b, s in p.items():
            s = {'rot': s} if isinstance(s, list) else dict(s)
            if b in out:
                out[b] = {'rot': out[b].get('rot', []) + s.get('rot', []), 'loc': s.get('loc') or out[b].get('loc')}
            else:
                out[b] = s
    return out


FIST = {f'{f}_0{i}_L': [((0, 0, 1), 0)] for f in ('index', 'middle', 'ring', 'pinky') for i in (1, 2, 3)}

NEUTRAL = {'upper_arm_L': [((0, 1, 0), 72), ((0, 0, 1), -8)], 'lower_arm_L': [((0, 0, 1), -12)],
           'clavicle_L': [((0, 1, 0), 6)]}

GUARD = {
    'pelvis': {'rot': [((0, 0, 1), -12)], 'loc': (0, 0, -0.045)},
    'spine_01': [((1, 0, 0), 4)], 'spine_02': [((1, 0, 0), 5)], 'chest': [((1, 0, 0), 4), ((0, 0, 1), 2)],
    'neck': [((1, 0, 0), 4), ((0, 0, 1), 10)], 'head': [((1, 0, 0), 6), ((0, 0, 1), 8)],
    'clavicle_L': [((0, 1, 0), 4), ((0, 0, 1), -8)],
    'upper_arm_L': [((0, 1, 0), 62), ((0, 0, 1), -52)], 'lower_arm_L': [((0, 0, 1), -128)],
    'hand_L': [((1, 0, 0), -10)],
    'upper_arm_R': [((0, -1, 0), 70), ((0, 0, -1), -32)], 'lower_arm_R': [((0, 0, -1), -140)],
    'hand_R': [((1, 0, 0), -10)],
    'thigh_L': [((1, 0, 0), -24), ((0, 1, 0), 4)], 'calf_L': [((1, 0, 0), 26)], 'foot_L': [((1, 0, 0), -4), ((0, 0, 1), 18)],
    'thigh_R': [((1, 0, 0), 10), ((0, 1, 0), -8)], 'calf_R': [((1, 0, 0), 24)], 'foot_R': [((1, 0, 0), -14), ((0, 0, 1), 18)],
}

def override(base, changes):
    out = dict(base); out.update(changes); return out


JAB = override(GUARD, {
    'pelvis': {'rot': [((0, 0, 1), -8)], 'loc': (0, -0.03, -0.045)},
    'chest': [((1, 0, 0), 4), ((0, 0, 1), -10)], 'spine_02': [((1, 0, 0), 5), ((0, 0, 1), -4)],
    'clavicle_L': [((0, 0, 1), -14)],
    'upper_arm_L': [((0, 1, 0), 6), ((0, 0, 1), -70)], 'lower_arm_L': [((0, 0, 1), -6)], 'hand_L': [],
})
CROUCH = {
    'pelvis': {'rot': [((1, 0, 0), 10)], 'loc': (0, 0.06, -0.33)},
    'spine_01': [((1, 0, 0), 12)], 'spine_02': [((1, 0, 0), 10)], 'chest': [((1, 0, 0), 6)], 'head': [((1, 0, 0), -18)],
    'upper_arm_L': [((0, 1, 0), 62), ((0, 0, 1), -52)], 'lower_arm_L': [((0, 0, 1), -128)],
    'thigh_L': [((1, 0, 0), -95), ((0, 1, 0), 6)], 'calf_L': [((1, 0, 0), 120)], 'foot_L': [((1, 0, 0), -35)],
}
RAISE = {
    'upper_arm_L': [((0, 1, 0), -55), ((0, 0, 1), -10)], 'lower_arm_L': [((0, 0, 1), -35)],
    'clavicle_L': [((0, 1, 0), -12)], 'chest': [((1, 0, 0), -6)], 'head': [((1, 0, 0), -12)],
}


def mirror(pose):
    """Swap left/right (for alternating cycles and opposite-hand punches)."""
    out = {}
    for b, spec in pose.items():
        spec = {'rot': spec} if isinstance(spec, list) else spec
        loc = spec.get('loc')
        out[mirror_name(b)] = {'rot': [((a[0], -a[1], -a[2]), d) for a, d in spec.get('rot', [])],
                               'loc': (-loc[0], loc[1], loc[2]) if loc else None}
    return out


def lr(pose_left):
    """Pose given for left side only, NOT auto-mirrored (asymmetric pose): explicit right = rest."""
    return pose_left
