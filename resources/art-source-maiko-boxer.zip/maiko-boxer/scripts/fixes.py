"""Post-retopo fixes."""
import numpy as np
from mathutils import Vector
import anatomy as A
from sdf import rot_matrix


def open_eyes(head, rx=0.0145, rz=0.0072, inside=0.0006):
    """Skin verts inside the almond eye opening -> pushed onto a sphere just inside the eyeball,
    so QuadriFlow can never leave a skin sheet across the eye. Lid rim (ellipse ~1) is untouched."""
    me = head.data; eye = [bool(a.value) for a in me.attributes['is_eye'].data]
    skin_v = {v for p in me.polygons if not eye[p.index] for v in p.vertices}
    ex, ey, ez = A.J['eye']; moved = 0
    for s in (1, -1):
        c = np.array([s * ex, ey, ez]); R = rot_matrix(0, 6 * s, 0)
        open_c = np.array([s * 0.031, -0.088, 1.614])
        for i in skin_v:
            co = np.array(me.vertices[i].co[:])
            q = (co - open_c) @ R
            e = (q[0] / rx) ** 2 + (q[2] / rz) ** 2
            if e < 1.06 and np.linalg.norm(co - c) < A.EYE_R + 0.006 and co[1] > -0.095:
                d = co - c; d /= np.linalg.norm(d)
                w = min(1.0, (1.06 - e) / 0.12)          # ease toward the rim
                tgt = c + d * (A.EYE_R - inside)
                me.vertices[i].co = Vector(co * (1 - w) + tgt * w); moved += 1
    me.update(); return moved
