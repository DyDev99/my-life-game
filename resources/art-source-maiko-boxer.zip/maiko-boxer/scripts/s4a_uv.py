"""Stage 4a: UV unwrapping. Skin = body+head share one atlas (head/face weighted ~3x texel density)."""
import sys, os, math, heapq
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
from mathutils import Vector, Matrix
import bx, anatomy as A
from PIL import Image, ImageDraw

bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
O = bpy.data.objects
body, head = O['Boxer_Body'], O['Boxer_Head']


def edit(objs, fn):
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    for o in objs:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        fn()
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')


def select_faces(ob, pred):
    bm = bmesh.from_edit_mesh(ob.data)
    eye = bm.faces.layers.bool.get('is_eye')
    for f in bm.faces:
        f.select_set(bool(pred(f, eye)))
    bmesh.update_edit_mesh(ob.data)


# ---- head seam: back midline from crown to neck (Dijkstra, penalise distance from x=0), skip eyes
bm = bmesh.new(); bm.from_mesh(head.data); bm.verts.ensure_lookup_table()
eye = bm.faces.layers.bool.get('is_eye')
skin_v = {v for f in bm.faces if not f[eye] for v in f.verts}
start = max((v for v in skin_v if abs(v.co.x) < 0.01), key=lambda v: v.co.z + 2 * v.co.y)        # crown, slightly back
end = max((v for v in skin_v if v.is_boundary), key=lambda v: v.co.y - 4 * abs(v.co.x))          # neck back
dist = {start: 0}; prev = {}; pq = [(0, id(start), start)]
while pq:
    d0, _, v = heapq.heappop(pq)
    if v is end: break
    if d0 > dist.get(v, 1e9): continue
    for e in v.link_edges:
        w = e.other_vert(v)
        if w not in skin_v or w.co.y < -0.02: continue
        c = d0 + e.calc_length() * (1 + 400 * abs(w.co.x))
        if c < dist.get(w, 1e9):
            dist[w] = c; prev[w] = (v, e); heapq.heappush(pq, (c, id(w), w))
v = end; n = 0
while v is not start:
    v, e = prev[v]; e.seam = True; n += 1
# ear cut: short seam around back of each ear helps flatten
print('head seam edges', n)
# face / scalp split: seam where front faces meet the rest
front = lambda f: f.calc_center_median().y < -0.03 and not f[eye]
for e in bm.edges:
    fs = [f for f in e.link_faces if not f[eye]]
    if len(fs) == 2 and front(fs[0]) != front(fs[1]):
        e.seam = True
bm.to_mesh(head.data); bm.free()

# ---- body: smart project ; head: angle-based unwrap with the seam
def region(f):
    c = f.calc_center_median()
    return 0 if abs(c.x) > 0.20 else (1 if c.z < 0.86 else 2)          # arms / legs / torso
for r in (0, 1, 2):
    edit([body], lambda: (select_faces(body, lambda f, e: region(f) == r),
                          bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.002, area_weight=0.0)))
edit([head], lambda: (select_faces(head, lambda f, e: not f[e]),
                      bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.002)))


def pack_skin():
    select_faces(body, lambda f, e: True); select_faces(head, lambda f, e: not f[e])
    bpy.ops.uv.select_all(action='SELECT')
    bpy.ops.uv.average_islands_scale()
    bm = bmesh.from_edit_mesh(head.data); uv = bm.loops.layers.uv.active; e = bm.faces.layers.bool.get('is_eye')
    for f in bm.faces:
        if not f[e]:
            k = 3.4 if f.calc_center_median().y < -0.03 else 2.4     # face gets the most texels
            for l in f.loops:
                l[uv].uv *= k
    bmesh.update_edit_mesh(head.data)
    bpy.ops.uv.pack_islands(rotate=True, margin=0.0025, shape_method='CONCAVE')
edit([body, head], pack_skin)

# ---- eyes: planar front projection into their own 0..1 space (MAT_Eyes)
bm = bmesh.new(); bm.from_mesh(head.data); uv = bm.loops.layers.uv.active; e = bm.faces.layers.bool.get('is_eye')
ex, ey, ez = A.J['eye']
for f in bm.faces:
    if f[e]:
        for l in f.loops:
            c = l.vert.co; cx = ex if c.x > 0 else -ex
            l[uv].uv = (0.5 + (c.x - cx) / (2.4 * A.EYE_R), 0.5 + (c.z - ez) / (2.4 * A.EYE_R))
bm.to_mesh(head.data); bm.free()

# ---- gear: smart project + pack each
for n in ('Boxer_Gloves_L', 'Boxer_Boot_L', 'Boxer_Shorts', 'Boxer_Headband', 'Boxer_Hair'):
    ob = O[n]
    if not ob.data.uv_layers:
        ob.data.uv_layers.new(name='UVMap')
    edit([ob], lambda: (select_faces(ob, lambda f, e: True),
                        bpy.ops.uv.smart_project(angle_limit=math.radians(60), island_margin=0.003, area_weight=0.0),
                        bpy.ops.uv.select_all(action='SELECT'),
                        bpy.ops.uv.pack_islands(rotate=True, margin=0.004, shape_method='CONCAVE')))

# ---- rebuild right-side copies from the unwrapped left pieces (mirror keeps per-corner UVs)
CH = bpy.data.collections['Character']
for L, R in (('Boxer_Gloves_L', 'Boxer_Gloves_R'), ('Boxer_Boot_L', 'Boxer_Boot_R')):
    bpy.data.objects.remove(O[R])
    me = O[L].data.copy(); me.name = R
    me.transform(Matrix.Scale(-1, 4, (1, 0, 0))); me.flip_normals()
    o = bpy.data.objects.new(R, me); CH.objects.link(o)
for o in CH.objects:
    o.data.uv_layers[0].name = 'UVMap'
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)


# ---- QC: draw UV layouts
def draw(objs, path, pred=lambda f, e: True, W=1024):
    im = Image.new('RGB', (W, W), (25, 25, 30)); d = ImageDraw.Draw(im); used = 0.0
    for ob, col in objs:
        me = ob.data; uvl = me.uv_layers[0].data; e = me.attributes.get('is_eye')
        for p in me.polygons:
            if e is not None and e.data[p.index].value: continue
            pts = [(uvl[i].uv.x * W, (1 - uvl[i].uv.y) * W) for i in p.loop_indices]
            d.polygon(pts, outline=col)
            a = 0.5 * abs(sum(pts[i][0] * pts[i - 1][1] - pts[i - 1][0] * pts[i][1] for i in range(len(pts))))
            used += a / (W * W)
    im.save(path); return used
u = draw([(body, (90, 200, 255)), (head, (255, 180, 80))], f'{bx.WORK}/uv_skin.png')
print(f'skin atlas coverage {u:.2f}')
for n in ('Boxer_Gloves_L', 'Boxer_Boot_L', 'Boxer_Shorts', 'Boxer_Headband', 'Boxer_Hair'):
    print(n, f'coverage {draw([(O[n], (120, 255, 140))], f"{bx.WORK}/uv_{n}.png"):.2f}')
