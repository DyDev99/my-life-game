"""Khmer Boxer - anatomy. One source of truth for sculpt + rig.
Height 1.72 m, T-pose, faces -Y, character's LEFT side is +X."""
import numpy as np
from sdf import Field, ellipsoid, sphere, cone, rbox, plane

HEIGHT = 1.72
ARM_Z = 1.425

# ---- joint landmarks (left side; right side = mirrored X) ----
J = {
    'root': (0, 0, 0),
    'pelvis': (0, 0.0, 0.95), 'spine_01': (0, 0.005, 1.03), 'spine_02': (0, 0.01, 1.14),
    'chest': (0, 0.012, 1.26), 'neck': (0, 0.012, 1.45), 'head': (0, 0.004, 1.545),
    'head_end': (0, 0.004, 1.72),
    'clavicle': (0.02, -0.005, 1.435), 'shoulder': (0.182, 0.01, ARM_Z),
    'elbow': (0.465, 0.015, ARM_Z), 'wrist': (0.725, 0.0, ARM_Z), 'knuckle': (0.835, 0.0, 1.42),
    'hip': (0.094, 0.0, 0.92), 'knee': (0.098, -0.012, 0.49), 'ankle': (0.10, 0.025, 0.085),
    'ball': (0.105, -0.10, 0.022), 'toe_end': (0.108, -0.175, 0.022),
    'eye': (0.031, -0.0712, 1.614),
}
EYE_R = 0.0118

# finger name -> (y offset at knuckle, length scale, radius)
FINGERS = {'index': (-0.030, 0.95, 0.0084), 'middle': (-0.0095, 1.0, 0.0086),
           'ring': (0.0115, 0.95, 0.0080), 'pinky': (0.031, 0.78, 0.0070)}
SEG_LEN = (0.046, 0.028, 0.022)
CURL = (35, 45, 25)      # degrees per joint, curling toward -Z (palm down) -> fits inside glove


def finger_points(name):
    yo, s, r = FINGERS[name]
    x0 = J['knuckle'][0] - (0.004 if name in ('index', 'pinky') else 0) - (0.006 if name == 'pinky' else 0)
    p = np.array([x0, yo, 1.42 - (0.003 if name == 'pinky' else 0)])
    pts = [p.copy()]; ang = 0
    for L, c in zip(SEG_LEN, CURL):
        ang += np.radians(c)
        p = p + s * L * np.array([np.cos(ang), 0, -np.sin(ang)])
        pts.append(p.copy())
    return pts, r


THUMB = [(0.752, -0.028, 1.412), (0.783, -0.050, 1.403), (0.805, -0.058, 1.398), (0.822, -0.060, 1.393)]


def neck_prims(F):
    """Shared by body and head sculpts so the neck seam matches exactly."""
    F.add(cone((0, 0.014, 1.40), (0, 0.002, 1.57), 0.060, 0.053), 0.025)                        # neck
    F.add(cone((0.050, 0.012, 1.58), (0.016, -0.036, 1.43), 0.014, 0.012), 0.02, sym=True)      # SCM
    F.add(cone((0.04, 0.035, 1.452), (0.17, 0.02, 1.44), 0.032, 0.030), 0.035, sym=True)         # traps


# ---------------------------------------------------------------- body
def build_body(res=0.0035, lo=(-0.78, -0.21, -0.004), hi=(0.78, 0.17, 1.52)):
    F = Field(lo, hi, res)
    a = F.add
    # torso
    a(ellipsoid((0, 0.014, 1.32), (0.128, 0.088, 0.16)))
    a(ellipsoid((0, 0.014, 1.22), (0.118, 0.084, 0.10)), 0.05)                                   # lower ribs
    a(cone((0.022, -0.040, 1.328), (0.125, -0.022, 1.362), 0.045, 0.038), 0.028, sym=True)  # pecs
    a(ellipsoid((0.100, 0.030, 1.31), (0.052, 0.046, 0.10)), 0.045, sym=True)                    # lats
    a(ellipsoid((0, 0.045, 1.36), (0.115, 0.05, 0.09)), 0.06)                                    # upper back
    a(ellipsoid((0, -0.002, 1.10), (0.116, 0.080, 0.15)), 0.06)                                  # abdomen
    a(ellipsoid((0.094, 0.004, 1.04), (0.044, 0.064, 0.10)), 0.05, sym=True)                     # obliques
    a(ellipsoid((0, 0.006, 0.94), (0.120, 0.092, 0.10)), 0.05)                                   # pelvis
    a(ellipsoid((0.062, 0.050, 0.885), (0.068, 0.058, 0.075)), 0.03, sym=True)                   # glutes
    neck_prims(F)
    # arms
    a(ellipsoid((0.19, 0.006, 1.412), (0.082, 0.054, 0.054)), 0.05, sym=True)                    # deltoid
    a(cone(J['shoulder'], J['elbow'], 0.050, 0.039), 0.03, sym=True)
    a(ellipsoid((0.33, -0.020, 1.428), (0.085, 0.036, 0.039)), 0.025, sym=True)                  # biceps
    a(ellipsoid((0.31, 0.027, 1.425), (0.095, 0.033, 0.035)), 0.02, sym=True)                    # triceps
    a(sphere((0.465, 0.02, ARM_Z), 0.034), 0.02, sym=True)                                       # elbow
    a(cone(J['elbow'], (0.76, 0.0, ARM_Z), 0.039, 0.026), 0.02, sym=True)
    a(ellipsoid((0.54, 0.0, 1.43), (0.09, 0.037, 0.035)), 0.03, sym=True)                        # forearm mass
    # legs
    a(cone(J['hip'], J['knee'], 0.071, 0.050), 0.045, sym=True)
    a(ellipsoid((0.104, -0.027, 0.70), (0.062, 0.056, 0.17)), 0.03, sym=True)                    # quads
    a(ellipsoid((0.076, -0.03, 0.565), (0.04, 0.04, 0.06)), 0.02, sym=True)                      # vastus med.
    a(ellipsoid((0.126, 0.0, 0.72), (0.034, 0.048, 0.13)), 0.03, sym=True)                       # outer thigh
    a(ellipsoid((0.10, 0.034, 0.71), (0.063, 0.054, 0.15)), 0.03, sym=True)                      # hamstrings
    a(ellipsoid((0.098, -0.02, 0.48), (0.044, 0.044, 0.05)), 0.02, sym=True)                     # knee
    a(cone(J['knee'], J['ankle'], 0.049, 0.029), 0.02, sym=True)
    a(ellipsoid((0.104, 0.026, 0.37), (0.048, 0.048, 0.10)), 0.03, sym=True)                     # calf lat
    a(ellipsoid((0.086, 0.02, 0.36), (0.034, 0.044, 0.08)), 0.02, sym=True)                      # calf med
    a(sphere(J['ankle'], 0.034), 0.02, sym=True)
    a(ellipsoid((0.103, -0.04, 0.042), (0.044, 0.11, 0.036)), 0.02, sym=True)                    # foot
    a(ellipsoid((0.108, -0.13, 0.026), (0.045, 0.05, 0.022)), 0.02, sym=True)                    # toes
    # detail: abs, navel, sternum, spine groove
    F.sub(ellipsoid((0, -0.094, 1.115), (0.004, 0.012, 0.11)), 0.01)
    for z in (1.165, 1.095, 1.03):
        F.sub(ellipsoid((0, -0.093, z), (0.05, 0.008, 0.0035)), 0.012)
    F.sub(sphere((0, -0.088, 1.005), 0.006), 0.004)
    F.sub(ellipsoid((0, -0.086, 1.31), (0.005, 0.010, 0.05)), 0.016)
    F.sub(ellipsoid((0, 0.118, 1.21), (0.007, 0.016, 0.15)), 0.02)
    F.clip(plane((0, 0, 1), 0.0))   # flat soles
    return F


# ---------------------------------------------------------------- head
def build_head(res=0.0012):
    """Facial thirds: hairline 1.70 / brow 1.635 / nose base 1.57 / chin 1.505. Eye line 1.614."""
    F = Field((-0.10, -0.13, 1.40), (0.10, 0.125, 1.74), res)
    a = F.add
    a(ellipsoid((0, 0.012, 1.627), (0.0765, 0.091, 0.094)))                                     # cranium
    a(ellipsoid((0, -0.034, 1.648), (0.066, 0.058, 0.066)), 0.02)                                # forehead
    a(ellipsoid((0, -0.038, 1.590), (0.062, 0.062, 0.062)), 0.02)                                # mid face
    a(ellipsoid((0, -0.028, 1.552), (0.054, 0.060, 0.040)), 0.025)                               # jaw mass
    a(sphere((0.052, 0.002, 1.553), 0.0125), 0.016, sym=True)                                    # jaw angle
    a(ellipsoid((0, -0.079, 1.521), (0.021, 0.016, 0.015)), 0.014)                               # chin
    a(ellipsoid((0.050, -0.058, 1.601), (0.022, 0.018, 0.013)), 0.02, sym=True)                  # cheekbones
    a(ellipsoid((0.042, -0.056, 1.585), (0.027, 0.027, 0.021)), 0.022, sym=True)                 # cheeks
    a(ellipsoid((0, -0.071, 1.550), (0.031, 0.028, 0.026)), 0.02)                                # muzzle
    neck_prims(F)
    a(ellipsoid((0.033, -0.075, 1.637), (0.030, 0.010, 0.010), rot=(0, 6, 0)), 0.018, sym=True)  # brow
    a(cone((0, -0.084, 1.626), (0, -0.102, 1.589), 0.0070, 0.0092), 0.010)                      # nose bridge
    a(sphere((0, -0.103, 1.581), 0.0118), 0.008)                                                 # nose tip
    a(sphere((0.0152, -0.092, 1.575), 0.0093), 0.008, sym=True)                                  # alae
    F.sub(ellipsoid((0.0083, -0.098, 1.5685), (0.0044, 0.0055, 0.003)), 0.002, sym=True)         # nostrils
    a(ellipsoid((0, -0.0950, 1.5525), (0.0215, 0.0085, 0.0055), rot=(-15, 0, 0)), 0.004)         # upper lip
    a(ellipsoid((0, -0.0922, 1.5415), (0.0185, 0.0085, 0.0060), rot=(15, 0, 0)), 0.004)          # lower lip
    F.sub(ellipsoid((0, -0.103, 1.5468), (0.022, 0.012, 0.0009)), 0.001)                         # mouth line
    a(ellipsoid((0.077, 0.012, 1.6025), (0.009, 0.019, 0.032), rot=(-8, 0, -12)), 0.006, sym=True)  # ears
    F.sub(ellipsoid((0.087, 0.006, 1.599), (0.007, 0.011, 0.015)), 0.003, sym=True)              # concha
    F.sub(ellipsoid((0.031, -0.088, 1.614), (0.0145, 0.012, 0.0072), rot=(0, 6, 0)), 0.002)      # eye L
    F.sub(ellipsoid((-0.031, -0.088, 1.614), (0.0145, 0.012, 0.0072), rot=(0, -6, 0)), 0.002)    # eye R
    a(ellipsoid((0.031, -0.0855, 1.622), (0.0142, 0.004, 0.0022), rot=(0, 6, 0)), 0.003, sym=True)  # upper lid
    F.clip(plane((0, 0, 1), 1.41))
    return F


# ---------------------------------------------------------------- hand (left; mirror for right)
def build_hand(res=0.0013):
    F = Field((0.68, -0.09, 1.33), (0.90, 0.06, 1.46), res)
    a = F.add
    a(cone((0.68, 0.0, ARM_Z), (0.735, 0.0, ARM_Z), 0.030, 0.026))
    a(ellipsoid(J['wrist'], (0.02, 0.03, 0.017)), 0.01)
    a(rbox((0.79, 0.0, 1.418), (0.047, 0.042, 0.0155), 0.014), 0.014)                           # palm
    a(ellipsoid((0.765, -0.030, 1.410), (0.03, 0.018, 0.015)), 0.01)                             # thenar
    for n in FINGERS:
        pts, r = finger_points(n)
        for i in range(3):
            a(cone(pts[i], pts[i + 1], r * (1 - 0.08 * i), r * (1 - 0.08 * (i + 1))), 0.004 if i else 0.008)
    for i in range(3):
        a(cone(THUMB[i], THUMB[i + 1], 0.0125 - 0.0015 * i, 0.011 - 0.0015 * i), 0.006)
    F.clip(plane((1, 0, 0), 0.69))
    return F


if __name__ == '__main__':
    import time, sys
    out = sys.argv[1]
    for name, fn in [('body', build_body), ('head', build_head), ('hand', build_hand)]:
        t = time.time(); F = fn(); v, f = F.mesh()
        np.savez(f'{out}/hp_{name}.npz', v=v, f=f)
        print(name, len(v), 'verts', len(f), 'tris', f'{time.time() - t:.1f}s')
