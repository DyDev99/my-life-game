"""Stage 7+8: LOD0/1/2 (hidden geometry removed, decimated), Unity FBX exports + verification by re-import."""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
import bpy, bmesh
import numpy as np
import bx

bpy.ops.wm.open_mainfile(filepath=bx.BLEND)
O = bpy.data.objects; sc = bpy.context.scene
arm = O['Boxer_Armature']; arm.animation_data.action = None
if 'Preview_Poses' in bpy.data.actions:          # preview-only helper; s9 recreates it. Keep it out of the FBX.
    bpy.data.actions.remove(bpy.data.actions['Preview_Poses'])
for pb in arm.pose.bones:
    pb.rotation_quaternion = (1, 0, 0, 0); pb.location = (0, 0, 0)
EXP = os.path.join(bx.ROOT, 'Export'); os.makedirs(EXP, exist_ok=True)
LODC = bx.coll('LOD')
for c in list(LODC.children):
    for o in list(c.objects): bpy.data.objects.remove(o)
    bpy.data.collections.remove(c)

PARTS = {  # unity name -> source objects
    'Body': ['Boxer_Body'], 'Head': ['Boxer_Head'], 'Hair': ['Boxer_Hair'], 'Headband': ['Boxer_Headband'],
    'Gloves': ['Boxer_Gloves_L', 'Boxer_Gloves_R'], 'Shorts': ['Boxer_Shorts'], 'Boots': ['Boxer_Boot_L', 'Boxer_Boot_R'],
}
TARGET = {0: 45000, 1: 16500, 2: 7800}


def copy_join(names, newname, coll):
    objs = []
    for n in names:
        o = O[n].copy(); o.data = O[n].data.copy(); coll.objects.link(o); objs.append(o)
    if len(objs) > 1:
        with bpy.context.temp_override(active_object=objs[0], selected_editable_objects=objs):
            bpy.ops.object.join()
    o = objs[0]; o.name = o.data.name = newname
    return o


def delete_faces(o, pred):
    bm = bmesh.new(); bm.from_mesh(o.data)
    dead = [f for f in bm.faces if pred(f)]
    bmesh.ops.delete(bm, geom=dead, context='FACES')
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context='VERTS')
    bm.to_mesh(o.data); bm.free(); return len(dead)


def all_v(f, cond):
    return all(cond(v.co) for v in f.verts)


def strip_material(o, mat_name):
    idx = [i for i, m in enumerate(o.data.materials) if m and m.name == mat_name]
    if not idx: return
    delete_faces(o, lambda f: f.material_index in idx)
    o.data.materials.pop(index=idx[0])


def tris(o): return sum(len(p.vertices) - 2 for p in o.data.polygons)


LODS = {}
for lod in (0, 1, 2):
    C = bx.coll(f'LOD{lod}', LODC)
    objs = {k: copy_join(v, f'Boxer_{k}_LOD{lod}', C) for k, v in PARTS.items()}
    # hidden geometry (character always wears this outfit)
    n = delete_faces(objs['Body'], lambda f: all_v(f, lambda c: 0.700 < c.z < 1.012 and abs(c.x) < 0.25))
    n += delete_faces(objs['Body'], lambda f: all_v(f, lambda c: c.z < 0.250))
    if lod >= 1:
        n += delete_faces(objs['Body'], lambda f: all_v(f, lambda c: abs(c.x) > 0.705))     # hands inside gloves
        strip_material(objs['Boots'], 'MAT_MetalDetails')
    print(f'LOD{lod}: removed {n} hidden body faces')
    for o in objs.values():          # n-gons -> triangles so tangents (normal maps) export correctly
        bm = bmesh.new(); bm.from_mesh(o.data)
        ng = [f for f in bm.faces if len(f.verts) > 4]
        if ng: bmesh.ops.triangulate(bm, faces=ng, quad_method='BEAUTY', ngon_method='BEAUTY')
        bm.to_mesh(o.data); bm.free()
    if lod == 0:
        o = objs['Head']; m = o.modifiers.new('LOD', 'DECIMATE'); m.ratio = 0.92; m.use_collapse_triangulate = True
        for mm in o.modifiers:
            if mm.type == 'ARMATURE': mm.show_viewport = False
        with bpy.context.temp_override(object=o, active_object=o):
            bpy.ops.object.modifier_apply(modifier='LOD')
        for mm in o.modifiers: mm.show_viewport = True
    if lod >= 1:
        cur = sum(tris(o) for o in objs.values()); r = TARGET[lod] / cur
        for k, o in objs.items():
            rk = min(1.0, r * (1.45 if k in ('Head',) else (1.15 if k in ('Hair', 'Gloves') else 0.92)))
            m = o.modifiers.new('LOD', 'DECIMATE'); m.ratio = rk; m.use_collapse_triangulate = True
            arm_mod = [mm for mm in o.modifiers if mm.type == 'ARMATURE']
            # apply only the decimate (armature stays live)
            for mm in arm_mod: mm.show_viewport = False
            with bpy.context.temp_override(object=o, active_object=o):
                bpy.ops.object.modifier_apply(modifier='LOD')
            for mm in arm_mod: mm.show_viewport = True
    LODS[lod] = objs
    tot = sum(tris(o) for o in objs.values())
    print(f'LOD{lod} total tris {tot}  ' + '  '.join(f'{k}:{tris(o)}' for k, o in objs.items()))

bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)


# ------------------------------------------------------------------ export
def export(lod, path, anims):
    objs = LODS[lod]
    root = bpy.data.objects.new('Boxer', None); sc.collection.objects.link(root)
    old_arm_name = arm.name; arm.name = 'Armature'; arm_parent = arm.parent; arm.parent = root
    renamed = []
    for k, o in objs.items():
        renamed.append((o, o.name)); o.name = k
        o.parent = root; o.matrix_parent_inverse.identity()
        for m in o.modifiers:
            if m.type == 'ARMATURE': m.object = arm
    for x in bpy.context.view_layer.objects: x.select_set(False)
    for x in [root, arm] + list(objs.values()): x.select_set(True)
    bpy.context.view_layer.objects.active = arm
    try:
        bpy.ops.export_scene.fbx(
            filepath=path, use_selection=True, object_types={'EMPTY', 'ARMATURE', 'MESH'},
            apply_unit_scale=True, apply_scale_options='FBX_SCALE_ALL', axis_forward='-Z', axis_up='Y',
            use_space_transform=True, bake_space_transform=False,
            mesh_smooth_type='FACE', use_tspace=True, use_mesh_modifiers=True, use_triangles=False,
            add_leaf_bones=False, primary_bone_axis='Y', secondary_bone_axis='X', use_armature_deform_only=False,
            armature_nodetype='NULL', bake_anim=anims, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=False,
            bake_anim_use_all_actions=anims, bake_anim_force_startend_keying=True, bake_anim_step=1.0,
            bake_anim_simplify_factor=0.0, path_mode='COPY', embed_textures=True)
    finally:
        for o, n in renamed: o.name = n; o.parent = arm
        arm.parent = arm_parent; arm.name = old_arm_name
        bpy.data.objects.remove(root)
    print('exported', os.path.basename(path), f'{os.path.getsize(path) / 1e6:.1f} MB')


export(0, os.path.join(EXP, 'Boxer_Character_Unity.fbx'), True)
export(0, os.path.join(EXP, 'Boxer_LOD0.fbx'), False)
export(1, os.path.join(EXP, 'Boxer_LOD1.fbx'), False)
export(2, os.path.join(EXP, 'Boxer_LOD2.fbx'), False)
bpy.ops.wm.save_as_mainfile(filepath=bx.BLEND)

# ------------------------------------------------------------------ verify by re-import into an empty scene
for fn in ('Boxer_Character_Unity.fbx', 'Boxer_LOD0.fbx', 'Boxer_LOD1.fbx', 'Boxer_LOD2.fbx'):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.fbx(filepath=os.path.join(EXP, fn))
    objs = list(bpy.context.scene.objects)
    meshes = [o for o in objs if o.type == 'MESH']; arms = [o for o in objs if o.type == 'ARMATURE']
    t = sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in meshes)
    dg = bpy.context.evaluated_depsgraph_get()
    zs = [ (o.matrix_world @ v.co).z for o in meshes for v in o.data.vertices]
    mats = {m.name for o in meshes for m in o.data.materials if m}
    imgs = [i for i in bpy.data.images if i.has_data or i.filepath]
    print(f'VERIFY {fn}: objects {sorted(o.name for o in objs)}')
    print(f'   bones {len(arms[0].data.bones) if arms else 0}  tris {t}  height {max(zs) - min(zs):.3f} m  '
          f'materials {len(mats)}  images {len(imgs)}  actions {len(bpy.data.actions)} {sorted(a.name.split("|")[-1] for a in bpy.data.actions)[:12]}')
    print('   unskinned meshes:', [o.name for o in meshes if not any(m.type == 'ARMATURE' for m in o.modifiers)])
